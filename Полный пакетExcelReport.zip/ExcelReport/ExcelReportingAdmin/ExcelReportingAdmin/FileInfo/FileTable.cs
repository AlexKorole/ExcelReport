﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using ExcelExport;

namespace FileInfo
{
    public class FileTable : DataTable
    {
        public const string Id = "Id";
        public const string FileName = "FileName";
        public const string TimeCreated = "TimeCreated";
        public const string Parameters = "Parameters";
        public const string TimeDuration = "TimeDuration";
        public const string FullFileName = "FullFileName";

        public string CurrentReportName;
        public int ParamCount;
            
        protected FileTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) : 
                  base(info, context) {
                      TableName = "FileTable";
        }

        public FileTable()
            : base()
        {
        }

        public FileTable(string path, string reportName, int paramCount, string username, string system_con_str) : base()
        {
            try
            {
                CurrentReportName = reportName;
                ParamCount = paramCount;
                TableName = "FileTable";
                Columns.Add(Id, typeof (int));
                Columns[0].AutoIncrement = true;
                Columns.Add(FileName, typeof (string));
                Columns.Add(TimeCreated, typeof (DateTime));
                Columns.Add(Parameters, typeof (string));
                Columns.Add(TimeDuration, typeof (string));
                Columns.Add(FullFileName, typeof (string));
                PrimaryKey = new[] {Columns[Id]};

                if (Directory.Exists(path))
                {
                    var files = Directory.GetFiles(path);
                    var rname = reportName.Replace("/", "_").Replace(@"\", "_");
                    //.Substring(0, reportName.Length > 20 ? 20 : reportName.Length);
                    var isEndNumber = Regex.IsMatch(rname, "[0-9]$", RegexOptions.IgnoreCase);
                    if (isEndNumber) rname = rname + "_";

                    foreach (var f in files)
                    {
                        var fileName = Path.GetFileName(f);
                        var fn = Regex.Replace(fileName.Trim(), "[^а-яa-z0-9 \\.]", "specSymb", RegexOptions.IgnoreCase);
                        var rnameR = Regex.Replace(rname.Trim(), "[^а-яa-z0-9 \\.]", "specSymb", RegexOptions.IgnoreCase);
                        if (Regex.IsMatch(fn, rnameR + @"[ 0-9]*\.xlsx", RegexOptions.IgnoreCase))
                            // if (fileName.ToUpper().StartsWith(rname.ToUpper()))
                            AddNewFile(f, username, system_con_str);
                    }
                }
            }
            catch (Exception e)
            {
                Logger.Log.Inst.ErrorToLog(e, username, "Функция FileTable:FileTable. Путь = " + path, null, reportName);
                throw;
            }
        }

        public void AddNewFile(string file, string username, string system_con_str)
        {
            var resString = string.Empty;
            if (ParamCount > 0)
            {
                List<string> s = null;
                try
                {
                    s = BaseExcel.LoadParameters(file);
                    int start = 0;
                    if ((s.Count() - (2*ParamCount)) == 1)
                        start = 1;
                    for (int i = start; i < ParamCount + start; i++)
                    {
                        if ((i + ParamCount) < s.Count())
                            resString += s[i] + " - " + s[i + ParamCount] + "<br/>"; //Environment.NewLine;
                        else
                            resString += s[i] + " - " + "<br/>"; //Environment.NewLine;
                    }
                }
                catch(Exception e)
                {
                    Logger.Log.Inst.ErrorToLog(e, username, "Функция AddNewFile", null, "Инициализация отчетов!");
                };
            }

            var newRow = NewRow();
            var fileName = Path.GetFileName(file);
            var createdDate = File.GetCreationTime(file);
            var modifiedDate = File.GetLastWriteTime(file);
            newRow[FileName] = fileName;
            newRow[FullFileName] = file;
            newRow[TimeCreated] = modifiedDate;
            newRow[Parameters] = resString;
            var dur = modifiedDate.Subtract(createdDate);
            newRow[TimeDuration] = dur.Hours.ToString("00") + ":" + dur.Minutes.ToString("00") + ":" + dur.Seconds.ToString("00");
            Rows.Add(newRow);
        }

    }
}
