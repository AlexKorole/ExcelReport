﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FileInfo
{
    public class FilePersister
    {
        private static object locker = new object();
        private static object lockerAccess = new object();
        public static bool ExecTemplateAction(Action<string, string> act, string param1, string param2)
        {
            var res = false;
            lock (locker)
            {
                if (act != null)
                {
                    act(param1, param2);
                }
                else
                {
                    res = File.Exists(param1);
                }
            }
            return res;
        }

        public static bool ExistsTemplate(string filename)
        {
            return ExecTemplateAction( null, filename, "");
        }

        public static void DeleteOrCopyTemplate(string fileName, string templatePath)
        {
            if (File.Exists(fileName)) File.Delete(fileName);
            File.Copy(templatePath, fileName);
        }

        public static string ExecAccessFunc(Func<string, string> func, string param1)
        {
            string res = string.Empty;
            lock (lockerAccess)
            {
                res = func(param1);
            }
            return res;
        }
    }
}
