﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using SerializeObj;

namespace Logger
{
    public class Log
    {
        private static Log instance;
        public static Log Inst 
        {
            get
            {
                if (instance == null)
                {
                    instance = new Log();
                }
                return instance;
            }
        }

        private static object lockobj = new object();
        private string _strcon;

        public Log()
        {
            _loadSystemCon();
        }

        static object locker = new object();
        private void _loadSystemCon()
        {
            DBConnection DBcon = null;
            var connectionFile = System.Configuration.ConfigurationManager.AppSettings["connectionFile"];
            var rf = new FileStream(connectionFile, FileMode.Open, FileAccess.Read, FileShare.Read);
            var serialize = new XmlSerializer(typeof(List<DBConnection>));
            lock (locker)
            {
                var listDBcon = (List<DBConnection>)serialize.Deserialize(rf);
                rf.Close();

                foreach (var elem in listDBcon)
                {
                    if (elem.type_Of_Usage == "System")
                    {
                        DBcon = elem;
                        break;
                    }
                }
            }
            _strcon = DBcon.value;
        }

        public string _paramToString(DbParameterCollection param)
        {
            var stringB = new StringBuilder();
            if (param != null && param.Count > 0)
            {
                foreach (DbParameter p in param)
                {
                    stringB.AppendLine(p.ParameterName + " = " + p.Value);
                }
            }
            return stringB.ToString();
        }

        public void StatusToLog(string v_message, string v_euser, string v_sqlquery, DbParameterCollection param, string v_report_name, uint v_numrows)
        {
            SaveToDB(_strcon, v_message, v_euser, "Сообщение", v_sqlquery, _paramToString(param), v_report_name, v_numrows, "");
        }

        public void ErrorToLog(Exception e, string v_euser, string v_sqlquery, DbParameterCollection param, string v_report_name, string str_param = "")
        {
            SaveToDB(_strcon, e.Message, v_euser, e.GetType().Name, v_sqlquery, str_param == "" ? _paramToString(param) : str_param, v_report_name, 0, e.StackTrace);
        }

        private void SaveToDB(string strcon, string v_error, string v_euser, string v_type, string v_sqlquery, string v_parameters, string v_report_name, uint v_numrows, string v_error_stack)
        {
            var tableName = System.Configuration.ConfigurationManager.AppSettings["utl_reports_error_log"];
            var query = "insert into " + tableName +
                        " (message, euser, edate, time, host, type, sqlquery, parameters, numrows, report_name, error_stack) values (:v_message, :v_euser, :v_edate, :v_time, :v_host, :v_type, :v_sqlquery, :v_parameters, :v_numrows, :v_report_name, :v_error_stack)";
            var lparam = new List<OracleParameter>();
            lparam.Add(_addParam(OracleType.VarChar, v_error, "v_message"));
            lparam.Add(_addParam(OracleType.VarChar, v_euser, "v_euser"));
            lparam.Add(_addParam(OracleType.DateTime, DateTime.Today, "v_edate"));
            lparam.Add(_addParam(OracleType.VarChar,
                DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00") + ":" +
                DateTime.Now.Second.ToString("00"), "v_time"));
            lparam.Add(_addParam(OracleType.VarChar, System.Net.Dns.GetHostName(), "v_host"));
            lparam.Add(_addParam(OracleType.VarChar, v_type, "v_type"));
            lparam.Add(_addParam(OracleType.Clob, string.IsNullOrEmpty(v_sqlquery) ? null : v_sqlquery, "v_sqlquery"));
            lparam.Add(_addParam(OracleType.VarChar, v_parameters, "v_parameters"));
            lparam.Add(_addParam(OracleType.Number, v_numrows, "v_numrows"));
            lparam.Add(_addParam(OracleType.VarChar, v_report_name, "v_report_name"));
            lparam.Add(_addParam(OracleType.Clob, string.IsNullOrEmpty(v_error_stack) ? null : v_error_stack, "v_error_stack"));
            lock (lockobj)
            {
                _execNonQuery(query, lparam, strcon);
            }
        }

        public static OracleParameter _addParam(OracleType type, object value, string name)
        {
            OracleParameter param = new OracleParameter();
            param.OracleType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = global::System.DBNull.Value;
            }
            else
            {
                param.Value = value;
            }
            return param;
        }

        private void _execNonQuery(string query, List<OracleParameter> lparam, string strcon)
        {
            object res = null;
            OracleConnection con = null;
            try
            {
                con = new OracleConnection(strcon);
                con.Open();
                var com = new OracleCommand();
                com.Connection = con;
                com.CommandTimeout = 0;
                com.CommandText = query;
                if (lparam != null && lparam.Count > 0)
                {
                    foreach (OracleParameter p in lparam)
                    {
                        com.Parameters.Add(p);
                    }
                }
                com.CommandType = CommandType.Text;
                res = com.ExecuteNonQuery();
                com.Parameters.Clear();
                con.Close();
            }
            catch (Exception e)
            {
                throw new Exception("Ошибка SaveToLog: " + e.Message);
            }
            finally
            {
                if( con != null) con.Close();
            }
        }
    }
}
