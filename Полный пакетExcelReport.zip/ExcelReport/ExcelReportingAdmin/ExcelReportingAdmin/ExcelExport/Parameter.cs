﻿using System;
using System.Collections.Generic;
using System.Data.OracleClient;
using Teradata.Client.Provider;

namespace ExcelExport
{
    public class Parameter
    {
        public string queryName;
        public string Name;
        public string Type;
        public string Value;

        public static List<Parameter> MakeParamList(string[] viewName, string[] names, string[] types, string[] values, string currUser, string reportName, string system_con_str)
        {
            if (names == null) return null;
            if (names.Length == 0) return null;
            List<Parameter> list = new List<Parameter>();

            try
            {
                int j = 0;
                for (int i = 0; i < names.Length; i++)
                {
                    Parameter el = new Parameter();

                    el.queryName = names[i];

                    if (el.queryName.ToUpper() == "USERID")
                    {
                        el.Value = currUser;
                        el.Type = "String";
                        el.Name = "Текущий пользователь";
                    }
                    else
                    {
                        el.Value = values[j];
                        el.Type = types[i];
                        el.Name = viewName[i];
                        j++;
                    }
                    list.Add(el);
                }
            }
            catch (Exception e)
            {
                Logger.Log.Inst.ErrorToLog(e, currUser, "Names: " + string.Join(";", names) + " ... Values: " + string.Join(";",values), null, reportName);
                throw;
            }
            return list;
        }
    }

    public class OraParameter
    {
        public string Name;
        public string ViewName;
        public OracleType type;
        public TdType td_type;
        public object Value;

        public static OraParameter AddOraParameter(string Name, OracleType type, object value, string ViewName = "")
        {
            var mparam = new OraParameter();
            mparam.Name = Name;
            mparam.type = type;
            mparam.Value = convertValuesFromString(type, value.ToString());
            mparam.ViewName = ViewName;
            switch (type)
            {
                case OracleType.Number: mparam.td_type = TdType.Number; break;
                case OracleType.NVarChar: mparam.td_type = TdType.VarChar; break;
                case OracleType.DateTime: mparam.td_type = TdType.Date; break;
            }
            return mparam;
        }

        public static object convertValuesFromString(OracleType type, string value)
        {
            object ret = null;
            if (value.Length > 0)
            {
                switch (type)
                {
                    case OracleType.DateTime:
                        ret = DateTime.ParseExact(value, "d.M.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        break;
                    default:
                        ret = value;
                        break;
                }
            }
            return ret;
        }

        public static OracleType convertToTypes(string type)
        {
            OracleType ret = OracleType.NVarChar;
            switch (type)
            {
                case "Number": ret = OracleType.Number; break;
                case "String": ret = OracleType.NVarChar; break;
                case "DateTime": ret = OracleType.DateTime; break;
                case "Double": ret = OracleType.Number; break;
                case "StrMulti": ret = OracleType.LongRaw;break;
            }
            return ret;
        }
    }
}