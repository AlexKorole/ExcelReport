﻿using System;
using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Threading;
using System.Globalization;
using SerializeObj;

namespace ExcelExport
{
    public class BaseExcel
    {
        string output;
        string sheetName;
        SpreadsheetDocument myDoc;
        WorksheetPart worksheetPart;
        WorkbookPart workbookPart;
        public OpenXmlWriter writer;
        OpenXmlWriter sheetWriter;
        List<string> sheetIds = null;
        bool isParameters;
        bool isDataPart = true;

        string _templatePath; 
        public string _templateRowNum;
        string _hdnTemplSheetName;

        private SaveToTemplate saveToTemplate;

        public static Dictionary<string,string> ColumnNameList = null;

        public static List<string> LoadParameters(string filename)
        {
            var text = new List<string>();
            using (SpreadsheetDocument myDoc = SpreadsheetDocument.Open(filename, false))
            {
                var workbookPart = myDoc.WorkbookPart;
                
                var sheetId = SaveToTemplate.GetSheetIdByStartWithName("Параметры (", workbookPart);
                var worksheetPart = workbookPart.GetPartById(sheetId) as WorksheetPart;

                var reader = OpenXmlReader.Create(worksheetPart);
                //while (reader.Read())
                //{
                //    if (reader.ElementType == typeof(CellValue) && reader.IsStartElement == true)
                //    {
                //           text.Add(reader.GetText());
                //    }
                //}
                bool isSheetData = false;
                while (reader.Read())
                {
                    if (reader.ElementType == typeof(SheetData))
                    {
                        if(reader.IsStartElement) isSheetData = true;
                    }

                    if (isSheetData)
                    {
                        if (reader.ElementType == typeof(Cell))
                                {
                                    Cell c = (Cell)reader.LoadCurrentElement();
                                    string cellValue;
                                    var isexists = false;
                                    if (c.DataType != null && c.DataType == CellValues.SharedString)
                                    {
                                        SharedStringItem ssi = workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(int.Parse(c.CellValue.InnerText));
                                        cellValue = ssi.Text.Text;
                                        isexists = true;
                                    }
                                    else
                                    {
                                        if (c.CellValue != null)
                                            cellValue = c.CellValue.InnerText;
                                        else cellValue = string.Empty;
                                        isexists = true;
                                    }
                                    if (isexists) text.Add(cellValue);
                                }
                    }
                    
                    if (reader.ElementType == typeof(SheetData))
                    {
                        if(reader.IsEndElement) isSheetData = false;
                    }
                }

                reader.Close();
            }
            return text;
        }

        public BaseExcel(DBConnection configCon, string query, List<OraParameter> parameters, string filename, string SName, bool isStoredProc, out bool norows, out string err, string reportName, string templatePath, string templateRowNum, string hdnTemplSheetName, string username, string system_con_str, ref UInt32 TotalRows)
        {
            _templatePath = templatePath;
            _templateRowNum = templateRowNum;
            _hdnTemplSheetName = hdnTemplSheetName;
            
            isParameters = false;
            sheetName = SName;
            output = filename;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");

            var r = new BaseDataReader(configCon, isStoredProc);
            r.openRowEvent += OpenRow;
            r.saveCellsEvent += SaveCells;
            r.closeRowEvent += CloseRow;

            if (!string.IsNullOrEmpty(_templatePath))
            {
                saveToTemplate = new SaveToTemplate();
                r.openNewSheet += saveToTemplate.OpenNewSheet;
                //r.closeRowEvent += saveToTemplate.CloseRow;
                saveToTemplate.CreateExcelFile(filename, _hdnTemplSheetName, query, parameters, r, this, reportName, out norows, out err, username, system_con_str, ref TotalRows);
                return;
            }
            else
            {
                CreateExcelFile();
                SaveParameters(parameters, reportName);
                r.openNewSheet += OpenNewSheet;
            }

            r.RunReader(query, parameters, false, out norows, out err, username, system_con_str, reportName, ref TotalRows);
            CloseExcelFile();
        }

        public void SaveParameters(List<OraParameter> parameters, string reportName)
        {
            isDataPart = false;
            if (!string.IsNullOrEmpty(reportName))
            {
                isParameters = true;
                OpenRow(1);
                BaseColumn c = new BaseColumn();
                c.Name = reportName;
                c.Type = typeof(string);
                SaveCells(c, null, 1);
                CloseRow();
            }
            
            if (parameters != null && parameters.Count > 0)
            {
                OpenRow(2);
                int i = 1;
                foreach (var p in parameters)
                {
                    BaseColumn c = new BaseColumn();
                    c.Name = p.ViewName;
                    c.Type = typeof(string);
                    SaveCells(c, null, i);
                    i++;
                }
                CloseRow();

                OpenRow(3);
                i = 1;
                foreach (var p in parameters)
                {
                    BaseColumn c = new BaseColumn();
                    if (p.Value != null)
                    {
                        c.Type = typeof(string);
                        if (p.Value.GetType() == typeof(DateTime))
                            SaveCells(c, Convert.ToDateTime(p.Value).ToString("dd.MM.yyyy"), i);
                        else SaveCells(c, p.Value.ToString(), i);
                        //c.Type = p.Value.GetType();
                        //SaveCells(c, p.Value, i);
                    }
                    else
                    {
                        c.Type = typeof(DBNull);
                        SaveCells(c, DBNull.Value, i);
                    }
                    i++;
                }
                CloseRow();
            }
            if (string.IsNullOrEmpty(_templatePath)) OpenNewSheet();
            isDataPart = true;
        }


        bool isrownum1AndTemplate = false;
        private void OpenRow(int rowNum)
        {
            if (isDataPart)
            {
                if (!string.IsNullOrEmpty(_templatePath))
                {
                    if (rowNum == 1)
                    {
                        isrownum1AndTemplate = true;
                        return;
                    }
                }
            }
            var oxa = new List<OpenXmlAttribute>();
            if (isDataPart)
            {
                int intRowNum;
                if (int.TryParse(_templateRowNum, out intRowNum))
                {
                    if (intRowNum > 0)
                        oxa.Add(new OpenXmlAttribute("r", null, (rowNum + intRowNum - 2).ToString()));
                    else oxa.Add(new OpenXmlAttribute("r", null, rowNum.ToString()));
                }
                else
                    oxa.Add(new OpenXmlAttribute("r", null, rowNum.ToString()));
            }
            else oxa.Add(new OpenXmlAttribute("r", null, rowNum.ToString()));
            writer.WriteStartElement(new Row(), oxa);
        }

        private void CloseRow()
        {
            if (isDataPart)
            {
                if (!isrownum1AndTemplate)
                    writer.WriteEndElement();
                else isrownum1AndTemplate = false;
            }
            else writer.WriteEndElement();
        }

        private void SaveCells(BaseColumn c, object value, int colNum)
        {
            if(isDataPart)
                if (!string.IsNullOrEmpty(_templatePath) && value == null) return;
            var oxa = new List<OpenXmlAttribute>();
            string exelType = string.Empty;
            //if (!isDataPart)
            {
                if (value == null || value == DBNull.Value) exelType = "str";
                else exelType = getExcelType(c.Type);
            }
           // else exelType = getExcelType(c.Type);

            if (exelType == "d")
            {
                if (isDataPart)
                {
                    if (!string.IsNullOrEmpty(_templatePath)) //шаблон
                    {
                        oxa.Add(new OpenXmlAttribute("s", null, "4"));
                    //    exelType = "str";
                    //    oxa.Add(new OpenXmlAttribute("t", null, exelType));
                    }
                    else
                        oxa.Add(new OpenXmlAttribute("s", null, "1"));
                }
                else
                    oxa.Add(new OpenXmlAttribute("s", null, "1"));
            } else  
                oxa.Add(new OpenXmlAttribute("t", null, exelType));
            writer.WriteStartElement(new Cell(), oxa);
            saveCellValue(c, value, exelType);
            writer.WriteEndElement();
        }

        private void saveCellValue(BaseColumn c, object value, string exelType)
        {
            if (value == null)
            {
                if (ColumnNameList != null)
                {
                    if(ColumnNameList.ContainsKey(c.Name.ToUpper()))
                        writer.WriteElement(new CellValue(ColumnNameList[c.Name.ToUpper()]));
                    else writer.WriteElement(new CellValue(c.Name));
                }
                else 
                    writer.WriteElement(new CellValue(c.Name));
            }
            else
            {
                var v = value is DBNull ? "" : value.ToString();
                switch (exelType)
                {
                    case "n": 
                        //writer.WriteElement(new CellValue(v.Replace(",", ".")));
                        if (value is DBNull)
                            writer.WriteElement(new CellValue());
                        else
                            writer.WriteElement(new CellValue(v.Replace(",", ".")));
                        break;
                    case "d":
                        if (string.IsNullOrEmpty(_templatePath)) // не шаблон
                        {
                            v = value is DBNull ? "" : Convert.ToDateTime(value).ToOADate().ToString();
                            //v = value is DBNull ? "" : Convert.ToDateTime(value).ToString("yyyy-MM-ddThh:mmZ");
                            //v = value is DBNull ? "" : Convert.ToDateTime(value).ToString("dd.MM.yyyy");
                            writer.WriteElement(new CellValue(v));
                            
                            //------------------------
                            //if (value is DBNull)
                            //    writer.WriteElement(null);
                            //else
                            //{
                            //    v = Convert.ToDateTime(value).ToOADate().ToString();
                            //    writer.WriteElement(new CellValue(v));
                            //}
                            //-------------------------
                        }
                        else //шаблон
                        {
                            v = value is DBNull ? "" : Convert.ToDateTime(value).ToOADate().ToString();
                            writer.WriteElement(new CellValue(v));
                        }
                        break;
                    default:
                        writer.WriteElement(new CellValue(BadChars.Fix(v)));
                        break;
                }
            }
        }

        private void OpenNewSheet()
        {
            CloseSheet();
            CreateExcelFile(false);
        }
        
        private void CloseSheet()
        {
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Close();
            
            if (sheetIds == null) sheetIds = new List<string>();
            sheetIds.Add(myDoc.WorkbookPart.GetIdOfPart(worksheetPart));
        }

        private void CloseExcelFile()
        {
            if (!string.IsNullOrEmpty(_templatePath))
            {
                writer.WriteEndElement();
                writer.WriteEndElement(); 
                writer.Close();
                myDoc.Close();
                return;
            }
            writer.WriteEndElement();
            writer.WriteEndElement(); 
            writer.Close();

            if (sheetIds == null) sheetIds = new List<string>();
            sheetIds.Add(myDoc.WorkbookPart.GetIdOfPart(worksheetPart));

            sheetWriter = OpenXmlWriter.Create(myDoc.WorkbookPart);
            sheetWriter.WriteStartElement(new Workbook());
            sheetWriter.WriteStartElement(new Sheets());

            uint sheetId = 1;
            bool isfirst = true;
            foreach (var id in sheetIds)
            {
                if (sheetIds.Count > 1)
                {
                    if (isParameters && isfirst)
                    {
                        isfirst = false;
                        isParameters = false;
                        var sheet = new Sheet()
                        {
                            Name = "Параметры (" + sheetId.ToString() + ")",
                            SheetId = (UInt32Value)sheetId,
                            Id = id
                        };
                        sheetWriter.WriteElement(sheet);
                    }
                    else
                        sheetWriter.WriteElement(new Sheet()
                        {
                            Name = sheetName + " (" + sheetId.ToString() + ")",
                            SheetId = (UInt32Value)sheetId,
                            Id = id
                        });
                }
                else
                    sheetWriter.WriteElement(new Sheet()
                    {
                        Name = sheetName,
                        SheetId = (UInt32Value)sheetId,
                        Id = id
                    });
                sheetId++;
            }

            sheetWriter.WriteEndElement();
            sheetWriter.WriteEndElement();
            sheetWriter.Close();
            myDoc.Close();
        }

        private void CreateExcelFile(bool isnew = true)
        {
            if (isnew)
            {
                myDoc = SpreadsheetDocument.Create(output, SpreadsheetDocumentType.Workbook);
                workbookPart = myDoc.AddWorkbookPart();
                var style = ApplyStylesheet(workbookPart);
            }

            worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
            writer = OpenXmlWriter.Create(worksheetPart);
            Worksheet worksheet = new Worksheet() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "x14ac" } };
            var ns = new Dictionary<string, string>();
            ns["r"] = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
            ns["mc"] = "http://schemas.openxmlformats.org/markup-compatibility/2006";
            ns["x14ac"] = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac";

            var attr = new List<OpenXmlAttribute>();
            attr.Add(new OpenXmlAttribute("mc:Ignorable", null, "x14ac"));
            writer.WriteStartElement(worksheet, attr, ns);
            writer.WriteStartElement(new SheetData());

            //if (!isnew)
            //{
            //    CopyExcelHeadFromTemplate.CopyHead(_templatePath, _templateRowNum, _hdnTemplSheetName, writer);
            //}
        }


        public static WorkbookStylesPart ApplyStylesheet(WorkbookPart workbookPart)
        {
            WorkbookStylesPart workbookStylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();

            Stylesheet stylesheet1 = new Stylesheet()
            {
                MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "x14ac" }
            };
            stylesheet1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
            stylesheet1.AddNamespaceDeclaration("x14ac", "http://schemas.microsoft.com/office/spreadsheetml/2009/9/ac");
            /*Шрифты*/
            Fonts fonts = new Fonts() { Count = (UInt32Value)1U, KnownFonts = true };

            Font font = new Font();
            FontSize fontSize = new FontSize() { Val = 11D };
            Color color = new Color() { Theme = (UInt32Value)1U };
            FontName fontName = new FontName() { Val = "Calibri" };
            FontFamilyNumbering fontFamilyNumbering = new FontFamilyNumbering() { Val = 2 };
            FontCharSet fontCharSet = new FontCharSet() { Val = 204 };
            FontScheme fontScheme = new FontScheme() { Val = FontSchemeValues.Minor };

            font.Append(fontSize);
            font.Append(color);
            font.Append(fontName);
            font.Append(fontFamilyNumbering);
            font.Append(fontCharSet);
            font.Append(fontScheme);

            fonts.Append(font);
            /*************/
            /*Заливка*/
            Fills fills = new Fills() { Count = (UInt32Value)1U };

            Fill fillNone = new Fill();
            PatternFill patternFillNone = new PatternFill() { PatternType = PatternValues.None };
            fillNone.Append(patternFillNone);

            fills.Append(fillNone);
            /*************/
            /*Границы*/
            Borders borders = new Borders() { Count = (UInt32Value)1U };

            Border border = new Border();
            LeftBorder leftBorder = new LeftBorder();
            RightBorder rightBorder = new RightBorder();
            TopBorder topBorder = new TopBorder();
            BottomBorder bottomBorder = new BottomBorder();
            DiagonalBorder diagonalBorder = new DiagonalBorder();

            border.Append(leftBorder);
            border.Append(rightBorder);
            border.Append(topBorder);
            border.Append(bottomBorder);
            border.Append(diagonalBorder);

            borders.Append(border);
            /*************/
            /*Форматы*/
            CellFormats cellFormats = new CellFormats() { Count = (UInt32Value)3U };

            CellFormat stringCellFormat = new CellFormat()
            {
                NumberFormatId = (UInt32Value)0U,
                FontId = (UInt32Value)0U,
                FillId = (UInt32Value)0U,
                BorderId = (UInt32Value)0U,
                FormatId = (UInt32Value)0U
            };
            CellFormat dateCellFormat = new CellFormat()
            {
                NumberFormatId = (UInt32Value)14U,
                FontId = (UInt32Value)0U,
                FillId = (UInt32Value)0U,
                BorderId = (UInt32Value)0U,
                FormatId = (UInt32Value)0U,
                ApplyNumberFormat = true
            };
            CellFormat numberCellFormat = new CellFormat()
            {
                NumberFormatId = (UInt32Value)2U,
                FontId = (UInt32Value)0U,
                FillId = (UInt32Value)0U,
                BorderId = (UInt32Value)0U,
                FormatId = (UInt32Value)0U,
                ApplyNumberFormat = true
            };

            cellFormats.Append(stringCellFormat);
            cellFormats.Append(dateCellFormat);
            cellFormats.Append(numberCellFormat);
            /*************/
            stylesheet1.Append(fonts);
            stylesheet1.Append(fills);
            stylesheet1.Append(borders);
            stylesheet1.Append(cellFormats);

            workbookStylesPart.Stylesheet = stylesheet1;

            return workbookStylesPart;
        }

        private string getExcelType(Type Type)
        {
            if (Type == typeof(string)) return "str";
            else
            {
                if (Type == typeof(DateTime)) return "d";
                else return "n";
            }
        }
    }
}