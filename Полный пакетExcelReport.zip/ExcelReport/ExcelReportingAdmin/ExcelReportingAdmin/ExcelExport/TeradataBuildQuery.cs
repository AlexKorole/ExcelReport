﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ExcelExport
{
    public class TeradataBuildQuery
    {
        public static void enterMultiParameters(ref string query, List<OraParameter> parameters)
        {
            var parMulti = new List<OraParameter>();

            foreach (var par in parameters)
            {
                if (par.type == OracleType.LongRaw)
                {
                    if (par.Value == null) par.Value = "NULL";
                    query = query.Replace(" :" + par.Name, par.Value.ToString());
                    parMulti.Add(par);
                }
            }

            foreach (var parmultiEl in parMulti)
            {
                parameters.Remove(parmultiEl);
            }
        }

        public static void prepareTeradataQuery(string query, List<OraParameter> parameters, DbCommand com)
        {
            enterMultiParameters(ref query, parameters);
            var dictParam = new Dictionary<int, OraParameter>();
            foreach (var pelem in parameters)
            {
                var abs_lcount = 0;
                var lcount = 0;
                var subquery = query;
                do
                {
                    lcount = subquery.IndexOf(":" + pelem.Name);
                    if (lcount >= 0)
                    {
                        abs_lcount += lcount;
                        dictParam.Add(abs_lcount, pelem);
                        abs_lcount += pelem.Name.Length + 1;
                        subquery = subquery.Substring(lcount + pelem.Name.Length + 1,
                            subquery.Length - (lcount + pelem.Name.Length + 1));
                    }
                } while (lcount >= 0);
            }

            foreach (var parm in dictParam.OrderBy(i => i.Key))
            {
                com.Parameters.Add(BaseDataReader.addParam(parm.Value.td_type, parm.Value.Value, parm.Value.Name));
            }
            com.CommandText = Regex.Replace(query, @" \:\w+", " ?");
        }
    }
}
