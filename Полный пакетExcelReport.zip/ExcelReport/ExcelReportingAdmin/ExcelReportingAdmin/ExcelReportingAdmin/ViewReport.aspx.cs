﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Threading;
using System.Globalization;
using ExcelReportingAdmin.ASPBackend;
using System.Web.Hosting;
using System.IO;
using System.Web.Services;
using dll_DataLayer;
using System.Data.OracleClient;
using System.Text.RegularExpressions;

namespace ExcelReportingAdmin
{
    public partial class ViewReport : System.Web.UI.Page
    {
        public static readonly string const_QueryPath = HostingEnvironment.ApplicationPhysicalPath + @"SQL\SQLQueries.xml";
        public static readonly string const_TemplatePath = System.Configuration.ConfigurationManager.AppSettings["ExcelTemplatesPath"];
        readonly string tempPath = System.Configuration.ConfigurationManager.AppSettings["PublicPath"];

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                btnExcel.Visible = true;
                var err = Queries.Init(const_QueryPath);
                if (!string.IsNullOrEmpty(err))
                    lblError.Text = err;
            }

            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            if (afterhdnClick.Value == "true")
            {
                if (Session[SessionNames.divParamsControls] != null && divParams.Controls.Count <= 1)
                {
                    List<Control> contr = Session[SessionNames.divParamsControls] as List<Control>;
                    foreach (var c in contr)
                    {
                        divParams.Controls.Add(c);
                    }
                }
            }
        }

        protected void hdnLoad_Click(object sender, EventArgs e)
        {
            Session[SessionNames.divParamsControls] = null;
            afterhdnClick.Value = "true";
            var con = Common.loadUserCon(Session).value;
            List<Control> contr = ViewReportBackEnd.AddDynamicControls(con, serverParamsName, serverParamsViewName, serverParamsType, serverParamsMaxVal, serverParamsMinVal, Session, const_QueryPath, Request.LogonUserIdentity.Name);
            if (contr != null)
            {
                foreach (var c in contr)
                {
                    divParams.Controls.Add(c);
                }
            }
        }

        protected void btnExcel_Click(object sender, EventArgs e)
        {
            var error = string.Empty;
            string newDir = Request.LogonUserIdentity.Name.Replace(@"\", "");
            var newpath = tempPath + @"\" + newDir + @"\";
            var repName = Session[SessionNames.CurrentReportName] != null?
                Session[SessionNames.CurrentReportName].ToString() : "разовый_селект";

            var list = new List<string>();
            if (Directory.Exists(newpath))
            {
                var files = Directory.GetFiles(newpath);
                var rname = Common.MakeShortName(repName);

                foreach (var f in files)
                {
                    var fileName = Path.GetFileName(f);
                    var fn = Regex.Replace(fileName.Trim(), "[^а-яa-z0-9 \\.]", "specSymb", RegexOptions.IgnoreCase);
                    var rnameR = Regex.Replace(rname.Trim(), "[^а-яa-z0-9 \\.]", "specSymb", RegexOptions.IgnoreCase);
                    if (Regex.IsMatch(fn, rnameR + @"[ 0-9]*\.xlsx", RegexOptions.IgnoreCase))
                        list.Add(fileName);
                }
            }

            var file = list.Max<string>();
            error = UIHelper.SendResult(newpath + file, false, Server.UrlEncode(file), "", this.Context.Response);
            lblStatus.Text = error;

            /*var error = string.Empty;
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            string query = serverQuery.Value;
            var reportName = string.Empty;
            if (serverReportName.Value.Length > 0)
                reportName = serverReportName.Value;

//--------------------------isStoredProc-------------------------            
            bool isStoredProc = false;
            if (Session[SessionNames.currentElements] is Dictionary<string, Element>)
            {
                var d = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                if (d.ContainsKey(Session[SessionNames.CurrentReportName].ToString()))
                {
                    isStoredProc = d[Session[SessionNames.CurrentReportName].ToString()].IsStoredProcedure;
                }
            }
//---------------------------------------------------------------

            if (query == string.Empty)
            {
                var d = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                if (d.ContainsKey(Session[SessionNames.CurrentReportName].ToString()))
                {
                    query = d[Session[SessionNames.CurrentReportName].ToString()].query;
                    if (serverReportName.Value.Length <= 0)
                        reportName = d[Session[SessionNames.CurrentReportName].ToString()].name;
                }
            }

            string shortName = reportName.Substring(0, reportName.Length > 20 ? 20 : reportName.Length);
            string tempPath = System.Configuration.ConfigurationManager.AppSettings["PublicPath"];
            string fileName = tempPath + Session.SessionID + shortName + ".xlsx";
            string values = serverParamValues.Value;
            if (string.IsNullOrWhiteSpace(values) && serverParamsName.Value != string.Empty)
            {
                lblError.Text = "Введите знечения для параметров!";
                return;
            }

            List<OraParameter> parameters = null;
            if (serverParamsName.Value != string.Empty)
            {
                var paramhtml = ExcelExport.Parameter.MakeParamList(serverParamsViewName.Value.Split(';'), serverParamsName.Value.Split(';'), serverParamsType.Value.Split(';'), values.Split(';'), Request.LogonUserIdentity.Name);
                
                if (paramhtml != null && paramhtml.Count > 0)
                {
                    parameters = new List<OraParameter>();
                    foreach (var p in paramhtml)
                    {
                        parameters.Add(OraParameter.AddOraParameter(p.queryName, OraParameter.convertToTypes(p.Type), p.Value, p.Name));
                    }
                }
            }
            bool norows = false;
            string err;
            var con = Common.loadCon(Session)[0].value;

            if (reportName == "ЧОД в разрезе клиентов")
            {
                var l = File.ReadAllLines(Request.PhysicalApplicationPath + @"SQL\ChodClients.txt");
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key, value);
                }

            }

            var a = new BaseExcel(con, query, parameters, fileName, shortName, isStoredProc, out norows, out err, reportName);
            lblStatus.Text = string.Empty;
            if (string.IsNullOrEmpty(err))
            {
                Response.AppendCookie(new HttpCookie("fileDownloadToken", "finished"));
                error = UIHelper.SendResult(fileName, norows, Server.UrlEncode(shortName), ".xlsx", this.Context.Response);
            }
            else error = err;
            if (!string.IsNullOrEmpty(error))

                Response.Cookies.Remove("fileDownloadToken");
            lblError.Text = error;*/
        }

        [WebMethod]
        public static string GetColumnsWebMethod(string serverParamsName, string serverParamsViewName, string serverParamsType, string serverParamsValue)
        {
            string err = string.Empty;
            var res2 = string.Empty;
            string errLFB = string.Empty;
            string error = string.Empty;
            var query = string.Empty;
            var reportName = string.Empty;
            try
            {
                var Session = HttpContext.Current.Session;
                bool isStoredProc = false;

                var ec = ExcelClick.PrepareUnload(ref query, ref reportName, Session, ref isStoredProc, const_QueryPath, const_TemplatePath);
                ec.system_con_str = (Common.loadSystemCon(Session)).value;
                
                
                var spn = Uri.UnescapeDataString(serverParamsName);
                var spvn = Uri.UnescapeDataString(serverParamsViewName);
                var spt = Uri.UnescapeDataString(serverParamsType);
                var spv = Uri.UnescapeDataString(serverParamsValue).Replace("&oneQuot;", "'");
                var res = ec.GetColumnName(reportName, spn, spvn, spt, spv, out error);
               
                var s = new Storage(HttpContext.Current.Cache, Common.loadSystemCon(Session).value);
                var con = s.Connection(out err);
                
               
                using (con)
                {
                    res2 = ec.LoadValuesFromDB(res, reportName, con, out errLFB);
                }
            }
            catch (Exception e)
            {
                if (e.InnerException != null)
                    error += "error=" + e.InnerException.Message;
                else
                    error += "error=" + e.Message;
                Logger.Log.Inst.ErrorToLog(e,
                       HttpContext.Current.Request.LogonUserIdentity.Name, query, null, reportName);
            }

            var result = "error=" + error + err + errLFB + ";value=" + res2;
            return Uri.EscapeDataString(result);
        }

        [WebMethod]
        public static string BtnSaveColName(string columns)
        {
            var query = string.Empty;
            var reportName = string.Empty;
            var Session = HttpContext.Current.Session;
            bool isStoredProc = false;
            ExcelClick.GetReportNameQuery(ref query, ref reportName, Session, ref isStoredProc);

            columns = Uri.UnescapeDataString(columns);
            var arrColumns = columns.Split(':');
            var bt = new BaseTable();
            bt.Columns.Add(bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.BASECOLUMNNAME), typeof(string));
            bt.Columns.Add(bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.EXCELCOLUMNNAME), typeof(string));
            bt.Columns.Add(bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.REPORTNAME), typeof(string));

            foreach (var el in arrColumns)
            {
                var elArr = el.Split('=');
                if (elArr.Length >= 2)
                {
                    var nrow = bt.NewRow();
                    nrow[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.REPORTNAME)] = reportName;
                    nrow[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.BASECOLUMNNAME)] = elArr[0];
                    nrow[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.EXCELCOLUMNNAME)] = elArr[1];
                    bt.Rows.Add(nrow);
                }
            }
            var s = new Storage(HttpContext.Current.Cache, Common.loadSystemCon(Session).value);
            string err;
            using (var con = s.Connection(out err))
            {
                bt.setConAndPath(const_QueryPath, con);
                var paramList = new List<DbParameter>();
                paramList.Add(Queries.addParam(OracleType.VarChar, reportName, "reportname"));
                var user_name = Queries.addParam(OracleType.VarChar, HttpContext.Current.Request.LogonUserIdentity.Name, "user_name");
                var modifieddate = Queries.addParam(OracleType.DateTime, DateTime.Now, "modifieddate");
                paramList.Add(user_name);
                paramList.Add(modifieddate);
                err += bt.ExecQuery("CopyToLog_utl_reports_column_names_log", paramList);
                paramList.Remove(user_name);
                paramList.Remove(modifieddate);
                err += bt.ExecQuery("Delete_UTL_REPORTS_COLUMN_NAMES", paramList);
                err += bt.InsertAllRows("Insert_UTL_REPORTS_COLUMN_NAMES", typeof(Enums.UTL_REPORTS_COLUMN_NAMES));
            }
            return "error=" + err;
        }
    }
}