﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Threading;
using System.Globalization;
using DevExpress.Web.ASPxEditors;
using ExcelReportingAdmin.ASPBackend;
using System.IO;
using FileInfo;
using DevExpress.Web.ASPxGridView;
using System.Web.Services;
using dll_DataLayer;
using System.Web.Hosting;
using System.Reflection;
using Newtonsoft.Json;


namespace ExcelReportingAdmin
{
    public partial class ViewReportLong : System.Web.UI.Page
    {
        public static readonly string const_QueryPath = HostingEnvironment.ApplicationPhysicalPath + @"SQL\SQLQueries.xml";
        public static readonly string const_TemplatePath = System.Configuration.ConfigurationManager.AppSettings["ExcelTemplatesPath"];
        readonly string tempPath = System.Configuration.ConfigurationManager.AppSettings["PublicPath"];

        private string GetReportName()
        {
            if (Session[SessionNames.CurrentReportName] == null)
                return hCurrentReportName.Value;
            return Session[SessionNames.CurrentReportName].ToString();
        }
        
        private FileTable InitFileTable()
        {
            try
            {
                string newDir = Request.LogonUserIdentity.Name.Replace(@"\", "");
                int colNum = 0;
                if (serverParamsName.Value.Length > 0)
                    colNum = serverParamsName.Value.Split(';').Count();
                var newpath = tempPath + @"\" + newDir + @"\";
                return new FileTable(newpath, GetReportName(), colNum,
                    Request.LogonUserIdentity.Name, Common.loadSystemCon(Session).value);
            }
            catch (Exception e)
            {
                Logger.Log.Inst.ErrorToLog(e, Request.LogonUserIdentity.Name, "Функция ViewReportLong:InitFileTable. serverParamsName.Value = " + serverParamsName.Value,
                    null, GetReportName());
                throw;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (IsPostBack)
                {
                    btnExcel.Visible = true;
                    gvFiles.Visible = true;
                    gvFiles.DataSource = InitFileTable();
                    gvFiles.DataBind();
                    Queries.Init(const_QueryPath);
                }
                else
                {
                    PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
                    isreadonly.SetValue(Request.QueryString, false, null);
                    Request.QueryString.Clear();
                }

                Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
                if (afterhdnClick.Value == "true")
                {
                    if (Session[SessionNames.divParamsControls] != null && divParams.Controls.Count <= 1)
                    {
                        List<Control> contr = Session[SessionNames.divParamsControls] as List<Control>;
                        foreach (var c in contr)
                        {
                            divParams.Controls.Add(c);
                        }
                    }
                }
            }
            catch (Exception err)
            {
                lblError.Text = err.Message;
                Logger.Log.Inst.ErrorToLog(err,
                                           HttpContext.Current.Request.LogonUserIdentity.Name,
                                           "Функция ViewReportLong.aspx:Page_Load (инициализация страницы)", null, "ViewReportLong.aspx:Page_Load");
            }
        }

        protected void hdnLoad_Click(object sender, EventArgs e)
        {
            if (Session[SessionNames.CurrentReportName] != null)
                hCurrentReportName.Value = Session[SessionNames.CurrentReportName].ToString();
            Session[SessionNames.divParamsControls] = null;
            afterhdnClick.Value = "true";
            var con = Common.loadUserCon(Session).value;
            List<Control> contr = ViewReportBackEnd.AddDynamicControls(con, serverParamsName, serverParamsViewName, serverParamsType, serverParamsMaxVal, serverParamsMinVal, Session, const_QueryPath, Request.LogonUserIdentity.Name);
            if (contr != null)
            {
                foreach (var c in contr)
                {
                    divParams.Controls.Add(c);
                }
            }
        }

        [WebMethod(EnableSession = true)]
        public static string ExcelWebMethod(string serverParamsName, string serverParamsViewName, string serverParamsType, string serverParamsValue, string hdnTemplateRowNum, string hdnTemplSheetName, string serverQuery = "")
        {
            var error = string.Empty;
            var query = serverQuery;//HttpUtility.UrlDecode(serverQuery, System.Text.Encoding.Default);
            var reportName = string.Empty;
            var Session = HttpContext.Current.Session;
            bool isStoredProc = false;
            var ts = new CancellationTokenSource();
            var curr_user = HttpContext.Current.Request.LogonUserIdentity.Name;
            CancellationToken ct = ts.Token;

            var ec = ExcelClick.PrepareUnload(ref query, ref reportName, Session, ref isStoredProc, const_QueryPath, const_TemplatePath, Uri.UnescapeDataString(hdnTemplateRowNum), Uri.UnescapeDataString(hdnTemplSheetName));

            string errcon;
            var s = new Storage(HttpContext.Current.Cache, Common.loadUserCon(Session).value, Common.loadSystemCon(Session).value);

            Task<string> mainTask = Task.Factory.StartNew<string>(() =>
            {
                ec.db_user_con = s.Connection(out errcon, Common.loadUserCon(Session).type);
                ec.db_system_con = s.ConnectionSystem(out errcon, Common.loadSystemCon(Session).type);
                ec.system_con_str = ((SerializeObj.DBConnection) Session[SessionNames.ConnectSystem]).value;
                
                error += errcon;
                var spn = serverParamsName;//Uri.UnescapeDataString(serverParamsName);
                var spvn = serverParamsViewName;//Uri.UnescapeDataString(serverParamsViewName);
                var spt = serverParamsType;//Uri.UnescapeDataString(serverParamsType);
                var spv = serverParamsValue;//Uri.UnescapeDataString(serverParamsValue).Replace("&oneQuot;", "'");
                var err = ec.Run(reportName, spn, spvn, spt, spv);

                if (!string.IsNullOrEmpty(err))
                {
                    var ex = new Exception(err);
                    Logger.Log.Inst.ErrorToLog(ex, curr_user, query, null, reportName, "Названия = " + spn + ".Тип = " + spt + " .Значения = " + spv);
                }

                ec.db_user_con.Close();
                ec.db_system_con.Close();
                return err;
            }, ct);

            if (mainTask.IsCompleted || mainTask.IsCanceled || mainTask.IsFaulted)
            {
                error += mainTask.Result;
            }
            else
            {
                var guid = Guid.NewGuid();
                Session["loadTask_" + guid.ToString()] = mainTask;
                Session["TotalRows_" + guid.ToString()] = ec;
                return "error=" + error + ";guid=" + guid.ToString();// +";procId=" + System.Diagnostics.Process.GetCurrentProcess().Id;
            }
            return "error=" + error + ";guid=";
        }
       
        [WebMethod]
        public static string CheckStateLoad(string guid)
        {
            var nguid = HttpUtility.UrlDecode(guid, System.Text.Encoding.Default);
            guid = nguid;
            var err = string.Empty;
            var result = "iscompleted=false";
            var rownum = "rownum=0";

            try
            {
                if (guid.Length > 0)
                {
                    result = "iscompleted=false";
                    if (HttpContext.Current.Session["loadTask_" + guid] != null)
                    {
                        var task = HttpContext.Current.Session["loadTask_" + guid] as Task<string>;
                        if (task.IsCompleted || task.IsCanceled || task.IsFaulted)
                        {
                            result = "iscompleted=true";
                            err = "error=" + task.Result;
                        }
                        if (HttpContext.Current.Session["TotalRows_" + guid] != null)
                        {
                            var TotalRows = ((ExcelClick)(HttpContext.Current.Session["TotalRows_" + guid])).TotalRows;
                            rownum = "rownum=" + TotalRows;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                if (e.InnerException != null)
                {
                    err += "error=" + e.InnerException.Message;
                    e = e.InnerException;
                }
                else
                    err += "error=" + e.Message;
                Logger.Log.Inst.ErrorToLog(e,
                      HttpContext.Current.Request.LogonUserIdentity.Name, "TotalRows_" + guid, null, "Процесс опроса состояния загрузки отчета!");
            }
            return err + ";" + result + ";" + rownum;
        }

        protected void btnExcel_Click(object sender, EventArgs e)
        {
            lblStatus.Text = string.Empty;
            var ft = InitFileTable();
            gvFiles.DataSource = ft;
            gvFiles.DataBind();
        }

        protected void btnDownload_Click(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = string.Empty;
                var key = ((ASPxButton)sender).JSProperties["cp_key"];
                var ft = InitFileTable();
                var row = ft.Rows.Find(key);

                UIHelper.Upload(Response, row[FileTable.FullFileName].ToString(),
                                            Server.UrlEncode(row[FileTable.FileName].ToString()), "");
                Response.End();
            }
            catch (Exception err)
            {
                if (!(err is ThreadAbortException))
                {
                    lblError.Text = err.Message;
                    Logger.Log.Inst.ErrorToLog(err,
                        HttpContext.Current.Request.LogonUserIdentity.Name,
                        "Функция ViewReportLong.aspx:btnDownload_Click", null,
                        "Ошибка, теоретически, может быть связанна с поиском имени файла!");
                }
            }
        }

        protected void gvFiles_HtmlRowCreated(object sender, DevExpress.Web.ASPxGridView.ASPxGridViewTableRowEventArgs e)
        {
            if (e.VisibleIndex < 0) return;
            
            var btnDownload = gvFiles.FindRowCellTemplateControl(e.VisibleIndex, gvFiles.Columns[0] as GridViewDataColumn, "btnDownload") as ASPxButton;
            btnDownload.JSProperties["cp_key"] = e.KeyValue;

            var btnDelete = gvFiles.FindRowCellTemplateControl(e.VisibleIndex, gvFiles.Columns[gvFiles.Columns.Count-1] as GridViewDataColumn, "btnDelete") as ASPxButton;
            btnDelete.JSProperties["cp_key"] = e.KeyValue;
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            var key = ((ASPxButton)sender).JSProperties["cp_key"];
            var ft = InitFileTable();
            var row = ft.Rows.Find(key);
            File.Delete(row[FileTable.FullFileName].ToString());
            ft.Rows.Remove(row);
            gvFiles.DataSource = ft;
            gvFiles.DataBind();
        }
    }
}