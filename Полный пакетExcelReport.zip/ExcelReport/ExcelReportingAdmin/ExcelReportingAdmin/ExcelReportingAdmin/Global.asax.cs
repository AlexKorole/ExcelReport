﻿using System;
using System.Web;
using ExcelReportingAdmin.ASPBackend;

namespace ExcelReportingAdmin
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            HttpContext.Current.Response.AddHeader("p3p", "CP=\"IDC DSP COR ADM DEVi TAIi PSA PSD IVAi IVDi CONi HIS OUR IND CNT\"");
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception lastError = Server.GetLastError();
            if (lastError != null)
            {
                if (lastError is HttpUnhandledException && lastError.InnerException != null)
                    lastError = lastError.InnerException;
                Logger.Log.Inst.ErrorToLog(lastError,
                                           HttpContext.Current.Request.LogonUserIdentity.Name, "Функция Application_Error", null, "!!! Отчет неизвестен !!!");
                Server.Transfer(@"..\Error.aspx");

            }
        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}