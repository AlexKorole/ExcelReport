﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Web;
using System.Web.UI;
using DevExpress.Web.ASPxEditors;
using System.Web.SessionState;
using System.Web.UI.WebControls;
using ExcelExport;
using dll_DataLayer;
using System.Data;
using System.Data.OracleClient;
using SerializeObj;

namespace ExcelReportingAdmin.ASPBackend
{
    public class ViewReportBackEnd
    {
        public static List<Control> AddDynamicControls(string con, HiddenField serverParamsName, HiddenField serverParamsViewName, HiddenField serverParamsType, HiddenField maxval, HiddenField minval, HttpSessionState Session, string queryPath, string curUser)
        {
            //divParams.Controls
            List<Control> contr = null;
            if (serverParamsName.Value.Length > 0)
            {
                contr = new List<Control>();
                if (Session[SessionNames.CurrentReportName] != null)
                {
                    var reportname = Session[SessionNames.CurrentReportName].ToString();
                    var name = new ASPxLabel();
                    name.Font.Bold = true;
                    name.Text = reportname;
                    contr.Add(name);
                }
                contr.Add(new LiteralControl("<table>"));
                contr.Add(new LiteralControl("<tr>"));
                var viewNames = serverParamsViewName.Value.Split(';');
                var types = serverParamsType.Value.Split(';');
                var names = serverParamsName.Value.Split(';');
                var maxVals = maxval.Value.Split(';');
                var minVals = minval.Value.Split(';');

                if (viewNames.Length == 1)
                {
                    contr.Add(new LiteralControl("<td valign = top>"));
                    addOneParam(Common.loadUserCon(Session), names[0], viewNames[0], types[0], maxVals[0], minVals[0], contr, queryPath, curUser);
                    contr.Add(new LiteralControl("</td>"));
                }
                else
                {
                    for (int i = 0; i < viewNames.Length; i++)
                    {
                        var vn = viewNames[i];
                        var type = types[i];
                        var name = names[i];
                        if (name.ToUpper() != "USERID")
                        {
                            contr.Add(new LiteralControl("<td valign = top>"));
                            addOneParam(Common.loadUserCon(Session), name, vn, type, maxVals[i], minVals[i], contr, queryPath, curUser);
                            i++;
                            if (i < viewNames.Length && names[i].ToUpper() != "USERID")
                            {
                                vn = viewNames[i];
                                type = types[i];
                                name = names[i];
                                addOneParam(Common.loadUserCon(Session), name, vn, type, maxVals[i], minVals[i], contr, queryPath, curUser);
                            }
                            contr.Add(new LiteralControl("</td>"));
                        }
                    }
                }
                contr.Add(new LiteralControl("</tr>"));
                contr.Add(new LiteralControl("</table>"));
                Session[SessionNames.divParamsControls] = contr;
            }
            return contr;
        }

        public static void addOneParam(DBConnection conConfig, string name, string viewname, string type, string maxval, string minval, List<Control> contr, string queryPath, string curUser)
        {
            var l = new ASPxLabel();
            l.Value = viewname;
            contr.Add(l);

            switch (type)
            {
                case "DateTime":
                    var d = new ASPxDateEdit();
                    d.ID = name;
                    d.ClientInstanceName = name;
                    d.Width = 200;
                    addMaxMinDate(conConfig, maxval, minval, contr, d);
                    contr.Add(d);
                    break;
                case "Number":
                    var d3 = new ASPxSpinEdit();
                    d3.ID = name;
                    d3.ClientInstanceName = name;
                    d3.Width = 200;
                    contr.Add(d3);
                    break;
                case "StrList":
                    var d4 = new ASPxComboBox();
                    d4.ID = name;
                    d4.ClientInstanceName = name;
                    d4.Width = 200;
                    addListStr(conConfig, maxval, minval, d4.Items, queryPath, curUser);
                    if (d4.Items != null && d4.Items.Count > 0)
                        d4.SelectedIndex = 0;
                    contr.Add(d4);
                    break;
                case "StrMulti":
                    var d5 = new ASPxListBox();
                    d5.SelectionMode = ListEditSelectionMode.CheckColumn;
                    d5.ID = name;
                    d5.ClientInstanceName = name;
                    d5.Width = 200;
                    addListStr(conConfig, maxval, minval, d5.Items, queryPath, curUser);

                    if (d5.SelectedIndex == -1)
                    {
                        if (string.IsNullOrEmpty(maxval))
                        {
                            if (d5.Items != null && d5.Items.Count > 0) d5.SelectedIndex = 0;
                        }
                    }

                    contr.Add(d5);
                    break;
                default:
                    var d1 = new ASPxTextBox();
                    d1.ID = name;
                    d1.ClientInstanceName = name;
                    d1.Width = 200;
                    contr.Add(d1);
                    break;
            }
        }

        private static void addListStr(DBConnection conConfig, string maxval, string minval, ListEditItemCollection d, string queryPath, string curUser)
        {
            var s = new Storage(HttpContext.Current.Cache, conConfig.value);
            var bt = FillData(minval, queryPath, s, conConfig, curUser);
            //var btSelect = FillData(maxval, queryPath, s, conConfig);
            foreach (DataRow el in bt.Rows)
            {
                var added = bt.GetValueStringAnyRow(1,el);
                var is_selected = false;

                if (bt.Columns.Count > 2)
                {
                    var intSel = bt.GetValueStringAnyRow(2, el);
                    is_selected = intSel == "1";
                }

                //foreach (DataRow el_select in btSelect.Rows)
                //{
                //    var sel = btSelect.GetValueStringAnyRow(1, el_select);
                //    if (sel == added)
                //    {
                //        is_selected = true;
                //        break;
                //    }
                //}

                var elem = new ListEditItem(added);
                elem.Selected = is_selected;
                d.Add(elem);
            }
        }

        private static BaseTable FillData(string query, string queryPath, Storage s, DBConnection conConfig, string curUser)
        {
            var bt = new BaseTable();
            string err;
            var conOra = s.Connection(out err, conConfig.type);
            using (conOra)
            {
                bt.setConAndPath(queryPath, conOra);
                if (query.Length > 0 && (query != "undefined") && bt.Rows.Count == 0)
                {
                    List<DbParameter> param = null;
                    param = SetUserID(ref query, conConfig, curUser);
                    bt.Load(query, param, typeof(Enums.UNKNOWN), true);
                }
            }
            return bt;
        }

        private static List<DbParameter> SetUserID(ref string query, DBConnection conConfig, string curUser)
        {
            List < DbParameter > ret = null;
            if (query.ToUpper().Contains(":USERID"))
            {
                switch (conConfig.type)
                {
                    case "Terradata":
                        query = String.Format(query.ToUpper().Replace(":USERID","'{0}'"), curUser);
                        break;
                    default:
                        query = query.ToUpper();
                        ret = new List<DbParameter>();
                        ret.Add(Queries.addParam(OracleType.VarChar, curUser, ":USERID"));
                        break;
                }
            }
            return ret;
        }

        private static void addMaxMinDate(DBConnection conConfig, string maxval, string minval, List<Control> contr, ASPxDateEdit d)
        {
            BaseDataReader reader = new BaseDataReader(conConfig, false);
            if (maxval.Length > 0 && (maxval != "undefined"))
            {
                var maxd = reader.LoadDateFromDB(maxval);
                var lm = new ASPxLabel();
                lm.Value = ". Макс: " + maxd.ToString("dd.MM.yyyy");
                d.MaxDate = maxd;
                contr.Add(lm);
            }

            if (minval.Length > 0 && (minval != "undefined"))
            {
                var mind = reader.LoadDateFromDB(minval);
                var lmin = new ASPxLabel();
                lmin.Value = "; Мин:" + mind.ToString("dd.MM.yyyy");
                d.MinDate = mind;
                contr.Add(lmin);
            }
        }
    }
}