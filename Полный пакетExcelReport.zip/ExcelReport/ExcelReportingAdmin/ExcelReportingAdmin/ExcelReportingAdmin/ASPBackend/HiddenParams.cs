﻿using System.Collections.Generic;
using System.Web.UI.WebControls;
using SerializeObj;
using System.Data.OracleClient;

namespace ExcelReportingAdmin.ASPBackend
{
    public class HiddenParams
    {
        public HiddenField serverParamsName;
        public HiddenField serverParamsViewName;
        public HiddenField serverParamsType;
        public HiddenField serverParamsMinVal;
        public HiddenField serverParamsMaxVal;
        
        public static void FillParams(HiddenParams sP, List<ElParam> paramList)
        {
            foreach (var p in paramList)
            {
                sP.serverParamsName.Value += p.Name + ";";
                sP.serverParamsViewName.Value += p.ViewName + ";";
                sP.serverParamsType.Value += OracleToNameTypes(p.Type) + ";";
                sP.serverParamsMinVal.Value += p.MinValQuery + ";";
                sP.serverParamsMaxVal.Value += p.MaxValQuery + ";";
            }
            sP.serverParamsName.Value = sP.serverParamsName.Value.Remove(sP.serverParamsName.Value.Length - 1);
            sP.serverParamsViewName.Value = sP.serverParamsViewName.Value.Remove(sP.serverParamsViewName.Value.Length - 1);
            sP.serverParamsType.Value = sP.serverParamsType.Value.Remove(sP.serverParamsType.Value.Length - 1);
            sP.serverParamsMinVal.Value = sP.serverParamsMinVal.Value.Remove(sP.serverParamsMinVal.Value.Length - 1);
            sP.serverParamsMaxVal.Value = sP.serverParamsMaxVal.Value.Remove(sP.serverParamsMaxVal.Value.Length - 1);
        }

        private static string OracleToNameTypes(OracleType type)
        {
            string ret = string.Empty;
            switch (type)
            {
                case OracleType.NVarChar: ret = "String"; break;
                case OracleType.DateTime: ret = "DateTime"; break;
                case OracleType.Number: ret = "Number"; break;
                // заглушка, т.к. все построенно на OracleType, а у него нет типа List
                case OracleType.Cursor: ret = "StrList"; break;
                case OracleType.LongRaw: ret = "StrMulti"; break;
                default: ret = "String"; break;
            }
            return ret;
        }

        private static OracleType NameToOracleTypes(string type)
        {
            OracleType ret = OracleType.NVarChar;
            switch (type)
            {
                case "String": ret = OracleType.NVarChar; break;
                case "DateTime": ret = OracleType.DateTime; break;
                case "Number": ret = OracleType.Number; break;
                // заглушка, т.к. все построенно на OracleType, а у него нет типа List
                case "StrList": ret = OracleType.Cursor; break;
                case "StrMulti": ret = OracleType.LongRaw; break;
            }
            return ret;
        }


        public List<ElParam> SaveParameters()
        {
            List<ElParam> parameters = null;
            var pnames = serverParamsName.Value.Split(';');
            var pviewnames = serverParamsViewName.Value.Split(';');
            var ptypes = serverParamsType.Value.Split(';');
            var pminval = serverParamsMinVal.Value.Split(';');
            var pmaxval = serverParamsMaxVal.Value.Split(';');

            if (pnames.Length > 0)
            {
                parameters = new List<ElParam>();
                for (int i = 0; i < pnames.Length; i++)
                {
                    var pr = new ElParam();
                    pr.Name = pnames[i];
                    pr.ViewName = pviewnames[i];
                    pr.Type = NameToOracleTypes(ptypes[i]);
                    pr.MinValQuery = pminval[i];
                    pr.MaxValQuery = pmaxval[i];
                    parameters.Add(pr);
                }
            }
            return parameters;
        }
    }
}