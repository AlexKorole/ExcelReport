﻿function Load() {
    $("#tReportsNameClient").empty();
    $("#tReportsNameClient").append(MakeReportNameList());

    var url = document.location.href;
    var start = url.indexOf('report' + '=');
    if (start != -1) {
        OpenViewReport();
    }
    else {
    }
}

function MakeReportNameList() {
    var addStr = "";
    var arr = $("#hdnReportListClient").val().split(";");
    for (var i = 0; i < arr.length; i++) {
        var url = document.location.href;
        addStr += "<tr><td><a href='" + url.substring(0, url.indexOf('?')) + "?report=" + encodeURIComponent(arr[i]) + "'>" + arr[i] + "</a></td><tr>";
    }
    return addStr;
}

function OpenViewReport() {
    var arr = new window.Array(
    "",
    $("#hdnServerParamsNameCl").val(),
    $("#hdnServerParamsViewNameCl").val(),
    $("#hdnServerParamsTypeCl").val(),
    $("#hdnServerParamsMinValCl").val(),
    $("#hdnServerParamsMaxValCl").val(),
    $("#hdnServerReportNameCl").val(),
    $("#hdnTemplateRowNum").val(),
    $("#hdnTemplSheetName").val()
    );
    // window.showModalDialog("ViewReport.aspx", arr, "dialogHeight:600px;dialogWidth:800px; scroll:no;status:no");
    //window.showModelessDialog("ViewReportLong.aspx", arr, "dialogHeight:0px;dialogWidth:0px; scroll:no;status:no");
    window.arr = arr;
    //window.open("ViewReportLong.aspx", "_blank");
    //window.open("ViewReportLong.aspx" + "?arr=" + encodeURIComponent(arr.join('~')), "_self");
    window.open("ViewReportLong.aspx", "_self");
    document.cookie = "clientParam=" + encodeURIComponent(arr.join('~'));
}