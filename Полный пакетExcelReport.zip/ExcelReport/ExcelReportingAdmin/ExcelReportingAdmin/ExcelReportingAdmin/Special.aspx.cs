﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Globalization;
using System.Web;
using ExcelReportingAdmin.ASPBackend;
using SerializeObj;
using System.IO;

namespace ExcelReportingAdmin
{
    public partial class Special : System.Web.UI.Page
    {
        string c_filenme = System.Configuration.ConfigurationManager.AppSettings["ClientFileName"];

        private HiddenParams InitHiddenParams()
        {
            var sP = new HiddenParams();
            sP.serverParamsName = hdnServerParamsNameCl;
            sP.serverParamsViewName = hdnServerParamsViewNameCl;
            sP.serverParamsType = hdnServerParamsTypeCl;
            sP.serverParamsMinVal = hdnServerParamsMinValCl;
            sP.serverParamsMaxVal = hdnServerParamsMaxValCl;
            return sP;
        }

        private string InitData()
        {
            string errMess;
            string query;
            var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
            ClientsBackEnd.initFile(con, query, c_filenme, hdnReportListClient, Session, Request.LogonUserIdentity.Name, out errMess, Request.PhysicalApplicationPath);
            var repDict = Session[SessionNames.currentElements] as Dictionary<string, Element>;
            return errMess;
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //lblError.Text = System.Diagnostics.Process.GetCurrentProcess().Id.ToString();
            string errMess = string.Empty;
            try
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
                if (!IsPostBack && Request.QueryString.Count == 0)
                {
                    errMess = InitData();
                    //hdnFileName.Value = c_filenme;
                }
                else
                {
                    if (Session[SessionNames.currentElements] == null)
                        errMess = InitData();
                    var sP = InitHiddenParams();
                    ClientsBackEnd.loadElement(hdnTemplateRowNum, hdnTemplSheetName, serverSecurityClient, sP, Request, Session);
                }
                if (string.IsNullOrEmpty(hdnReportListClient.Value))
                    hdnReportListClient.Value = Session[SessionNames.hdnReportList] is string ? Session[SessionNames.hdnReportList].ToString() : "";
                lblError.Text = errMess;
            }
            catch (Exception err)
            {
               lblError.Text = err.Message;
               Logger.Log.Inst.ErrorToLog(err,
                           HttpContext.Current.Request.LogonUserIdentity.Name, "Функция Page_Load", null, "Ошибка инициализации special.aspx!");
            }
        }
    }
}