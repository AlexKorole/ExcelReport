﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.OracleClient;
using System.IO;
using System.Threading;
using System.Globalization;
using ExcelReportingAdmin.ASPBackend;
using SerializeObj;
using CheckAccess;
using ExcelExport;
using System.Web.Services;
using FileInfo;

namespace ExcelReportingAdmin
{
    public partial class Admin : System.Web.UI.Page
    {
        public static readonly string const_TemplatePath = System.Configuration.ConfigurationManager.AppSettings["ExcelTemplatesPath"];

        private void ClearAll()
        {
            serverQuery.Value = "";
            serverParamsName.Value = "";
            serverParamsViewName.Value = "";
            serverParamsType.Value = "";
            serverParamsMinVal.Value = "";
            serverParamsMaxVal.Value = "";
            serverSecurity.Value = "";
            serverReportName.Value = "";
            //hdnReportList.Value = "";
            //clearReportPart.Value = "0";
        }

        private HiddenParams InitHiddenParams()
        {
            var sP = new HiddenParams();
            sP.serverParamsName = serverParamsName;
            sP.serverParamsViewName = serverParamsViewName;
            sP.serverParamsType = serverParamsType;
            sP.serverParamsMinVal = serverParamsMinVal;
            sP.serverParamsMaxVal = serverParamsMaxVal;
            return sP;
        }

        static object locker = new object();
        private static bool SaveDataToDB(string fileName)
        {
            var isok = true;
            var repName = HttpContext.Current.Session[SessionNames.CurrentReportName];
            var lparam = new OracleParameterCollection();
            var tableName = System.Configuration.ConfigurationManager.AppSettings["utl_reports_log"];
            var query = "insert into " + tableName + " (save_date, save_user, data) values (:v_save_date, :v_save_user, :v_data)";
            try
            {
                var res = string.Empty;
                lock (locker)
                {
                    var file = File.OpenText(System.Configuration.ConfigurationManager.AppSettings["SourceDir"] + fileName + ".xml");
                    res = file.ReadToEnd();
                    file.Close();
                }

                var dr = new BaseDataReader(Common.loadSystemCon(HttpContext.Current.Session), false);
                lparam.Add(BaseDataReader.addParam(OracleType.DateTime, DateTime.Now, "v_save_date"));
                lparam.Add(BaseDataReader.addParam(OracleType.VarChar, HttpContext.Current.Request.LogonUserIdentity.Name, "v_save_user"));
                lparam.Add(BaseDataReader.addParam(OracleType.Clob, res, "v_data"));
                string err;
                dr.ExecNonQuery(query, null, out err, lparam, false, HttpContext.Current.Request.LogonUserIdentity.Name, 
                                Common.loadSystemCon(HttpContext.Current.Session).value,
                                repName != null ? repName.ToString() : "Отчет не известен! Функция SaveDataToDB!");
                if (err.Length > 0) isok = false;
            }
            catch(Exception e)
            {
                isok = false;
                Logger.Log.Inst.ErrorToLog(e,
                                           HttpContext.Current.Request.LogonUserIdentity.Name,
                                           query, lparam, repName != null ? repName.ToString() : "Отчет не известен! Функция SaveDataToDB!");
            }
            return isok;
        }

        private bool SaveChanges(string curname, Dictionary<string, Element> elements)
        {
            var isnameChange = false;
            var elem = elements[curname];
            if (elem.name != serverReportName.Value)
            {
                elem.name = serverReportName.Value;
                isnameChange = true;
            }

            if (hdnIsStoredProcFlag.Value == "stored")
                elem.IsStoredProcedure = true;
            else elem.IsStoredProcedure = false;
            elem.query = serverQuery.Value;
            elem.SecurityGroup = serverSecurity.Value;
            var sP = InitHiddenParams();
            elem.paramList = sP.SaveParameters();

            AdminBackEnd.SerializeChanges(elements, dlFiles.SelectedValue);
            SaveDataToDB(dlFiles.SelectedValue);
            if (isnameChange)
            {
                string query;
                var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
                string errMsg;
                AdminBackEnd.initFile(con, query, dlFiles.SelectedValue, hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            }
            return isnameChange;
        }

        

        //--Events-----------------------------------------------------------------------
        
        protected void Page_Load(object sender, EventArgs e)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            //в случае с терадатой используем таблицу доступа в той же базе.
            DBConnection con = Common.loadUserCon(Session);
            if (con.type != "Terradata")
                con = Common.loadSystemCon(Session);

            string query;
            string errMsg = checkAccess(out query, con);

            if (!IsPostBack && Request.QueryString.Count == 0)
            {
                var files = AdminBackEnd.LoadFiles(Session, dlFiles);
                AdminBackEnd.initFile(con, query, files[0], hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
                //тестовый
                //dlFiles.SelectedIndex = 1;
                //AdminBackEnd.initFile(con, query, files[1], hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            }
            if (hdnReportList.Value == string.Empty && Session[SessionNames.hdnReportList] == null) Response.Redirect("AccessDenied.htm");
            HiddenParams sP = InitHiddenParams();
            AdminBackEnd.loadElement(hdnIsStoredProcFlag, serverQuery, hdnTemplateRowNum, hdnTemplSheetName, serverSecurity, sP, Request, Session, Server);
            if (string.IsNullOrEmpty(hdnReportList.Value))
                hdnReportList.Value = Session[SessionNames.hdnReportList] is string ? Session[SessionNames.hdnReportList].ToString() : "";

            if (dlFiles.DataSource == null && dlFiles.SelectedIndex == -1 && Session[SessionNames.files] is string[])
            {
                dlFiles.DataSource = Session[SessionNames.files] as string[];
                dlFiles.DataBind();
                if (Session[SessionNames.FilesSelectedIndex] is int)
                    dlFiles.SelectedIndex = (int)Session[SessionNames.FilesSelectedIndex];
            }
            setTemplate();

            //var paramList = new List<ElParam>();
            //var p1 = new ElParam("ppp", "Параметр", System.Data.OracleClient.OracleType.NVarChar, "select 1", "select 2");
            //paramList.Add(p1);
            //var el = new Element("Выдача карт", "вклады", paramList, false, "1.05.10 Специальные - Отчет по численности клиентских менеджеров МВС");

            //var elemList = new List<Element>();
            //elemList.Add(el);

            //var serialize = new XmlSerializer(typeof(List<Element>));
            //var wfs = new StreamWriter(@"C:\Temp\storage\test4.xml");
            //serialize.Serialize(wfs, elemList);
            //wfs.Close();

            //tvNav

            //var rf = new FileStream(testfile, FileMode.Open, FileAccess.Read, FileShare.Read);
            //var serialize = new XmlSerializer(typeof(List<Element>));
            //List<Element> elemList = (List<Element>)serialize.Deserialize(rf);
        }

        private string checkAccess(out string query, DBConnection con)
        {
            
            query = FilePersister.ExecAccessFunc(File.ReadAllText, Request.PhysicalApplicationPath + @"SQL\Access.txt");
            var acctable = System.Configuration.ConfigurationManager.AppSettings["AccessTable"];
            query = query.Replace("@AccessTable", acctable);
            string errMsg;
            Access acc = new Access();
            errMsg = Common.setSecurity(con, query, acc, Request.LogonUserIdentity.Name, Response,
                Request.PhysicalApplicationPath);
            return errMsg;
        }

        private void setTemplate()
        {
            if (Session[SessionNames.CurrentReportName] != null)//!string.IsNullOrEmpty(serverReportName.Value))
            {
                var shortName = Common.MakeShortName(Session[SessionNames.CurrentReportName].ToString());
                var filename = const_TemplatePath + shortName + ".xlsx";
                if (FilePersister.ExistsTemplate(filename))
                    hdnTemplateName.Value = shortName + ".xlsx";
            }

            if (string.IsNullOrEmpty(hdnTemplateName.Value))
            {
                btnLoadTemplate.Visible = false;
                //btnDelTemplate.Visible = false;
            }
            else
            {
                btnLoadTemplate.Visible = true;
                //btnDelTemplate.Visible = true;
            }
        }

        protected void dlFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Для терадаты берем данные непосредственно из неё
            string query;
            var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
            string errMsg;

            AdminBackEnd.initFile(con, query, dlFiles.SelectedValue, hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            Session[SessionNames.FilesSelectedIndex] = dlFiles.SelectedIndex;
            clearReportPart.Value = "1";
            hdnTemplSheetName.Value = "";
        }

        protected void hdnSave_Click(object sender, EventArgs e)
        {
            // Для терадаты берем данные непосредственно из неё
            string query;
            var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
            string errMsg;
            AdminBackEnd.initFile(con, query, dlFiles.SelectedValue, hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            if (Session[SessionNames.CurrentReportName] != null && Session[SessionNames.currentElements] != null)
            {
                var curname = Session[SessionNames.CurrentReportName].ToString();
                // Здесь нельзя барть занчение из serverReportName.Value т.к. тогда не переименовать отчет!
                //if (!string.IsNullOrEmpty(serverReportName.Value))
                //    curname = serverReportName.Value;
                
                var elements = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                if (!elements.ContainsKey(curname)) return;

                int rownum;
                if (int.TryParse(hdnTemplateRowNum.Value, out rownum))
                {
                    var el = elements[curname];
                    el.rowNumInTemplate = rownum;
                    el.TemplSheetName = hdnTemplSheetName.Value;
                }
                SaveChanges(curname, elements);
            }
        }

        protected void btnAddNewReport_Click(object sender, EventArgs e)
        {
            ClearAll();
            Session[SessionNames.CurrentReportName] = null;

            // Для терадаты берем данные непосредственно из неё
            string query;
            var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
            string errMsg;
            AdminBackEnd.initFile(con, query, dlFiles.SelectedValue, hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);

            //if (Session[SessionNames.hdnReportList] != null)
            {
                var reportlist = Session[SessionNames.hdnReportList].ToString();
                var elements = Session[SessionNames.currentElements] as Dictionary<string, Element>;

                int i = 0;
                if (elements != null)
                    while (elements.ContainsKey("Новый отчет " + i)) { i++; }
                else elements = new Dictionary<string, Element>();
                var newreportName = "Новый отчет " + i;
                reportlist += ";" + newreportName;
                
                var elem = new Element();
                elem.name = newreportName;
                elements.Add(newreportName, elem);
                serverReportName.Value = newreportName;
                Session[SessionNames.CurrentReportName] = newreportName;
                hdnReportList.Value = reportlist;

                Session[SessionNames.hdnReportList] = reportlist;
                SaveChanges(newreportName, elements);
            }
        }

        protected void btnDelRep_Click(object sender, EventArgs e)
        {
            string query;
            var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
            string errMsg;
            AdminBackEnd.initFile(con, query, dlFiles.SelectedValue, hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            
            //if (Session[SessionNames.CurrentReportName] != null && Session[SessionNames.hdnReportList] != null)
            {
                ClearAll();
                var reportlist = Session[SessionNames.hdnReportList].ToString();
                var elements = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                var curreport = Session[SessionNames.CurrentReportName].ToString();
                if (elements.ContainsKey(curreport))
                {
                    elements.Remove(curreport);
                    reportlist = reportlist.Replace(";" + curreport, "").Replace(curreport,"");
                    hdnReportList.Value = reportlist;
                    Session[SessionNames.hdnReportList] = reportlist;
                    Session[SessionNames.CurrentReportName] = null;
                    serverReportName.Value = "";
                    AdminBackEnd.SerializeChanges(elements, dlFiles.SelectedValue);
                    SaveDataToDB(dlFiles.SelectedValue);
                }
            }
        }

        protected void btnAddFile_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(tFileName.Text))
            {
                var elements = new Dictionary<string, Element>();
                AdminBackEnd.SerializeChanges(elements, tFileName.Text);
                SaveDataToDB(dlFiles.SelectedValue);
                var files = AdminBackEnd.LoadFiles(Session, dlFiles);
                string query;
                var con = Common.PrepareBeforeCheckAccess(Session, Request.PhysicalApplicationPath, out query);
                string errMsg;
                AdminBackEnd.initFile(con, query, files[0], hdnReportList, Session, Request.LogonUserIdentity.Name, out errMsg, Request.PhysicalApplicationPath);
            }
        }

        protected void ASPxUploadControl1_FileUploadComplete(object sender, DevExpress.Web.ASPxUploadControl.FileUploadCompleteEventArgs e)
        {
            if (!string.IsNullOrEmpty(serverReportName.Value))
            {
                try
                {
                    var shortName = Common.MakeShortName(serverReportName.Value);
                    var filename = const_TemplatePath + shortName + ".xlsx";
                    if (File.Exists(filename))
                        File.Delete(filename);
                    e.UploadedFile.SaveAs(filename);
                    e.CallbackData = "error=;value=" + shortName + ".xlsx";
                }
                catch (Exception err)
                {
                    e.CallbackData = "error=" + err.Message + ";value=";
                    Logger.Log.Inst.ErrorToLog(err,
                    HttpContext.Current.Request.LogonUserIdentity.Name, "Функция ViewReport.aspx:ASPxUploadControl1_FileUploadComplete", null, serverReportName.Value);
                }

            }
            else e.CallbackData = "error=Не задано имя отчета!;value=";
        }

        protected void btnLoadTemplate_Click(object sender, EventArgs e)
        {
            if (Session[SessionNames.CurrentReportName] != null)//!string.IsNullOrEmpty(serverReportName.Value))
            {
                var shortName = Common.MakeShortName(Session[SessionNames.CurrentReportName].ToString());
                var filename = const_TemplatePath + shortName + ".xlsx";
                var errorStr = UIHelper.SendResult(filename, false, Server.UrlEncode(shortName), ".xlsx", this.Context.Response, false);
                error.Value = errorStr;
            }
        }

        [WebMethod]
        public static string DeleteTemplateFile(string Ser_filename)
        {
            var s_filename = Uri.UnescapeDataString(Ser_filename);
            var error = string.Empty;
            if (HttpContext.Current.Session[SessionNames.CurrentReportName] != null)//!string.IsNullOrEmpty(serverReportName.Value))
            {
                try
                {
                    var shortName = Common.MakeShortName(HttpContext.Current.Session[SessionNames.CurrentReportName].ToString());
                    var filename = const_TemplatePath + shortName + ".xlsx";
                    if (File.Exists(filename))
                        File.Delete(filename);

                    var curname = HttpContext.Current.Session[SessionNames.CurrentReportName].ToString();
                    var elements = HttpContext.Current.Session[SessionNames.currentElements] as Dictionary<string, Element>;
                    if (elements.ContainsKey(curname))
                    {
                        var el = elements[curname];
                        el.rowNumInTemplate = 0;
                        el.TemplSheetName = string.Empty;
                    }
                    AdminBackEnd.SerializeChanges(elements, s_filename);
                    SaveDataToDB(s_filename);

                    //hdnTemplateName.Value = string.Empty;
                    //btnLoadTemplate.Visible = false;
                    //btnDelTemplate.Visible = false;
                } catch (Exception err)
                {
                    error = err.Message;
                    Logger.Log.Inst.ErrorToLog(err,
                    HttpContext.Current.Request.LogonUserIdentity.Name, "Функция Admin.aspx:DeleteTemplateFile", null, s_filename);
                }
            }
            return "error=" + error;
        }
    }
}