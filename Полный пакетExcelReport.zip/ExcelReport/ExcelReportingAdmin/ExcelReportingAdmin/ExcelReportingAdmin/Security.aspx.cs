﻿using System;
using System.Collections.Generic;
using System.IO;
using ExcelReportingAdmin.ASPBackend;

namespace ExcelReportingAdmin
{
    public partial class Security : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var listRead = Common.LoadUsersFromFile(Request.PhysicalApplicationPath);
            lbRead.DataSource = listRead;
            lbRead.DataBind();
        }

        protected void lbRead_Callback(object sender, DevExpress.Web.ASPxClasses.CallbackEventArgsBase e)
        {
            var arr = e.Parameter.Split(';');
            if (!(arr.Length > 1 && !string.IsNullOrEmpty(arr[1])))
                 return;
            var user = arr[1].ToUpper().Trim();
            if (!user.StartsWith("SZB-HQ\\"))
            {
                user = "SZB-HQ\\" + user;
            }
            
            if (e.Parameter.Contains("addNewUser;"))
            {
                var listUsers = new List<string>();
                listUsers.Add(user);
                File.AppendAllLines(Request.PhysicalApplicationPath + @"Security\Read.txt", listUsers);
            }

            if (e.Parameter.Contains("delUser;"))
            {
                var listDelRead = Common.LoadUsersFromFile(Request.PhysicalApplicationPath);
                listDelRead.Remove(user);
                File.WriteAllLines(Request.PhysicalApplicationPath + @"Security\Read.txt", listDelRead);
            }
            var listRead = Common.LoadUsersFromFile(Request.PhysicalApplicationPath);
            lbRead.DataSource = listRead;
            lbRead.DataBind();
        }
    }
}