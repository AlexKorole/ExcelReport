﻿function GetParamFromMParams(mparams, Name) {
    var retval = "";
    var ar = null;
    ar = mparams.split(Name + "=");
    if (ar != null && ar.length > 1) {
        var s2 = null;
        s2 = ar[1].split(';');
        if (s2 != null && s2.length > 0) {
            retval = s2[0];
        }
    }
    return retval;
}

function BeginTimer(guid) {
    var dateStart = new Date();
    var IntervalId = false;
    AjaxCheck();
    //IntervalId = window.setInterval(function () {
    function AjaxCheck() {
        var difInSeconds = Math.floor(((new Date()).getTime() - dateStart.getTime()) / 1000);
        var hours = Math.floor(difInSeconds / 3600);
        var minutes = Math.floor((difInSeconds - (hours * 3600)) / 60);
        var seconds = difInSeconds - (hours * 3600) - (minutes * 60);
        if (hours < 10) hours = "0" + hours;
        if (minutes < 10) minutes = "0" + minutes;
        if (seconds < 10) seconds = "0" + seconds;
        lblStatus.SetText("Waiting, data transfering... " + hours + ":" + minutes + ":" + seconds + ".&nbsp;");

        var $ajaxQ = $.ajax({
            type: "POST",
            async: false,
            url: "ViewReportLong.aspx/CheckStateLoad",
            data: "{'guid':'" + guid + "'}",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: onSuccessCheckStateLoad,
            error: onErrorCheckStateLoad
        });

        var noop = function () { };
        if ($ajaxQ != null) {
            $ajaxQ.onreadystatechange = $ajaxQ.abort = noop;
            $ajaxQ = null;
        }

        function onSuccessCheckStateLoad(result) {
            var error = GetParamFromMParams(result.d, "error");
            var iscompleted = GetParamFromMParams(result.d, "iscompleted");
            var rownum = GetParamFromMParams(result.d, "rownum");
            if (error.length > 0) {
                lblStatus.SetText(error);
                EnableAll();
                //clearInterval(IntervalId);
                IntervalId = true;
            } else {
                if (rownum)
                    lblRowNum.SetText("Rows = " + rownum);
                if (iscompleted == "true") {
                    if ($("#hRowNum"))  $("#hRowNum").val(rownum);
                    lblStatus.SetText("");
                    EnableAll();
                    //clearInterval(IntervalId);
                    IntervalId = true;
                    document.getElementById("hdnSave").click();
                } 
            }
            if (!IntervalId) setTimeout(AjaxCheck, 1000);
        }

        function onErrorCheckStateLoad(result) {
            alert("error " + result.responseText);
            lblStatus.SetText(result.responseText);
            EnableAll();
            //clearInterval(IntervalId);
            IntervalId = true;
            if (!IntervalId) setTimeout(AjaxCheck, 1000);
        }
    };
    //, 1000);
}

String.prototype.replaceAll = function (search, replace) {
    return this.split(search).join(replace);
}


function LoadByWebMethod() {
    var arrname = $("#serverParamsName").val();
    var arrtype = $("#serverParamsType").val();
    var arrval = $("#serverParamValues").val();
    var arrviewname = $("#serverParamsViewName").val();
    var serverQuery = $("#serverQuery").val();

    var jsonObj = new Object;
    jsonObj.serverParamsName = arrname;
    jsonObj.serverParamsViewName = arrviewname;
    jsonObj.serverParamsType = arrtype;
    jsonObj.serverParamsValue = arrval;
    jsonObj.hdnTemplateRowNum = $("#hdnTemplateRowNum").val();
    jsonObj.serverQuery = serverQuery;
    jsonObj.hdnTemplSheetName = $("#hdnTemplSheetName").val();

    var data = $.toJSON(jsonObj);
    //var data = "{'serverParamsName':'" + encodeURI(arrname) + "','serverParamsViewName':'" + encodeURI(arrviewname) +
    //    "','serverParamsType':'" + encodeURI(arrtype) +
    //    "','serverParamsValue':'" + encodeURIComponent(arrval.replaceAll("'","&oneQuot;")) +
    //    "','hdnTemplateRowNum':'" + encodeURI($("#hdnTemplateRowNum").val()) +
    //    "','serverQuery':'" + serverQueryJson +
    //    "','hdnTemplSheetName':'" + encodeURI($("#hdnTemplSheetName").val()) + "'}";

    $.ajax({
        type: "POST",
        async: false,
        url: "ViewReportLong.aspx/ExcelWebMethod",
        data: data,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessExcelWebMethod,
        error: onErrorExcelWebMethod
    });

    function onSuccessExcelWebMethod(result) {
        var error = GetParamFromMParams(result.d, "error");
        var guid = GetParamFromMParams(result.d, "guid");
        var procId = GetParamFromMParams(result.d, "procId");
        // procId нужен при тестировании приложения, чтобы увидеть ID текущего процесса
        if (procId.length > 0) alert(procId);
        if (error.length == 0 && guid.length > 0) {
//-----Включаем счетчик-------------------------------------------------
            BeginTimer(guid);
//----------------------------------------------------------------------
        }
        else {
            alert(error);
        }
    }

    function onErrorExcelWebMethod(result) {
        alert("error " + result.responseText);
        lblStatus.SetText(result.responseText);
        EnableAll();
    }
}


// Получаем названия колонок в базе и предлагаем заполнить их названиями для Excel
function LoadColumnsByWebMethod() {
    var arrname = $("#serverParamsName").val();
    var arrtype = $("#serverParamsType").val();
    var arrval = $("#serverParamValues").val();
    $("#btnGetColumns").disabled = true;

    var dateStart = new Date();
    var isfinish = "start";
    IntervalId = window.setInterval(function () {
        var cookie = getCookie('fileDownloadToken');
        if (isfinish == 'finished') {
            clearInterval(IntervalId);
        }
        else {
            var difInSeconds = Math.floor(((new Date()).getTime() - dateStart.getTime()) / 1000);
            var hours = Math.floor(difInSeconds / 3600);
            var minutes = Math.floor((difInSeconds - (hours * 3600)) / 60);
            var seconds = difInSeconds - (hours * 3600) - (minutes * 60);
            if (hours < 10) hours = "0" + hours;
            if (minutes < 10) minutes = "0" + minutes;
            if (seconds < 10) seconds = "0" + seconds;
            lblStatus.SetText("Подождите, идет загрузка... " + hours + ":" + minutes + ":" + seconds);
        }
    }, 1000);


    var arrviewname = $("#serverParamsViewName").val();
    $.ajax({
        type: "POST",
        async: true,
        url: "ViewReport.aspx/GetColumnsWebMethod",
        data: "{'serverParamsName':'" + encodeURI(arrname) + "','serverParamsViewName':'" + encodeURI(arrviewname) +
            "','serverParamsType':'" + encodeURI(arrtype) +
            "','serverParamsValue':'" + encodeURIComponent(arrval.replaceAll("'", "&oneQuot;")) + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessGetColumnsWebMethod,
        error: onErrorGetColumnsWebMethod
    });

    function onSuccessGetColumnsWebMethod(result) {
        lblStatus.SetText("");
        btnExcel.SetEnabled(true);
        $("#btnGetColumns").disabled = false;
        isfinish = 'finished';

        var f = $('table *');
        for (var i = 0; i < f.length; i++) {
            f[i].disabled = false;
        }

        var rress = decodeURIComponent(result.d);
        var error = GetParamFromMParams(rress, "error");
        var value = GetParamFromMParams(rress, "value");

        if (error.length == 0 && value.length > 0) {
            var tableStart = "<table rules='all' frame='border'>";
            var headerName = "<thead><tr><th>Колонка в базе</th><th>Колонка в excel</th></thead><tbody>";
            tableStart += headerName;
            var arrValue = value.split(':');
            for (var i = 0; i < arrValue.length; i++) {
                var smar = arrValue[i].split('=');
                tableStart += "<tr><td id='dCN_td" + i.toString() + "'>" + smar[0] + "</td><td> <input type='text' id='dCN_txt" + i.toString() + "' style='width:300px' value='" + (smar.length >= 2 ? smar[1] : "") + "'/></td></tr>";
            }
            var btn = "<tr><td align='center' colspan='2'><input id='btnSaveColumns' type='button' value='Сохранить колонки' onclick='BtnSaveColName();' /></td><tr>";
            tableStart += btn;
            var tableEnd = "</tbody></table>";
            tableStart += tableEnd;
            $("#divColumnNames").append(tableStart);
        }
        else {
            alert(error);
        }
    }

    function onErrorGetColumnsWebMethod(result) {
        lblStatus.SetText("");
        btnExcel.SetEnabled(true);
        $("#btnGetColumns").disabled = false;
        isfinish = 'finished';
        alert("error " + result.responseText);
    }
}

// Включаем все задизабленные элементы
function EnableAll() {
    btnExcel.SetEnabled(true);
    var f = $('table *');
    for (var i = 0; i < f.length; i++) {
        f[i].disabled = false;
    }
}


// Сохранение колонок для Excel
function BtnSaveColName() {
    var resToServer = "";
    var i = 0;
    while (true) {
        var elTd = $("#dCN_td" + i.toString());
        if (elTd.length == 0)
            break;
        else {
            var elTxt = $("#dCN_txt" + i.toString());
            if (elTxt.length > 0)
                resToServer += elTd.text() + "=" + elTxt.val() + ":";
        }
        i++;
        if (i > 10000) break;
    }
    resToServer = resToServer.substring(0, resToServer.length - 1);

    $.ajax({
        type: "POST",
        async: false,
        url: "ViewReport.aspx/BtnSaveColName",
        data: "{'columns':'" + encodeURI(resToServer) + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessBtnSaveColName,
        error: onErrorBtnSaveColName
    });

    function onSuccessBtnSaveColName(result) {
        var error = GetParamFromMParams(result.d, "error")
        if (error.length > 0)
            alert("error: " + error);
        else {
            alert("Названия колонок успешно сохраненны!");
        }
        EnableAll();
    }

    function onErrorBtnSaveColName(result) {
        alert("error " + result.responseText);
        EnableAll();
    }
}

function btnDelTemplate_Click() {
    $.ajax({
        type: "POST",
        async: true,
        url: "Admin.aspx/DeleteTemplateFile",
        data: "{'Ser_filename':'" + encodeURI($("#dlFiles").val()) + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: onSuccessDeleteTemplateFileWebMethod,
        error: onErrorDeleteTemplateFileWebMethod
    });

    function onSuccessDeleteTemplateFileWebMethod(result) {
        var error = GetParamFromMParams(result.d, "error")
        if (error.length > 0)
            alert("error: " + error);
        else {
            clearTemplate();
            txtRowNum.SetValue(0);
            $("#txtTemplSheetName").val("");
        }
    }

    function onErrorDeleteTemplateFileWebMethod(result) {
        alert("error " + result.responseText);
    }
}

function clearTemplate() {
    $("#hdnTemplateName").val("");
    $("#lblTek").text($("#hdnTemplateName").val());
    $("#btnLoadTemplate").hide();
    $("#btnDelTemplate").hide();

    $("#hdnTemplateRowNum").val("");
}

