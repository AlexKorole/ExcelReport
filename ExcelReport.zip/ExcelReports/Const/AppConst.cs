﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Const
{
    public class AppConst
    {
        private static readonly string _getSysQuery = @"select query from {0} where name = :v_name";

        public static readonly string GetSysQuery = String.Format(_getSysQuery,
            System.Configuration.ConfigurationManager.AppSettings["QueryTable"]);

        public const string InsertRep = "InsertRep";
        public const string UpdateRep = "UpdateRep";
        public const string CheckRep = "CheckRep";
        public const string DeleteParam = "DeleteParam";
        public const string InsertParam = "InsertParam";
        public const string DeleteRep = "DeleteRep";
        public const string LoadAllRep = "LoadAllRep";
        public const string NewRep = "Новый отчет ";
        public const string LoadOne = "LoadOne";
        public const string LoadParams = "LoadParams";
    }
}
