﻿function ModAdm() {
    this.ParamList;
    this.SecurityGroup;
    this.Name;
    this.Query;
    this.RowNumInTemplate;
    this.TemplSheetName;
    this.IsStoredProcedure;
}

ModAdm.GetCntr = function() {
    var report = new ModAdm();
    var params = new Array();

    if ($("#rId").val() == "") report.Id = -1;
    else report.Id = $("#rId").val();

    if ($("#tblParams")) {
        $("#tblParams>tbody>tr").each(function () {
            var elem = new Object();
            elem.Id = this.id.replaceAll("trId", "");
            elem.Name = this.cells[0].innerText;
            elem.ViewName = $("input", this.cells[1]).val();
            elem.StrType = $("select", this.cells[2]).val();
            elem.MinValQuery = $("input", this.cells[3]).val();
            elem.MaxValQuery = $("input", this.cells[4]).val();
            params.push(elem);
        });
    }
    report.ParamList = params;
    report.SecurityGroup = $("#SecurityGroup").val();
    report.Name = $("#Name").val();
    report.Query = $("#Query").val();

    report.RowNumInTemplate = $("#RowNumInTemplate").val();
    report.TemplSheetName = $("#TemplSheetName").val();
    report.IsStoredProcedure = $('#cbIsStroedProc').is(":checked");

    return report;
}

ModAdm.SetCntr = function (data) {
    $("#rId").val(data.Id);
    $("#Name").val(NullToEmp(data.Name));
    $("#SecurityGroup").val(NullToEmp(data.SecurityGroup));
    $("#Query").val(NullToEmp(data.Query));
    if (data.ParamList != null)
        ModAdm.MakeParamListFromServer(data.ParamList);

    $("#lblTek").text(NullToEmp(data.TemplateName));
    $("#TemplSheetName").val(NullToEmp(data.TemplSheetName));
    $("#RowNumInTemplate").val(NullToEmp(data.RowNumInTemplate));
    $('#cbIsStroedProc')[0].checked = data.IsStoredProcedure;
}

ModAdm.MakeParamListFromServer = function (data) {
    $("#tdParams").empty();
    var addStr = "<table id='tblParams'>";
    var headerName = "<thead><tr><th>Параметр</th><th>Название</th><th>Тип</th><th>Min значение</th><th>Max значение</th></tr></thead><tbody>";
    addStr += headerName;

    $.each(data, function (key, item) {
        var name = "<td>" + item.Name + "</td>";
        var viewname = "<td><input type='text' value='" + item.ViewName + "'></input></td>";
        var type = "<td><select><option " + (item.StrType == "String" ? "selected" : "") + ">String</option><option " + (item.StrType == "DateTime" ? "selected" : "") + ">DateTime</option><option " + (item.StrType == "Number" ? "selected" : "") + ">Number</option><option " + (item.StrType == "StrList" ? "selected" : "") + ">StrList</option><option " + (item.StrType == "StrMulti" ? "selected" : "") + ">StrMulti</option></select></td>";
        var minval = '<td><input type="text" value="' + (item.MinValQuery ? item.MinValQuery.replaceAll('\"', '&quot;') : "") + '"></input></td>';
        var maxval = '<td><input type="text" value="' + (item.MaxValQuery ? item.MaxValQuery.replaceAll('\"', '&quot;') : "") + '"></input></td>';
        addStr += "<tr id = 'trId" + item.Id + "'>" + name + viewname + type + minval + maxval + "</tr>";
    });

    addStr += "</tbody>";
    addStr += "</table>";
    $("#tdParams").append(addStr);
}

ModAdm.ClearCntr = function () {
    $("#rId").val('-1');
    $("#Name").val('');
    $("#SecurityGroup").val('');
    $("#Query").val('');
    $("#tdParams").empty();
    $("#lblTek").text('');
    $("#TemplSheetName").val('');
    $("#RowNumInTemplate").val('');
    $('#cbIsStroedProc')[0].checked = false;
}

ModAdm.ClearTemplate = function () {
    $("#lblTek").text('');
    $("#TemplSheetName").val('');
    $("#RowNumInTemplate").val('');
}

ModAdm.SetAccordion = function (data) {
    $("#products").empty();
    $.each(data, function (key, item) {
        var btn = "<button id='accBtn" + item.Id + "' class='btnRepL' onclick='Load(" + item.Id + ")'>" + item.Name + "</button>";
        $('#products').append(btn);
        $('<br/>').appendTo($('#products'));
    });
}

ModAdm.ChangeAccRepName = function (id, newName) {
    $('#accBtn' + id).html(newName);
}

