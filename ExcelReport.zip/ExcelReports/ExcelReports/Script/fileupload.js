﻿$(document).ready(function () {
    $('#jqxFileUpload').jqxFileUpload({ width: 300, uploadUrl: '../api/Admin', fileInputName: 'fileToUpload' });

    $('#jqxFileUpload').on('uploadEnd', function (event) {
        var args = event.args;
        var fileName = args.file;
        var serverResponse = args.response;
        $("#lblTek").text(fileName);
        
    });

    $('#jqxFileUpload').on('uploadStart', function (event) {
        var fileName = event.args.file;
    });
});






