﻿var uri = 'api/Admin';

function Load(id) {
    $.getJSON(uri, { id: id })
        .done(function(data) {
            ModAdm.ClearCntr();
            ModAdm.SetCntr(data);
    });
}

$(document).ready(function() {
    $.getJSON(uri)
        .done(function(data) {
            ModAdm.SetAccordion(data);
    });
});

function btnSaveClick() {
    document.getElementById("btnViewReport").disabled = false;
    var report = ModAdm.GetCntr();

    ModAdm.ChangeAccRepName(report.Id, report.Name);

    $('#btnSave').css('background', 'red');

    $.ajax(
    {
        url: uri,
        type: 'PUT',
        dataType: 'json',
        data: report,
        success: function(data, textStatus, xhr) {
            $('#btnSave').css('background', '#D6D3CE');
        },
        error: function(xhr, textStatus, errorThrown) {
            
        }
    });
}

function btnDelTemplate_Click() {
    var del = new Object();
    del.Id = 5;
    $.ajax(
           {
               url: uri + "/DeleteExcelTemplate/" + 5,
               type: 'DELETE',
               success: function () {
                   ModAdm.ClearTemplate();
               },
               error: function (x, y, z) {
                   alert(x + '\n' + y + '\n' + z);
               }
           });
}

function ParseText() {
    document.getElementById("btnViewReport").disabled = true;
    var s = $("#Query").val();
    //quickExpr = /:[A-Za-z]\w+/gim; без пробела
    quickExpr = / :\w+/gim;
    match = s.match(quickExpr);
    
    var parr = new Array();
    if (match != null && match.length > 0) {
        for (var i = 0; i < match.length; i++) {
            var elem = match[i];
            if(elem.length > 2)
                elem = elem.substring(2);
            var el = {
                Name : elem,
                StrType : "",
                ViewName : "",
                MinValQuery : "",
                MaxValQuery : ""
            }
            parr.push(el);
        }
    }
    ModAdm.MakeParamListFromServer(parr);
}

function btnDelRep_Click() {
    if (confirm('Точно удалить?')) {
        $.ajax(
        {
            url: uri + "/DeleteReport/" + $("#rId").val(),
            type: 'DELETE',
            success: function (data) {
                ModAdm.ClearCntr();
                ModAdm.SetAccordion(data);
            },
            error: function (x, y, z) {
                alert(x + '\n' + y + '\n' + z);
            }
        });
    }
}


function btnAddNewReport_Click() {
    ModAdm.ClearCntr();
   
    $.getJSON(uri, { strnew: "new" })
    .done(function (data) {
        ModAdm.SetAccordion(data);
        for (var i = 0; i < data.length; i++) {
            if (data[i].Current == 1) {
                ModAdm.SetCntr(data[i]);
                break;
            }
        }
    });
}

function OpenViewReport() {
    var report = ModAdm.GetCntr();
    window.open("ViewReport.html", "_blank");
}
