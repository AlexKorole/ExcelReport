﻿function LoadViewReport() {
    var params = window.opener.arr;
}

function BuildFormFromData() {

}

//function SetParamValues() {
//    var arr = $("#serverParamsName").val().split(';');
//    var arrtype = $("#serverParamsType").val().split(';');
//    var valsAll = $("#serverParamValues").val();
//    if (!(valsAll != null && valsAll != "")) return;
//    var vals = valsAll.split(';');
//    if (vals.length == 0) return;
//    var j = 0;
//    if (arr.length > 0) {
//        for (var i = 0; i < arr.length; i++) {
//            var elem = ASPxClientControl.GetControlCollection().GetByName(arr[i]);
//            if (elem != null) {
//                switch (arrtype[i]) {
//                    case "DateTime":
//                        if (vals[j] != null && vals[j] != undefined && vals[j].length > 0) {
//                            var dd = vals[j].split('.');
//                            var d = parseInt(dd[0]);
//                            var m = parseInt(dd[1]);
//                            var y = parseInt(dd[2]);
//                            if (!isNaN(d) && !isNaN(m) && !isNaN(y))
//                                elem.SetValue(new Date(y, m - 1, d));
//                        }
//                        break;
//                    case "Number":
//                        try {
//                            if ('SetText' in elem)
//                                elem.SetText(vals[j]);
//                            else elem.SetValue(vals[j]);
//                        } catch (err)
//                        { };
//                        break;
//                    default:
//                        if ('SetText' in elem)
//                            elem.SetText(vals[j]);
//                        else elem.SetValue(vals[j]);
//                        break;
//                }
//                j++;
//            }
//        }
//    }
//}