﻿String.prototype.replaceAll = function (search, replace) {
    return this.split(search).join(replace);
}

function NullToEmp(s) {
    if(s) return s;
    else return "";
}