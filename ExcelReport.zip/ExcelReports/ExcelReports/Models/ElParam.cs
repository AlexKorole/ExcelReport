﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExcelReports.Models
{
    public class ElParam
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ViewName { get; set; }
        public Type Type { get; set; }
        public string StrType { get; set; }
        public string MinValQuery { get; set; }
        public string MaxValQuery { get; set; }
    }
}