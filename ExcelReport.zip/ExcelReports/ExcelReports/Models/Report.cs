﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using Const;
using Dapper;
using DllRepository;

namespace ExcelReports.Models
{
    public class Report
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SecurityGroup { get; set; }
        public string Query { get; set; }
        public List<ElParam> ParamList { get; set; }
        public string TemplateName { get; set; }
        public int RowNumInTemplate { get; set; }
        public string TemplSheetName { get; set; }
        
        public string Author { get; set; }
        public bool IsStoredProcedure { get; set; }
        
        // если 1 то отображать, если 0 то нет.
        public int Current { get; set; }


        private static List<ElParam> _loadParams(DbConnection dbCon, int repId)
        {
            List<ElParam> res = null;
            var loadparams = SysRep.GetSysQ(dbCon, AppConst.LoadParams);
            {
                var ret = dbCon.Query<ElParam>(loadparams.First(), new { v_id_report = repId }).ToList();
                if (ret.Any()){
                    res = ret;
                }
            }
            return res;
        }
        
        private void _saveParams(DbConnection dbCon, DbTransaction tran)
        {
            if (ParamList != null)
            {
                var deleteParam = SysRep.GetSysQ(dbCon, AppConst.DeleteParam, tran);
                dbCon.Query(deleteParam.First(), new {v_id_report = Id}, tran);
                var insertParam = SysRep.GetSysQ(dbCon, AppConst.InsertParam, tran);
            
                for (int i = 0; i < ParamList.Count; i++)
                {
                    dbCon.Query(insertParam.First(), new
                    {
                        v_id_report = Id,
                        v_id_param = i,
                        v_name = ParamList[i].Name,
                        v_viewname = ParamList[i].ViewName,
                        v_strtype = ParamList[i].StrType,
                        v_minvalquery = ParamList[i].MinValQuery,
                        v_maxvalquery = ParamList[i].MaxValQuery
                    }, tran);
                }
            }
        }

        public static List<Report> AddNewReport()
        {
            var ret = new List<Report>();
            var ct = new ConType();
            using (var dbCon = ct.SystemCon)
            {
                dbCon.Open();

                var loadAll = SysRep.GetSysQ(dbCon, AppConst.LoadAllRep);
                ret = dbCon.Query<Report>(loadAll.First()).ToList();

                int i = 0;
                if (ret.Any())
                {
                   //while (ret.Any(f => f.Name != null && f.Name.Contains(AppConst.NewRep + i)))
                   //    i++;
                    i = ret.Max(f => f.Id) + 1;
                }
                var r = new Report
                {
                    Id = -1,
                    Name = AppConst.NewRep + i
                };
                r.Save();
                ret = dbCon.Query<Report>(loadAll.First()).ToList();

                var cur = ret.Where(f=> f.Id == r.Id);
                if (cur.Any())
                    cur.First().Current = 1;
            }
            return ret;
        }

        public static List<Report> LoadAll()
        {
            var ret = new List<Report>();
            var ct = new ConType();
            using (var dbCon = ct.SystemCon)
            {
                dbCon.Open();
                var loadAll = SysRep.GetSysQ(dbCon, AppConst.LoadAllRep);
                ret = dbCon.Query<Report>(loadAll.First()).ToList();
            }
            return ret;
        }

        public static void Delete(int Id)
        {
            var ct = new ConType();
            using (var dbCon = ct.SystemCon)
            {
                dbCon.Open();
                var tran = dbCon.BeginTransaction();
                var deleteParam = SysRep.GetSysQ(dbCon, AppConst.DeleteParam, tran);
                dbCon.Query(deleteParam.First(), new {v_id_report = Id}, tran);

                var deleteRep = SysRep.GetSysQ(dbCon, AppConst.DeleteRep, tran);
                dbCon.Query(deleteRep.First(), new { v_id_report = Id }, tran);
                tran.Commit();
            }
        }
        
        public void Save()
        {
            var ct = new ConType();
            using (var dbCon = ct.SystemCon)
            {
                dbCon.Open();
                var tran = dbCon.BeginTransaction();
                var check = SysRep.GetSysQ(dbCon, AppConst.CheckRep, tran);
                var ifexists = dbCon.Query<int?>(check.First(), new { v_id_report = Id }, tran);
                if (ifexists.Any())
                {
                    var update = SysRep.GetSysQ(dbCon, AppConst.UpdateRep, tran);
                    dbCon.Query(update.First(), new
                    {
                        v_name = Name,
                        v_securitygroup = SecurityGroup,
                        v_query = Query,
                        v_templatename = TemplateName,
                        v_rownumintemplate = RowNumInTemplate,
                        v_templsheetname = TemplSheetName,
                        v_isstoredprocedure = IsStoredProcedure,
                        v_id_report = Id
                    }, tran);
                }
                else
                {
                    var insert = SysRep.GetSysQ(dbCon, AppConst.InsertRep, tran);
                    var param = new DynamicParameters();
                    param.Add("v_name", Name);
                    param.Add("v_securitygroup", SecurityGroup);
                    param.Add("v_query", Query);
                    param.Add("v_templatename", TemplateName);
                    param.Add("v_rownumintemplate", RowNumInTemplate);
                    param.Add("v_templsheetname", TemplSheetName);
                    param.Add("v_isstoredprocedure", IsStoredProcedure);
                    param.Add("outId", dbType: DbType.VarNumeric, direction: ParameterDirection.Output);
                    dbCon.Query(insert.First(), param, tran);
                    Id = Convert.ToInt32(param.Get<decimal>("outId"));
                }
                _saveParams( dbCon, tran);
                tran.Commit();
            }
        }

        public static Report LoadOne(int id)
        {
            var ret = new Report();
            var ct = new ConType();
            using (var dbCon = ct.SystemCon)
            {
                dbCon.Open();
                var loadOne = SysRep.GetSysQ(dbCon, AppConst.LoadOne);
                var rl = dbCon.Query<Report>(loadOne.First(), new { v_id_report = id });
                if (rl.Any())
                {
                    ret = rl.First();
                    ret.ParamList = _loadParams(dbCon, id);
                }
            }
            return ret;
        }
    }
}