﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using ExcelReports.Models;

namespace ExcelReports.Controllers
{
    public class AdminController : ApiController
    {
       /* List<Report> reports = new List<Report>
        {
            new Report { Id = 0, Name = "Report1 Report1 Report1 r report"},
            new Report { Id = 1, Name = "Report2"},
            new Report { Id = 2, Name = "Report3"}
        };
        
        Report report = new Report 
        {
           Id = 0, 
           Name = "R2",
           SecurityGroup="My Group",
           Query = "Select 130 from dual where :p and :p2",
           ParamList = new List<ElParam> { new ElParam
               {
                  Name = "P1",
                  StrType = "String",
                  ViewName = "Параметр",
                  MinValQuery = "select \"1\" from dual",
                  MaxValQuery = "select \"2\" from dual",
               }
           },
           RowNumInTemplate = 5,
           TemplSheetName = "Лист 1",
           TemplateName = "Большой отчет", 
           IsStoredProcedure = true
        };*/

        public List<Report> GetAllReports()
        {
            return Report.LoadAll();
        }

        public List<Report> GetNewReport(string strnew)
        {
            return Report.AddNewReport();
        }
        
        public Report GetReport(int id)
        {
            return Report.LoadOne(id);
        }

        public void PutNewReport(Report report)
        {
            if (report.Id != -1)
            {
                report.Save();
            }
        }

        public List<Report> DeleteReport(int Id)
        {
            Report.Delete(Id);
            return Report.LoadAll();
        }

        public void DeleteExcelTemplate(int id)
        {
            var c = id + 50;
        }

        /// <summary>
        /// Как загрузить шаблон на сервер
        /// </summary>
        /// <returns></returns>
        public HttpResponseMessage PostFileUpload()
        {
            HttpContext.Current.Request.Files["fileToUpload"].SaveAs(@"C:\temp\1\test");
            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
