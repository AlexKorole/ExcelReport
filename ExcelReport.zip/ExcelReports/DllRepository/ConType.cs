﻿using System.Configuration;
using System.Data.Common;


namespace DllRepository
{
    public class ConType
    {

        public DbConnection UserCon
        {
            get
            {
                var confstr = ConfigurationManager.ConnectionStrings["User"];
                return _loadCons(confstr);
            }
        }

        public DbConnection SystemCon
        {
            get
            {
                var confstr = ConfigurationManager.ConnectionStrings["System"];
                return _loadCons(confstr);
            }
        }
        
        
        private static DbConnection _loadCons(ConnectionStringSettings  confstr)
        {
            DbConnection DBcon = null;
            var fctr = DbProviderFactories.GetFactory(confstr.ProviderName);
            DBcon = fctr.CreateConnection();
            DBcon.ConnectionString = confstr.ConnectionString;
            return DBcon;
        }
    }
}
