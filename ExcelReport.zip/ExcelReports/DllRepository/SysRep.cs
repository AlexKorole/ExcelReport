﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Const;
using Dapper;

namespace DllRepository
{
    public class SysRep
    {
        public static IEnumerable<string> GetSysQ(DbConnection dbCon, string name, IDbTransaction tran = null)
        {
            return dbCon.Query<string>(AppConst.GetSysQuery, new { v_name = name }, tran);
        }
    }
}
