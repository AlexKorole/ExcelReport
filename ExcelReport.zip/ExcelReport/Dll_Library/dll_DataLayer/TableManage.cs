﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Web;
using System.Data.OracleClient;
using System.Data;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс заполняющий таблицу значениями из базы
    /// </summary>
    public class TableManage
    {
        public BaseTable tbl;
        public Errors err;

        string DBConnectStr;
        string QueriesFile;

        // Нужен для параллельной работы
        public HttpContext context;

        private HttpContext prop_HTTPContext 
        {
            get { return HttpContext.Current ?? context; }
        }

        public TableManage(string dbConnectStr, string queriesFile)
        {
            DBConnectStr = dbConnectStr;
            QueriesFile = queriesFile;
            err = new Errors();
        }

        /// <summary>
        /// Загрузка таблицы из базы
        /// </summary>
        public void Load(string queryName, Type enType, List<OracleParameter> lparam = null, DbTransaction tran = null)
        {
            var dbparam = new List<DbParameter>();
            if (lparam != null)
            {
                foreach (var lp in lparam)
                {
                    dbparam.Add(lp);
                }
            }
            LoadDB(queryName, enType, dbparam, tran);
        }

        public void LoadDB(string queryName, Type enType, List<DbParameter> lparam = null, DbTransaction tran = null)
        {
            var s = new Storage(prop_HTTPContext.Cache, DBConnectStr);
            DbConnection con;
            if (tran == null)
                con = s.Connection(err);
            else con = tran.Connection;
            tbl = new BaseTable();
            tbl.setConAndPath(QueriesFile, con);
            tbl.Load(queryName, lparam, enType, err, false, tran);
            if (tran == null) con.Close();
        }

        /// <summary>
        /// Обновляет строку таблицы с записью ошибок в общий класс
        /// </summary>
        /// <param name="row"></param>
        /// <param name="dict"></param>
        public void UpdateRow(DataRow row, System.Collections.Specialized.OrderedDictionary dict)
        {
            if (tbl == null) tbl = new BaseTable();
            err.AddErr(tbl.UpdateRow(row, dict));
        }


        /// <summary>
        /// Получает названия колонок в виде входных параметров с такими же именами
        /// </summary>
        /// <returns></returns>
        public List<OracleParameter> MakeParamListFromRow(DataRow row)
        {
            var l = new List<OracleParameter>();
            try
            {
                foreach (DataColumn c in row.Table.Columns)
                {
                    if (c.ColumnName != "Id")
                    {
                        var param = new OracleParameter();
                        param.Value = row[c.ColumnName];
                        param.ParameterName = c.ColumnName;
                        param.OracleType = Queries.GetOracleType(row[c.ColumnName].GetType());
                       // if (param.OracleType == OracleType.VarChar && row[c.ColumnName] == DBNull.Value)
                       //     param.Value = string.Empty;
                        l.Add(param);
                    }
                }
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            return l;
        }

        /// <summary>
        /// Открывает транзакцию
        /// </summary>
        /// <returns></returns>
        public DbTransaction OpenTran()
        {
            var s = new Storage(prop_HTTPContext.Cache, DBConnectStr);
            var con = s.Connection(err);
            var tran = con.BeginTransaction();
            return tran;
        }

        public void CloseTran(DbTransaction tran, bool isCommit)
        {
            var con = tran.Connection;
            if (isCommit) tran.Commit();
            else tran.Rollback();
            con.Close();
        }

        /// <summary>
        /// Выполнение запроса
        /// </summary>
        public object ExecQuery(string queryName, List<OracleParameter> p, bool isScalar, bool isSP, DbTransaction tran)
        {
            var dbparam = new List<DbParameter>();
            if (p != null)
            {
                foreach (var lp in p)
                    dbparam.Add(lp);
            }
            return ExecQueryDb(queryName, dbparam, isScalar, isSP, tran);
        }

        public object ExecQueryDb(string queryName, List<DbParameter> p, bool isScalar, bool isSP, DbTransaction tran)
        {
            object res = null;
            try
            {
                var s = new Storage(prop_HTTPContext.Cache, DBConnectStr);
                DbConnection con;
                if (tran == null)
                    con = s.Connection(err);
                else con = tran.Connection;
                if (tbl == null) tbl = new BaseTable();
                tbl.setConAndPath(QueriesFile, con);
                res = tbl.ExecQuery(queryName, p, isSP, isScalar, err, tran);
                if (tran == null) con.Close();
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            return res;
        }

        /// <summary>
        /// Отбор только параметров, которые есть в запросе
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="p"></param>
        public void ClearParameters(string queryName, List<OracleParameter> p)
        {
            var loadQuery = Queries.Get(queryName, QueriesFile);
            var delParam = new List<OracleParameter>();
            foreach (var prm in p)
            {
                if (!loadQuery.Contains(":" + prm.ParameterName))
                    delParam.Add(prm);
            }

            foreach (var prm in delParam)
            {
                p.Remove(prm);
            }
        }
    }
}
