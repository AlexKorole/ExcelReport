﻿namespace dll_DataLayer
{
    /// <summary>
    /// Класс хранить Enum, в которых хранятся названия колонок в таблицах с которыми работает dll. 
    /// Название элементов enum должно совпдадать с названием колонок в селекте
    /// </summary>
    public class Enums
    {
        /// <summary>
        /// Когда нужно просто считать селект и записать его в таблицу, названия колонок которй не важны
        /// </summary>
        public enum UNKNOWN
        {
          
        }
        
        /// <summary>
        /// Для сохранения соответсвий колонок в базе колонкам в Excel
        /// </summary>
        public enum UTL_REPORTS_COLUMN_NAMES
        {
            REPORTNAME,
            BASECOLUMNNAME,
            EXCELCOLUMNNAME
        }


    }
}
