﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using Teradata.Client.Provider;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_DataLayer
{
    public class DBWrapper
    {
        public static DbConnection GetConnection(string type, string conStr)
        {
            switch (type)
            {
                case "Oracle":
                    return new OracleConnection(conStr);
                case "Terradata":
                    return new TdConnection(conStr);
                default:
                    return null;
            }
        }

        public static DbCommand GetCommand(string type)
        {
            switch (type)
            {
                case "Oracle":
                    return new OracleCommand();
                case "Terradata":
                    return new TdCommand();
                default:
                    return null;
            }
        }
    }
}
