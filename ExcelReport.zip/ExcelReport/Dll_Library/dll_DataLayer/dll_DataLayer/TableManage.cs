﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Data.OracleClient;
using System.Data;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс заполняющий таблицу значениями из базы
    /// </summary>
    public class TableManage
    {
        public BaseTable tbl;
        public Errors err;

        string DBConnectStr;
        string QueriesFile;

        public TableManage(string dbConnectStr, string queriesFile)
        {
            DBConnectStr = dbConnectStr;
            QueriesFile = queriesFile;
            err = new Errors();
        }

        /// <summary>
        /// Загрузка таблицы из базы
        /// </summary>
        public void Load(string queryName, Type enType, List<OracleParameter> lparam = null, OracleTransaction tran = null)
        {
            var s = new Storage(HttpContext.Current.Cache, DBConnectStr);
            OracleConnection con;
            if (tran == null)
                con = s.Connection(err);
            else con = tran.Connection;
            tbl = new BaseTable();
            tbl.setConAndPath(QueriesFile, con);
            tbl.Load(queryName, lparam, enType, err, false, tran);
            if (tran == null) con.Close();
        }

        /// <summary>
        /// Обновляет строку таблицы с записью ошибок в общий класс
        /// </summary>
        /// <param name="row"></param>
        /// <param name="dict"></param>
        public void UpdateRow(DataRow row, System.Collections.Specialized.OrderedDictionary dict)
        {
            if (tbl == null) tbl = new BaseTable();
            err.AddErr(tbl.UpdateRow(row, dict));
        }


        /// <summary>
        /// Получает названия колонок в виде входных параметров с такими же именами
        /// </summary>
        /// <returns></returns>
        public List<OracleParameter> MakeParamListFromRow(DataRow row)
        {
            var l = new List<OracleParameter>();
            try
            {
                foreach (DataColumn c in row.Table.Columns)
                {
                    if (c.ColumnName != "Id")
                    {
                        var param = new OracleParameter();
                        param.Value = row[c.ColumnName];
                        param.ParameterName = c.ColumnName;
                        param.OracleType = Queries.GetOracleType(row[c.ColumnName].GetType());
                       // if (param.OracleType == OracleType.VarChar && row[c.ColumnName] == DBNull.Value)
                       //     param.Value = string.Empty;
                        l.Add(param);
                    }
                }
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            return l;
        }

        /// <summary>
        /// Открывает транзакцию
        /// </summary>
        /// <returns></returns>
        public OracleTransaction OpenTran()
        {
            var s = new Storage(HttpContext.Current.Cache, DBConnectStr);
            var con = s.Connection(err);
            var tran = con.BeginTransaction();
            return tran;
        }

        public void CloseTran(OracleTransaction tran, bool isCommit)
        {
            var con = tran.Connection;
            if (isCommit) tran.Commit();
            else tran.Rollback();
            con.Close();
        }
        
        /// <summary>
        /// Выполнение запроса
        /// </summary>
        public object ExecQuery(string queryName, List<OracleParameter> p, bool isScalar, bool isSP, OracleTransaction tran)
        {
            object res = null;
            try
            {
                var s = new Storage(HttpContext.Current.Cache, DBConnectStr);
                OracleConnection con;
                if (tran == null)
                    con = s.Connection(err);
                else con = tran.Connection;
                if (tbl == null) tbl = new BaseTable();
                tbl.setConAndPath(QueriesFile, con);
                res = tbl.ExecQuery(queryName, p, isSP, isScalar, err, tran);
                if (tran == null) con.Close();
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            return res;
        }

        /// <summary>
        /// Отбор только параметров, которые есть в запросе
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="p"></param>
        public void ClearParameters(string queryName, List<OracleParameter> p)
        {
            var loadQuery = Queries.Get(queryName, QueriesFile);
            var delParam = new List<OracleParameter>();
            foreach (var prm in p)
            {
                if (!loadQuery.Contains(":" + prm.ParameterName))
                    delParam.Add(prm);
            }

            foreach (var prm in delParam)
            {
                p.Remove(prm);
            }
        }
    }
}
