﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Data.OracleClient;
using System.Data;

namespace dll_DataLayer
{
    /// <summary>
    /// Вспомогательный класс для получения запросов из файлов, добавления параметров и т.п.
    /// </summary>
    public class Queries
    {
        /// <summary>
        /// Словарь всех запросов из файла
        /// </summary>
        static Dictionary<string, string> AllQueries;

        /// <summary>
        /// Получение запроса по имени
        /// </summary>
        /// <param name="QueryName"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string Get(string QueryName, string path)
        {
            if (AllQueries == null)
                Init(path);
            return AllQueries[QueryName];
        }

        /// <summary>
        /// Инициализаия
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string Init(string path)
        {
            var err = string.Empty;
            try
            {
                var ret = string.Empty;
                var doc = new XmlDocument();
                doc.Load(path);

                AllQueries = new Dictionary<string, string>();
                foreach (XmlNode node in doc.GetElementsByTagName("query"))
                {
                    if (!AllQueries.ContainsKey(node.Attributes["id"].Value))
                        AllQueries.Add(node.Attributes["id"].Value, node.InnerText);
                }
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            return err;
        }

        /// <summary>
        /// Создает параметр
        /// </summary>
        /// <param name="type"></param>
        /// <param name="value"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static OracleParameter addParam(OracleType type, object value, string name)
        {
            OracleParameter param = new OracleParameter();
            param = new OracleParameter();
            param.OracleType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = global::System.DBNull.Value;
            }
            else
            {
                param.Value = value;
                if (type == OracleType.VarChar || type == OracleType.NVarChar)
                {
                    param.Size = value.ToString().Length;
                }
            }
            return param;
        }

        /// <summary>
        ///  Функция выполняет запрос в базе
        /// </summary>
        public static object ExecNonQuery(string query, OracleConnection con, OracleTransaction tran, out string err, List<OracleParameter> lparam, bool isStoredProcedure, bool isScalar = false)
        {
            object res = null;
            err = string.Empty;
            try
            {
                OracleCommand com = new OracleCommand();
                if (tran != null) com.Transaction = tran;
                com.Connection = con;
                com.CommandTimeout = 0;
                com.CommandText = query;
                if (lparam != null && lparam.Count > 0)
                {
                    foreach (OracleParameter p in lparam)
                    {
                        com.Parameters.Add(p);
                    }
                }
                if (isStoredProcedure) com.CommandType = CommandType.StoredProcedure;
                else com.CommandType = CommandType.Text;
                if (isScalar) 
                    res = com.ExecuteScalar();
                else res = com.ExecuteNonQuery();
                com.Parameters.Clear();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            return res;
        }


        /// <summary>
        /// Возвращает по типу С# тип Oracle
        /// </summary>
        /// <param name="inputType"></param>
        /// <returns></returns>
        public static OracleType GetOracleType(Type inputType)
        {
            OracleType t = OracleType.VarChar;
            if (inputType == typeof(string))
            {
                t = OracleType.VarChar; return t;
            }

            if (inputType == typeof(int) || inputType == typeof(decimal))
            {
                t = OracleType.Number; return t;
            }

            if (inputType == typeof(DateTime))
            {
                t = OracleType.DateTime; return t;
            }

            return t;
        }
    }
}
