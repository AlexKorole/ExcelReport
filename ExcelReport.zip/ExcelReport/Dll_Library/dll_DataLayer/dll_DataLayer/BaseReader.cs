﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OracleClient;
using System.Data;

namespace dll_DataLayer
{
    /// <summary>
    /// Работает с DataReader при заполнении таблицы
    /// </summary>
    public class BaseReader
    {
        private bool isStoredProc;
        public delegate void SaveCellsData(Dictionary<int, BaseColumn> c, OracleDataReader reader);
        public delegate void GenerateColumns(Dictionary<int, BaseColumn> c);
        // Событие на запись значений
        public event SaveCellsData saveCellsEvent;
        // Событие на получения списка колонок из запроса, вызывается когда нужно вернуть только колонки
        public event GenerateColumns generateColumns;

        public delegate void SaveColumns(BaseColumn c);
        // Событие на получения списка колонок из запроса
        public event SaveColumns saveColumnsEvent;
        // Соединение с базой
        private OracleConnection mainConnect;

        public BaseReader(OracleConnection con, bool IsStoredProc)
        {
            mainConnect = con;
            isStoredProc = IsStoredProc;
        }

        /// <summary>
        /// Функция которая запускает ридер и пишет из него в класс который подписался на события.
        /// Ошибка возвращается как out параметр.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="parameters"></param>
        /// <param name="norows"></param>
        /// <param name="err"></param>
        public void RunReader(string query, List<OracleParameter> parameters, out bool norows, out string err, OracleTransaction tran)
        {
            norows = false;
            OracleDataReader reader = execReader(query, parameters, out err, tran);
            if (!string.IsNullOrEmpty(err)) return;
            try
            {
                if (reader.FieldCount > 0)
                {
                    var columns = GetColumns(reader);
                    if (!reader.HasRows)
                        norows = true;
                    else generateColumns(columns);
                    
                    while (reader.Read())
                    {
                        if (saveCellsEvent != null) saveCellsEvent(columns, reader);
                    }

                    if (norows)
                        if (generateColumns != null) generateColumns(columns);
                }
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            reader.Close();
        }


        private Dictionary<int, BaseColumn> GetColumns(OracleDataReader reader)
        {
            Dictionary<int, BaseColumn> col = new Dictionary<int, BaseColumn>();
            var schema = reader.GetSchemaTable();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                DataRow field = schema.Rows[i];
                var c = new BaseColumn();
                c.Name = field["ColumnName"].ToString();
                c.Type = (System.Type)field["DataType"];
                c.size = Convert.ToInt32(field["ColumnSize"]);
                c.colNumber = i;
                col.Add(i, c);
                if (saveColumnsEvent != null) saveColumnsEvent(c);
            }
            return col;
        }

        private OracleDataReader execReader(string query, List<OracleParameter> parameters, out string err, OracleTransaction tran)
        {
            err = string.Empty;

            OracleCommand com = new OracleCommand();
            com.Connection = mainConnect;
            com.CommandTimeout = 0;
            com.CommandText = query;
            if (tran != null) com.Transaction = tran;
            if (isStoredProc)
            {
                var arr = com.CommandText.Split('(');
                var resQuery = "";
                if (arr.Length > 1)
                    resQuery = com.CommandText.Split('(')[0];
                else resQuery = query;

                com.CommandText = resQuery;
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.Add("returnValue", OracleType.Cursor).Direction = ParameterDirection.ReturnValue;
            }

            if (parameters != null && parameters.Count > 0)
            {
                foreach (var p in parameters)
                {
                    com.Parameters.Add(p);
                }
            }

            OracleDataReader reader = null;
            try
            {
                if (isStoredProc)
                {
                    com.ExecuteNonQuery();
                    reader = (OracleDataReader)com.Parameters["returnValue"].Value;
                }
                else
                    reader = com.ExecuteReader();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            return reader;
        }
    }
}
