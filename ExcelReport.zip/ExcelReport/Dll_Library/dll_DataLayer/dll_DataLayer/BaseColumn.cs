﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dll_DataLayer
{
    /// <summary>
    /// Вспомогательный класс для хранения информации о колонках в запросе
    /// </summary>
    public class BaseColumn
    {
        public string Name;
        public Type Type;
        public int size;
        public int colNumber;
    }
}
