﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.OracleClient;
using System.Web.SessionState;
using System.Web.Caching;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс хранит открытую коннекцию к базе в кэше приложения
    /// </summary>
    public class Storage
    {
        public const string const_Connection = "Connection";
        public const string Inst = "Inst";

        string ConStr;

        Cache cache;
        public Storage(Cache Cache, string conStr)
        {
            cache = Cache;
            ConStr = conStr;
        }

        /// <summary>
        /// Соединение с базой, возвращает ошибку в out параметре
        /// </summary>
        /// <param name="err"></param>
        /// <returns></returns>
        public OracleConnection Connection(out string err)
        {
            err = string.Empty;
            var con = new OracleConnection(ConStr);
            try
            {
               // connection();
               con.Open();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            //return cache[const_Connection] as OracleConnection;
            return con;
        }

        /// <summary>
        /// Соединение с базой, возвращает ошибку в Errors классе
        /// </summary>
        /// <param name="err"></param>
        /// <returns></returns>
        public OracleConnection Connection(Errors err)
        {
            var con = new OracleConnection(ConStr);
            try
            {
                //connection();
                con.Open();
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            //return cache[const_Connection] as OracleConnection;
            return con;
        }

        /// <summary>
        /// Соединение с базой
        /// </summary>
        //private void connection()
        //{
        //    if (cache[const_Connection] == null)
        //    {
        //        var con = new OracleConnection(ConStr);
        //        con.Open();
        //        cache.Insert(const_Connection,
        //                     con,
        //                     null,
        //                     Cache.NoAbsoluteExpiration,
        //                     new TimeSpan(0, 30, 0),
        //                     CacheItemPriority.Default,
        //                     new CacheItemRemovedCallback(ReportRemovedCallback));
        //    }
        //    else if ((cache[const_Connection] as OracleConnection).State != System.Data.ConnectionState.Open)
        //    {
        //        (cache[const_Connection] as OracleConnection).Open();
        //    }
        //}

        //public static void ReportRemovedCallback(String key, object value, CacheItemRemovedReason removedReason)
        //{
        //    if (key == const_Connection && value != null)
        //    {
        //        if ((value as OracleConnection).State != System.Data.ConnectionState.Closed)
        //        {
        //            (value as OracleConnection).Close();
        //        }
        //    }
        //}

        //public void CloseConncetion()
        //{
        //    if (cache[const_Connection] != null)
        //    {
        //        if ((cache[const_Connection] as OracleConnection).State != System.Data.ConnectionState.Closed)
        //        {
        //            (cache[const_Connection] as OracleConnection).Close();
        //        }
        //    }
        //}
    }
}
