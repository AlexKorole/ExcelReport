﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OracleClient;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс для работы с базой данных, хранит в себе набор данных в виде DataTable
    /// </summary>
    [Serializable]
    public class BaseTable : DataTable
    {
        // Коннекция к базе
        OracleConnection Con;
        // Путь к Query.xml
        string Path;
        // список строковых значений Enum
        string[] workEnum;

        // список с ошибками
        public List<string> errorList;
        
        /// <summary>
        /// Возвращает строковое значение Enum
        /// </summary>
        /// <param name="elem"></param>
        /// <returns></returns>
        public string CN(object elem)
        {
            return Enum.GetName(elem.GetType(), elem);
        }

       

        protected BaseTable(global::System.Runtime.Serialization.SerializationInfo info, global::System.Runtime.Serialization.StreamingContext context) :
            base(info, context)
        {
            TableName = this.GetType().Name;
        }

        /// <summary>
        /// Рабочий конструктор, остальные перегруженны для корректной работы Сериализации
        /// </summary>
        public BaseTable()
            : base() { 
            TableName = this.GetType().Name;
            Columns.Add("Id", typeof(int));
            Columns[0].AutoIncrementSeed = 0;
            Columns[0].AutoIncrement = true;
            PrimaryKey = new[] { Columns["Id"] };
            errorList = new List<string>();
        }

        /// <summary>
        /// Установка коннекта и пути к файлу с запросами, класс не всегда работает только с базой, строки можно добавить в ручную из кода
        /// </summary>
        /// <param name="path"></param>
        /// <param name="con"></param>
        public void setConAndPath(string path, OracleConnection con)
        {
            Path = path;
            Con = con;
        }

        private void fillworkEnumIfNull(Dictionary<int, BaseColumn> c)
        {
            if (workEnum == null)
            {
                var list = new List<string>();
                foreach (var d in c)
                {
                    list.Add(d.Value.Name);
                }
                workEnum = list.ToArray();
            }
        }

        /// <summary>
        /// Создание колонок на основе названий в Enum
        /// </summary>
        /// <param name="c"></param>
        protected void generateColumns(Dictionary<int, BaseColumn> c)
        {
            var nrow = NewRow();
            var a = new AddValues(c, nrow, null);
            fillworkEnumIfNull(c);
            a.GenerateColumns(this, workEnum);
        }

        /// <summary>
        /// Добавление строки в таблицу
        /// </summary>
        /// <param name="c"></param>
        /// <param name="reader"></param>
        protected void loadDataToCellsEvent(Dictionary<int, BaseColumn> c, OracleDataReader reader)
        {
            var nrow = NewRow();
            var a = new AddValues(c, nrow, reader);
            //fillworkEnumIfNull(c);
            //a.GenerateColumns(this, workEnum);
            a.bindValues(workEnum);
            Rows.Add(nrow);
        }

        /// <summary>
        /// Загрузка таблицы из базы.
        /// Ошибка возвращается как retval
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="lparam"></param>
        /// <param name="enType"></param>
        /// <returns></returns>
        public string Load(string queryName, List<OracleParameter> lparam, Type enType, bool isDynamicQuery = false, OracleTransaction tran = null)
        {
            string err = load(queryName, lparam, enType, isDynamicQuery, tran);
            if (!string.IsNullOrEmpty(err))
            {
                errorList.Add(err);
            }
            var errres = string.Empty;
            if (errorList != null)
            {
                foreach(var e in errorList)                    
                    errres += e;
            }
            return errres;
        }

        /// <summary>
        ///  Загрузка таблицы из базы. Ошибка пишется в класс ошибок
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="lparam"></param>
        /// <param name="enType"></param>
        /// <param name="errCl"></param>
        /// <param name="isDynamicQuery"></param>
        public void Load(string queryName, List<OracleParameter> lparam, Type enType, Errors errCl, bool isDynamicQuery = false, OracleTransaction tran = null)
        {
            string err = load(queryName, lparam, enType, isDynamicQuery, tran);
            if (!string.IsNullOrEmpty(err))
            {
                errCl.AddErr(err);
            }
            if (errorList != null)
            {
                foreach (var e in errorList)
                    errCl.AddErr(e);
            }
        }

        /// <summary>
        ///  Загрузка таблицы из базы, без обработки ошибок
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="lparam"></param>
        /// <param name="enType"></param>
        /// <param name="isDynamicQuery"></param>
        /// <returns></returns>
        private string load(string queryName, List<OracleParameter> lparam, Type enType, bool isDynamicQuery, OracleTransaction tran)
        {
            if (typeof(Enums.UNKNOWN) != enType)
                workEnum = Enum.GetNames(enType);

            var loadQuery = string.Empty;
            if (isDynamicQuery)
                loadQuery = queryName;
            else
                loadQuery = Queries.Get(queryName, Path);

            var reader = new BaseReader(Con, false);
            reader.saveCellsEvent += loadDataToCellsEvent;
            reader.generateColumns += generateColumns;
            string err;
            bool norows;
            reader.RunReader(loadQuery, lparam, out norows, out err, tran);
            return err;
        }

        /// <summary>
        /// Выполнение запроса к базе. Возвращает ошибку как класс
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public object ExecQuery(string queryName, List<OracleParameter> param, bool isSP, bool isScalar, Errors err, OracleTransaction tran = null)
        {
            var loadQuery = Queries.Get(queryName, Path);
            string errStr;
            var res = Queries.ExecNonQuery(loadQuery, Con, tran, out errStr, param, isSP, isScalar);
            err.AddErr(errStr);
            return res;
        }
        
        
        /// <summary>
        /// Выполнение запроса к базе. Возвращает ошибку как строку
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public string ExecQuery(string queryName, List<OracleParameter> param, bool isSP = false ,bool isScalar = false)
        {
            var loadQuery = Queries.Get(queryName, Path);
            string err;
            Queries.ExecNonQuery(loadQuery, Con, null, out err, param, isSP, isScalar);
            return err;
        }

        /// <summary>
        /// Сохранение всех строк таблицы в базу
        /// </summary>
        /// <param name="queryName"></param>
        /// <param name="enType"></param>
        /// <returns></returns>
        public string InsertAllRows(string queryName, Type enType)
        {
            var errBuilder = new StringBuilder();
            var loadQuery = Queries.Get(queryName, Path);
            var names = Enum.GetNames(enType);

            var tran = Con.BeginTransaction();

            foreach (DataRow r in Rows)
            {
                var paramList = new List<OracleParameter>();
                foreach (var n in names)
                    paramList.Add(Queries.addParam(Queries.GetOracleType(r[n].GetType()), r[n], n));
                string err;
                Queries.ExecNonQuery(loadQuery, Con, tran, out err, paramList, false);
                errBuilder.AppendLine(err);
            }

            if (errBuilder.ToString().Trim().Length == 0)
                tran.Commit();
            else tran.Rollback();
            return errBuilder.ToString().Trim();
        }

        /// <summary>
        /// Возвращает bool из ячеки табицы
        /// </summary>
        /// <param name="colname"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        public bool? GetValueBoolAnyRow(string colname, DataRow r)
        {
            bool? archivator = null;
            var rchStr = r[colname];
            if (rchStr != DBNull.Value)
            {
                archivator = Convert.ToBoolean(rchStr);
            }
            return archivator;
        }

        /// <summary>
        /// Возвращает int32 из ячеки табицы
        /// </summary>
        /// <param name="colname"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        public int? GetValueIntAnyRow(string colname, DataRow r)
        {
            int? archivator = null;
            var rchStr = r[colname];
            if (rchStr != DBNull.Value)
            {
                archivator = Convert.ToInt32(rchStr);
            }
            return archivator;
        }

        /// <summary>
        /// Возвращает строку из ячеки табицы
        /// </summary>
        /// <param name="colname"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        public string GetValueStringAnyRow(string colname, DataRow r)
        {
            var archivator = string.Empty;
            var rchStr = r[colname];
            if (rchStr != DBNull.Value)
            {
                archivator = rchStr.ToString();
            }
            return archivator;
        }

        /// <summary>
        /// Возвращает строку из ячеки таблицы
        /// </summary>
        /// <param name="colname"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        public string GetValueStringAnyRow(int colnumber, DataRow r)
        {
            var archivator = string.Empty;
            var rchStr = r[colnumber];
            if (rchStr != DBNull.Value)
            {
                archivator = rchStr.ToString();
            }
            return archivator;
        }

        public string UpdateRow(DataRow row, System.Collections.Specialized.OrderedDictionary dict)
        {
            string ret = string.Empty;
            try
            {
                foreach (DataColumn c in row.Table.Columns)
                {
                    if (c.ColumnName != "Id")
                    {
                        if (dict.Contains(c.ColumnName))
                        {
                            row[c.ColumnName] = dict[c.ColumnName] == null ? DBNull.Value : dict[c.ColumnName];
                        }
                    }
                }
            }
            catch (Exception e)
            {
                ret = e.Message;
            }
            return ret;
        }
    }
}
