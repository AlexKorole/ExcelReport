﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;

namespace dll_DataLayer
{
    /// <summary>
    /// Вспомогательный класс для автоматической привязке результата селекта из базы к классу BaseTable
    /// </summary>
    public class AddValues
    {
        Dictionary<int, BaseColumn> c;
        DataRow nrow;
        DbDataReader reader;

        /// <summary>
        /// Добавление значений или названий колонок, без разбора значений reader
        /// </summary>
        /// <param name="C"></param>
        /// <param name="Nrow"></param>
        /// <param name="Reader"></param>
        public AddValues(Dictionary<int, BaseColumn> C,
                         DataRow Nrow,
                         DbDataReader Reader)
        {
            c = C;
            nrow = Nrow;
            reader = Reader;
        }

        /// <summary>
        /// Генерация колонок
        /// </summary>
        /// <param name="table"></param>
        /// <param name="names"></param>
        public void GenerateColumns(DataTable table, string[] names)
        {
            foreach (var v in names)
            {
                var realstrN = v;
                if (!table.Columns.Contains(realstrN))
                {
                    for (int i = 0; i < c.Count; i++)
                    {
                        string sv = realstrN.ToUpper().Trim();
                        if (c[i].Name.ToUpper().Trim() == sv)
                        {
                            table.Columns.Add(realstrN, c[i].Type);
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Маппинг значений reader на значения класса
        /// </summary>
        /// <param name="tEnum"></param>
        public void bindValues(string[] tEnum)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                foreach (var v in tEnum)
                {
                    var realstrN = v;
                    string sv = realstrN.ToUpper().Trim();
                    if (c[i].Name.ToUpper().Trim() == sv)
                    {
                        nrow[realstrN] = reader[i];
                        break;
                    }
                }
            }
        }

        //private void addVal(int pos, string name)
        //{
        //    if (c[pos - 1].Name.ToUpper() == name.ToUpper())
        //        nrow[pos] = reader[pos - 1];
        //}

        //public void addVal(object enumName)
        //{
        //    addVal((int)enumName, Enum.GetName(enumName.GetType(), enumName));
        //}
    }
}
