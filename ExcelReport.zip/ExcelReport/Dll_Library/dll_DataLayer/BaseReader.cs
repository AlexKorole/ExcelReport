﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data;

namespace dll_DataLayer
{
    /// <summary>
    /// Работает с DataReader при заполнении таблицы
    /// </summary>
    public class BaseReader
    {
        public string db_type = "Oracle";
        
        private bool isStoredProc;
        public delegate void SaveCellsData(Dictionary<int, BaseColumn> c, DbDataReader reader);
        public delegate void GenerateColumns(Dictionary<int, BaseColumn> c);
        // Событие на запись значений
        public event SaveCellsData saveCellsEvent;
        // Событие на получения списка колонок из запроса, вызывается когда нужно вернуть только колонки
        public event GenerateColumns generateColumns;

        public delegate void SaveColumns(BaseColumn c);
        // Событие на получения списка колонок из запроса
        public event SaveColumns saveColumnsEvent;
        // Соединение с базой
        private DbConnection mainConnect;

        public BaseReader(DbConnection con, bool IsStoredProc)
        {
            mainConnect = con;
            isStoredProc = IsStoredProc;
        }

        /// <summary>
        /// Функция которая запускает ридер и пишет из него в класс который подписался на события.
        /// Ошибка возвращается как out параметр.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="parameters"></param>
        /// <param name="norows"></param>
        /// <param name="err"></param>
        public void RunReader(string query, List<DbParameter> parameters, out bool norows, out string err, DbTransaction tran)
        {
            norows = false;
            DbDataReader reader = execReader(query, parameters, out err, tran);
            if (!string.IsNullOrEmpty(err)) return;
            try
            {
                if (reader.FieldCount > 0)
                {
                    var columns = GetColumns(reader);
                    if (!reader.HasRows)
                        norows = true;
                    else generateColumns(columns);
                    
                    while (reader.Read())
                    {
                        if (saveCellsEvent != null) saveCellsEvent(columns, reader);
                    }

                    if (norows)
                        if (generateColumns != null) generateColumns(columns);
                }
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            reader.Close();
        }


        private Dictionary<int, BaseColumn> GetColumns(DbDataReader reader)
        {
            Dictionary<int, BaseColumn> col = new Dictionary<int, BaseColumn>();
            var schema = reader.GetSchemaTable();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                DataRow field = schema.Rows[i];
                var c = new BaseColumn();
                c.Name = field["ColumnName"].ToString();
                c.Type = (System.Type)field["DataType"];
                c.size = Convert.ToInt32(field["ColumnSize"]);
                c.colNumber = i;
                col.Add(i, c);
                if (saveColumnsEvent != null) saveColumnsEvent(c);
            }
            return col;
        }

        private DbDataReader execReader(string query, List<DbParameter> parameters, out string err, DbTransaction tran)
        {
            err = string.Empty;

            if (mainConnect is OracleConnection) 
                 db_type = "Oracle";
            else db_type = "Terradata";
            
            var com = DBWrapper.GetCommand(db_type);
            com.Connection = mainConnect;
            com.CommandTimeout = 0;
            com.CommandText = query;
            if (tran != null) com.Transaction = tran;
            if (isStoredProc)
            {
                var arr = com.CommandText.Split('(');
                var resQuery = "";
                if (arr.Length > 1)
                    resQuery = com.CommandText.Split('(')[0];
                else resQuery = query;

                com.CommandText = resQuery;
                com.CommandType = CommandType.StoredProcedure;
                if(db_type == "Oracle")
                    (com as OracleCommand).Parameters.Add("returnValue", OracleType.Cursor).Direction = ParameterDirection.ReturnValue;
            }

            if (parameters != null && parameters.Count > 0)
            {
                foreach (var p in parameters)
                {
                    com.Parameters.Add(p);
                }
            }

            DbDataReader reader = null;
            try
            {
                if (isStoredProc)
                {
                    com.ExecuteNonQuery();
                    if (db_type == "Oracle")
                        reader = (OracleDataReader)com.Parameters["returnValue"].Value;
                }
                else
                    reader = com.ExecuteReader();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            return reader;
        }
    }
}
