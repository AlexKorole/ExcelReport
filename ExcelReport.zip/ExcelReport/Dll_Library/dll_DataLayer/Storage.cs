﻿using System;
using System.Data.Common;
using System.Data.OracleClient;
using System.Web.Caching;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс хранит открытую коннекцию к базе в кэше приложения
    /// </summary>
    public class Storage
    {
        public const string const_Connection = "Connection";
        public const string Inst = "Inst";

        string ConStr;
        string ConStrSystem;

        Cache cache;

        public Storage(Cache Cache, string conStr, string conStrSystem = "")
        {
            cache = Cache;
            ConStr = conStr;
            ConStrSystem = conStrSystem;
        }

        /// <summary>
        /// Соединение с системной базой, возвращает ошибку в out параметре
        /// </summary>
        /// <param name="err"></param>
        /// <returns></returns>
        public DbConnection ConnectionSystem(out string err, string db_type = "Oracle")
        {
            err = string.Empty;
            var con = DBWrapper.GetConnection(db_type, ConStrSystem);
            try
            {
                // connection();
                con.Open();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            //return cache[const_Connection] as OracleConnection;
            return con;
        }

        /// <summary>
        /// Соединение с базой, возвращает ошибку в out параметре
        /// </summary>
        /// <param name="err"></param>
        /// <returns></returns>
        public DbConnection Connection(out string err, string db_type = "Oracle")
        {
            err = string.Empty;
            var con = DBWrapper.GetConnection(db_type, ConStr);
            try
            {
               // connection();
               con.Open();
            }
            catch (Exception e)
            {
                err = e.Message;
            }
            //return cache[const_Connection] as OracleConnection;
            return con;
        }

        /// <summary>
        /// Соединение с базой, возвращает ошибку в Errors классе
        /// </summary>
        /// <param name="err"></param>
        /// <returns></returns>
        public DbConnection Connection(Errors err, string db_type="Oracle")
        {
            var con = DBWrapper.GetConnection( db_type, ConStr);
            try
            {
                //connection();
                con.Open();
            }
            catch (Exception e)
            {
                err.AddErr(e.Message);
            }
            //return cache[const_Connection] as OracleConnection;
            return con;
        }

        /// <summary>
        /// Соединение с базой
        /// </summary>
        //private void connection()
        //{
        //    if (cache[const_Connection] == null)
        //    {
        //        var con = new OracleConnection(ConStr);
        //        con.Open();
        //        cache.Insert(const_Connection,
        //                     con,
        //                     null,
        //                     Cache.NoAbsoluteExpiration,
        //                     new TimeSpan(0, 30, 0),
        //                     CacheItemPriority.Default,
        //                     new CacheItemRemovedCallback(ReportRemovedCallback));
        //    }
        //    else if ((cache[const_Connection] as OracleConnection).State != System.Data.ConnectionState.Open)
        //    {
        //        (cache[const_Connection] as OracleConnection).Open();
        //    }
        //}

        //public static void ReportRemovedCallback(String key, object value, CacheItemRemovedReason removedReason)
        //{
        //    if (key == const_Connection && value != null)
        //    {
        //        if ((value as OracleConnection).State != System.Data.ConnectionState.Closed)
        //        {
        //            (value as OracleConnection).Close();
        //        }
        //    }
        //}

        //public void CloseConncetion()
        //{
        //    if (cache[const_Connection] != null)
        //    {
        //        if ((cache[const_Connection] as OracleConnection).State != System.Data.ConnectionState.Closed)
        //        {
        //            (cache[const_Connection] as OracleConnection).Close();
        //        }
        //    }
        //}
    }
}
