﻿using System.Text;

namespace dll_DataLayer
{
    /// <summary>
    /// Класс содержит ошибки, которые возникли при работе с dll
    /// </summary>
    public class Errors
    {
        StringBuilder errBld;
        public void AddErr(string err)
        {
            if (errBld == null) errBld = new StringBuilder();
            errBld.AppendLine(err);
        }

        public string GetErrAndClr()
        {
            if (errBld == null) return string.Empty;
            var res = errBld.ToString().Trim();
            errBld.Clear();
            return res;
        }
    }
}
