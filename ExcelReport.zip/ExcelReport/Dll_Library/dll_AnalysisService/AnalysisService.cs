﻿using System;
using System.Collections.Generic;
using Microsoft.AnalysisServices;

namespace dll_AnalysisService
{
    public class AnalysisService
    {
        /// <summary>
        /// Пример добавления роли 
        /// </summary>
        /// <param name="strDbServerName">Имя сервера</param>
        /// <param name="catalogName">Имя куба</param>
        /// <param name="roleName">Имя роли</param>
        /// <param name="memberName">Учетная запись добавляемого пользователя</param>
        public static void AddMemberSample(string strDbServerName, string catalogName, string roleName, string memberName)
        {
            string strConnection = string.Format("Data Source={0};Provider=MSOLAP;Initial Catalog={1};", strDbServerName, catalogName);
            var server = new Server();
            server.Connect(strConnection);
            var db = server.Databases.GetByName(catalogName);
            if (db.Roles.ContainsName(roleName))
            {
                var role = db.Roles.GetByName(roleName);
                role.Members.Add(new RoleMember(memberName));
                role.Update();
            }
            server.Disconnect();
        }




        private Database db;
        Server server;

        public void Disconnect()
        {
            server.Disconnect();
        }

        public bool CheckState(string cubeName)
        {
            //db = server.Databases.GetByName(cubeName);
            //if (db != null && db.State == AnalysisState.Unprocessed) 
            //    return true;
            //else return false;
            return true;
        }

        public void UpdateDB()
        {
            //if (db != null && db.State == AnalysisState.Unprocessed)
            {
                db.Update();
            }
        }
        
        public void ConnectAnalysisServices(string strDBServerName, string catalogName, out string error)
        {
            error = string.Empty;
            try
            {
                server = new Server();
                string strConnection = "Data Source=" + strDBServerName + ";Provider=" + "MSOLAP" +
                                        ";Initial Catalog=" + catalogName + ";";
                //Disconnect from current connection if it's currently connected.
                if (server.Connected)
                    server.Disconnect();

                server.Connect(strConnection);
            }
            catch (Exception ex)
            {
                error = "ConnectAnalysisServices func: " + ex.Message;
            }
        }

        public Role GetRole(string roleName, out string err)
        {
            Role role;
            err = string.Empty;
            if (!db.Roles.ContainsName(roleName))
            {
                role = null;
                err = "GetRole: Такой роли не существует!";
            }
            else
            {
                //Role already exists with the same name
                role = db.Roles.GetByName(roleName);
            }
            return role;
        }

        public void AssignMember(Role role, string memberName)
        {
            role.Members.Add(new RoleMember(memberName));
        }

        
        public void DeleteMember(Role role, string memberName)
        {
            RoleMember delrole = null;
            foreach (RoleMember e in role.Members)
            {
                if (e.Name.ToUpper() == memberName.ToUpper())
                {
                    delrole = e;
                    break;
                }
            }

            if (delrole != null)
                role.Members.Remove(delrole);
        }

        private List<string> _getWrongMembers(Role role)
        {
            var delRole = new List<RoleMember>();
            
            var ret = new List<string>();
            var distinctRet = new List<string>();
            foreach (RoleMember elr in role.Members)
            {
                var iscont = false;
                if (!distinctRet.Contains(elr.Name))
                {
                    distinctRet.Add(elr.Name);
                    iscont = true;
                }

                if (elr.Name == elr.Sid)
                {
                    ret.Add(elr.Name);
                    delRole.Add(elr);
                }
                else
                {
                    if (distinctRet.Contains(elr.Name) && !ret.Contains(elr.Name) && !iscont)
                        ret.Add(elr.Name);
                }
            }

            foreach (RoleMember eldel in delRole)
                role.Members.Remove(eldel);
            role.Update();

            return ret;
        }

        public void DeleteWrongMembers(string roleName, string cubeName)
        {
            string errRole = string.Empty;
            db = server.Databases.GetByName(cubeName);
            Role role = GetRole(roleName, out errRole);
            var wrmem = _getWrongMembers(role);
            var listRole = new List<RoleMember>();
           
            foreach (var fm in wrmem)
            {
                bool isfirst = false;
                foreach (RoleMember elr in role.Members)
                {
                    if (elr.Name.ToUpper() == fm.ToUpper() && isfirst)
                    {
                        listRole.Add(elr);
                    }
                    if (elr.Name.ToUpper() == fm.ToUpper() && !isfirst)
                        isfirst = true;
                }
            }

            foreach (RoleMember eldel in listRole)
                role.Members.Remove(eldel);
            role.Update();
        }

        public void DeleteNotFound(List<string> fileMembers, string roleName, string cubeName)
        {
                string errRole = string.Empty;
                db = server.Databases.GetByName(cubeName); //server.Databases[cubeName];
                //if (db.State == AnalysisState.Unprocessed)
                {
                    Role role = GetRole(roleName, out errRole);
                    if (!string.IsNullOrEmpty(errRole)) throw new Exception(errRole);
                    var listRole = new List<RoleMember>();

                    foreach (RoleMember elr in role.Members)
                    {
                        bool isexists = false;
                        foreach (var fm in fileMembers)
                        {
                            if (elr.Name.ToUpper() == fm.ToUpper())
                            {
                                isexists = true;
                                break;
                            }
                        }
                        if (!isexists)
                            listRole.Add(elr);
                    }
                    foreach (RoleMember eldel in listRole)
                        role.Members.Remove(eldel);
                    role.Update();
                }
        }

        public bool AddNewMembers(string NewMember, string roleName, string cubeName, out string err)
        {
            err = string.Empty;
            var ret = false;
            string errRole = string.Empty;
            string errTry = string.Empty;
            try
            {
                db = server.Databases.GetByName(cubeName);
                //if (db.State == AnalysisState.Unprocessed)
                {
                    Role role = GetRole(roleName, out errRole);
                    foreach (RoleMember elr in role.Members)
                    {
                        if (elr.Name.ToUpper() == NewMember.ToUpper())
                        {
                            ret = true;
                            break;
                        }
                    }

                    if (!ret)
                    {
                        AssignMember(role, NewMember);
                        //ValidationErrorCollection errc = new ValidationErrorCollection();
                        //role.Validate(errc);
                        //role.Update(UpdateOptions.AlterDependents, UpdateMode.Update);
                        role.Update();
                    }
                }
            }
            catch (Exception e)
            {
                errTry = "AddNewMembers: " + e.Message;
            }
            finally
            {
                err += errRole + errTry;
            }
            return ret;
        }

        public void DeleteMembers(string deleteMemb, string roleName, string cubeName, out string err)
        {
            err = string.Empty;
            string errRole = string.Empty;
            string errTry = string.Empty;
            try
            {
                db = server.Databases.GetByName(cubeName);
                //if (db.State == AnalysisState.Unprocessed)
                {
                    Role role = GetRole(roleName, out errRole);
                    DeleteMember(role, deleteMemb);
                    role.Update();
                }
            }
            catch (Exception e)
            {
                errTry = "DeleteMembers: " + e.Message;
            }
            finally
            {
                err += errRole + errTry;
            }
        }

        //public void DriverMethod()
        //{
        //    string err;
        //    Server server = (Server)ConnectAnalysisServices(@"finucubes", "MSOLAP", "ЧОД", out err);
        //    db = server.Databases["ЧОД"];

        //    string roleName = "Terbank";
        //    string errRole;
        //    Role role = GetRole(roleName, out errRole);
        //    AssignMember(role, @"SZB-HQ\0000User3");

        //    role.Update();
        //    db.Update();
        //    server.Disconnect();
        //}
    }
}
