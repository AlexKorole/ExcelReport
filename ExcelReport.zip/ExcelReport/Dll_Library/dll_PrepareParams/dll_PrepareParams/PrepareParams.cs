﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data.OracleClient;

namespace dll_PrepareParams
{
    /// <summary>
    /// Получаем параметры из json строк
    /// </summary>
    public class PrepareParams
    {
        public static string getParamFromNamedArray(string param, string name, char splitter)
        {
            name = name.ToUpper();
            string ret = string.Empty;
            var ar = param.Split(splitter);
            foreach (var d in ar)
            {
                if (d.ToUpper().StartsWith(name))
                {
                    var elem = d.Split('=');
                    if (elem.Length > 1)
                    {
                        ret = elem[1];
                        break;
                    }
                }
            }
            return ret;
        }

        public static List<OracleParameter> MakeInputParamList(string input_params, string query)
        {
            List<OracleParameter> ret = null;
            if (!string.IsNullOrEmpty(input_params) && !string.IsNullOrEmpty(query))
            {
                ret = new List<OracleParameter>();
                var reg = new Regex(":.+[,)]", RegexOptions.IgnoreCase);
                var match = reg.Match(query);
                while (match.Success)
                {
                    var paramName = match.ToString();
                    paramName = paramName.Replace(":", "").Replace(",", "").Replace(")", "");
                    var value = getParamFromNamedArray(input_params, paramName.Replace("v_", ""), ';');
                    var p = new OracleParameter(paramName, value);
                    p.OracleType = OracleType.VarChar;
                    p.Size = value.Length;
                    ret.Add(p);
                    match = match.NextMatch();
                }
            }
            return ret;
        }
    }
}
