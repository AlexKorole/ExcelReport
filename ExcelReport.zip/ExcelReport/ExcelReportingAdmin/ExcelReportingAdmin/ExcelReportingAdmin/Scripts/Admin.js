﻿var prevReportsName;
function Load() {
    InitReportsPart();
    $("#tReportsName").empty();
    $("#tReportsName").append(MakeReportNameList());
    var url = document.location.href;
    var start = url.indexOf('report' + '=');
    if (start != -1)
        $("#reportHeader").val(decodeURIComponent(url.substring(start, url.length).split('=')[1]));
    else {
        if ($("#serverReportName").val().length > 0) {
            $("#reportHeader").val($("#serverReportName").val());
            $("#serverReportName").val("");
        } else 
            clearTemplate();
    }
    $("#iSecurity").val($("#serverSecurity").val());

    $("#lblTek").text($("#hdnTemplateName").val());
    $("#txtTemplSheetName").val($("#hdnTemplSheetName").val());
    
    if ($("#lblTek").text().length > 0)
        $("#btnDelTemplate").show();
    else $("#btnDelTemplate").hide();
}

function initRowNumTemplate(s, e) {
    if ($("#hdnTemplateRowNum").val().length == 0) {
        txtRowNum.SetValue(0);
    } else {
        var v = parseInt($("#hdnTemplateRowNum").val());
        if (!isNaN(v))
            txtRowNum.SetValue(v);
    }
}

function InitReportsPart() {
    if ($("#clearReportPart").val() != "1") {
        if ($("#serverQuery").val() != "" && $("#serverQuery").val() != "undefined") {
            $("#taInputSelect").val($("#serverQuery").val());
        }
        if ($("#serverParamsName").val() != "" && $("#serverParamsName").val() != "undefined") {
            $("#tParams").append(makeParamListFromServer());
        }
    } else {
        $("#taInputSelect").val("");
        $("#tParams").empty();
        $("#serverQuery").val("");
        $("#serverParamsName").val("");
        $("#clearReportPart").val("0");
        $("#serverSecurity").val("");
    }

    if($("#hdnIsStoredProcFlag").val() == "stored")
    {
        $('#cbIsStroedProc').attr('checked', 'checked');
    }
}

function MakeReportNameList() {
    var addStr = "";
    var arr = $("#hdnReportList").val().split(";");
    for (var i = 0; i < arr.length; i++) {
        var url = document.location.href;
        addStr += "<tr><td><a href='" + url.substring(0, url.indexOf('?')) + "?report=" + encodeURIComponent(arr[i]) + "'>" + arr[i] + "</a></td><tr>";
    }
    return addStr;
}

function makeParamListFromServer() {
    var pname = $("#serverParamsName").val().split(";");
    var pviewname = $("#serverParamsViewName").val().split(";");
    var ptype = $("#serverParamsType").val().split(";");
    var pminval = $("#serverParamsMinVal").val().split(";");
    var pmaxval = $("#serverParamsMaxVal").val().split(";");

    var addStr = "";
    if (pname.length > 0) {
        var headerName = "<thead><tr><th>Параметр</th><th>Название</th><th>Тип</th><th>Min значение</th><th>Max значение</th></tr></thead><tbody>";
            addStr += headerName;
            for (var i = 0; i < pname.length; i++) {
                var name = "<td>" + pname[i] + "</td>";
                var viewname = "<td><input id='view" + pname[i].replaceAll(' ','_') + "' type='text' value='" + pviewname[i] + "'></input></td>";
                var type = "<td><select id='type" + pname[i].replaceAll(' ', '_') + "'><option " + (ptype[i] == "String" ? "selected" : "") + ">String</option><option " + (ptype[i] == "DateTime" ? "selected" : "") + ">DateTime</option><option " + (ptype[i] == "Number" ? "selected" : "") + ">Number</option><option " + (ptype[i] == "StrList" ? "selected" : "") + ">StrList</option><option " + (ptype[i] == "StrMulti" ? "selected" : "") + ">StrMulti</option></select></td>";
                var minval = '<td><input id="min' + pname[i].replaceAll(' ', '_') + '" type="text" value="' + (pminval[i]?pminval[i].replaceAll('\"', '&quot;'):"") + '"></input></td>';
                var maxval = '<td><input id="max' + pname[i].replaceAll(' ', '_') + '" type="text" value="' + (pmaxval[i] ? pmaxval[i].replaceAll('\"', '&quot;') : "") + '"></input></td>';
                addStr += "<tr>" + name + viewname + type + minval + maxval + "</tr>";
            }
            addStr += "</tbody>";
    }
    return addStr;
}

String.prototype.replaceAll = function (search, replace) {
    return this.split(search).join(replace);
}

function btnSaveClick(onlyclient) {
    document.getElementById("btnViewReport").disabled = false;
    $("#serverParamsViewName").val("");
    $("#serverParamsType").val("");
    $("#serverParamsMinVal").val("");
    $("#serverParamsMaxVal").val("");
    var viewname = "";
    var type = "";
    var minval = "";
    var maxval = "";

    var pname = $("#serverParamsName").val().split(";");
    for (var i = 0; i < pname.length; i++) {
        viewname += $("#" + "view" + pname[i].replaceAll(' ', '_')).val();
        type += $("#" + "type" + pname[i].replaceAll(' ', '_')).val();
        minval += $("#" + "min" + pname[i].replaceAll(' ', '_')).val();
        maxval += $("#" + "max" + pname[i].replaceAll(' ', '_')).val();

        if (i != pname.length - 1) {
            viewname += ";";
            type += ";";
            minval += ";";
            maxval += ";";
        }
    }
    $("#serverSecurity").val($("#iSecurity").val());
    $("#serverReportName").val($("#reportHeader").val());
    $("#serverQuery").val($("#taInputSelect").val());

    $("#serverParamsViewName").val(viewname);
    $("#serverParamsType").val(type);
    $("#serverParamsMinVal").val(minval);
    $("#serverParamsMaxVal").val(maxval);

    $("#hdnTemplateRowNum").val(txtRowNum.GetText());
    $("#hdnTemplSheetName").val($("#txtTemplSheetName").val());
    if (onlyclient != "true")
        document.getElementById("hdnSave").click();
}

function ParseText() {
    document.getElementById("btnViewReport").disabled = true;
    $("#serverParamsName").val("");
    $("#serverParamsViewName").val("");
    $("#serverParamsType").val("");
    $("#serverParamsMinVal").val("");
    $("#serverParamsMaxVal").val("");

    var s = $("#taInputSelect").val();
    //quickExpr = /:[A-Za-z]\w+/gim; без пробела
    quickExpr = / :[A-Za-z]\w+/gim;
    match = s.match(quickExpr);
    $("#tParams").empty();
    if (match != null && match.length > 0) {
        var elemToServer = "";
        for (var i = 0; i < match.length; i++) {
            var elem = match[i];
            //if (i != match.length - 1) {
            if (elemToServer.indexOf(elem) == -1)
                elemToServer += elem + ";";
            //}
        }
        elemToServer = elemToServer.substring(0, elemToServer.length - 1);
        //elemToServer = elemToServer.split(":").join(""); без пробела
        elemToServer = elemToServer.split(" :").join("");
    }
    $("#serverParamsName").val(elemToServer);

    if ($("#serverParamsName").val() != "" && $("#serverParamsName").val() != "undefined") {
        $("#tParams").append(makeParamListFromServer());
    }
}

function OpenViewReport() {
    btnSaveClick("true");
    var arr = new window.Array(
    $("#serverQuery").val(),
    $("#serverParamsName").val(),
    $("#serverParamsViewName").val(),
    $("#serverParamsType").val(),
    $("#serverParamsMinVal").val(),
    $("#serverParamsMaxVal").val(),
    $("#serverReportName").val(),
    $("#hdnTemplateRowNum").val(),
    $("#hdnTemplSheetName").val()
    );
    // window.showModalDialog("ViewReport.aspx", arr, "dialogHeight:600px;dialogWidth:800px; scroll:no;status:no");
    //window.showModelessDialog("ViewReport.aspx", arr, "dialogHeight:0px;dialogWidth:0px; scroll:no;status:no");
    window.arr = arr;
    window.open("ViewReport.aspx", "_blank");//, "dialogHeight:0px;dialogWidth:0px; scroll:no;status:no");
}

function SetIsStoredProcedure(checkbox) {
    if ($('#cbIsStroedProc').attr('checked')) {
        $("#hdnIsStoredProcFlag").val("stored");
    } else {
        $("#hdnIsStoredProcFlag").val("");
    }
}


function TemplateUploadStart(s, e) {
    $("#serverReportName").val($("#reportHeader").val());
}

function TemplateUploadComplete(s, e) {
    var error = GetParamFromMParams(e.callbackData, "error");
    var value = GetParamFromMParams(e.callbackData, "value");

    if (error.length > 0)
        alert(e.callbackData);
    else {
        $("#hdnTemplateName").val(value);
        btnSaveClick();
    }
}
