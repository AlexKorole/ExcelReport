﻿function btnAddNewClick() {
    var newuser = tbNewUser.GetText();
    lbRead.PerformCallback("addNewUser;" + newuser);
}


function btnDelUsrClick() {
    var delUser = lbRead.GetValue();
    lbRead.PerformCallback("delUser;" + delUser);
}