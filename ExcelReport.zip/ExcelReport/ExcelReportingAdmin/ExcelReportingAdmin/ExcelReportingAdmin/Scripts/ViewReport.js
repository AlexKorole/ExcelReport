﻿function LoadViewReport() {
    if ($("#hRowNum") && $("#hRowNum").val() && $("#hRowNum").val().length > 0) {
        lblRowNum.SetText("Получено строк = " + $("#hRowNum").val());
        $("#hRowNum").val("");
    }

    if ($("#firstLoad").val() != "n") {
        var params = getCookie("clientParam");
        document.cookie = "clientParam=;expires=-1";

        var arr = null;
        if (!params) {
            if (window.opener != null && window.opener != undefined &&
                window.opener.arr != null && window.opener.arr != undefined) {
                arr = window.opener.arr;
            } else {
                var params = window.location.search.substring(1);
                arr = decodeURIComponent(params.substring(4, params.length)).split('~');
            }
        } else arr = params.split('~');

        $("#serverQuery").val(arr[0]);
        $("#serverParamsName").val(arr[1]);
        $("#serverParamsViewName").val(arr[2]);
        $("#serverParamsType").val(arr[3]);
        $("#serverParamsMinVal").val(arr[4]);
        $("#serverParamsMaxVal").val(arr[5]);
        $("#serverReportName").val(arr[6]);
        $("#hdnTemplateRowNum").val(arr[7]);
        $("#hdnTemplSheetName").val(arr[8]);
        $("#firstLoad").val("n");
        document.getElementById("hdnLoad").click();
        //setTimeout(function () { }, 3000);
        //window.close();
    } else 
        SetParamValues();
}

var IntervalId;

function GetParamValues(isColumn) {
    lblError.SetText("");
    lblStatus.SetText("Подождите, идет загрузка...");
    $("#serverParamValues").val();
    var arr = $("#serverParamsName").val().split(';');
    var arrtype = $("#serverParamsType").val().split(';');
    if (arr.length > 0) {
        var vals = "";
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == "") continue;
            var eell = ASPxClientControl.GetControlCollection().GetByName(arr[i]);
            if (eell == null) continue;
            var elem = eell.GetValue();
            if (elem != null) {
                switch (arrtype[i]) {
                    case "DateTime":
                        elem = elem.getDate().toString() + "." + (elem.getMonth() + 1).toString() + "." + elem.getFullYear().toString();
                        break;
                    case "Number":
                        elem = elem.toString();
                        break;
                    case "StrMulti":
                        var sv = eell.GetSelectedValues();
                        for (var j = 0; j < sv.length; j++) {
                            sv[j] = "'" + sv[j] + "'";
                        }
                        elem = sv.join(',');
                        break;
                    default:
                        break;
                }
                vals += elem + ";";
            } else vals += ";";
        }
        vals = vals.substring(0, vals.length - 1);
        $("#serverParamValues").val(vals);
        
        //var fileName = window.location.pathname.substring(window.location.pathname.lastIndexOf('/') + 1);
        //if (fileName != 'ViewReportLong.aspx') {
            //var dateStart = new Date();
            //IntervalId = window.setInterval(function () {
            //    var cookie = getCookie('fileDownloadToken');
            //    if (cookie == 'finished') {
            //        lblStatus.SetText("");
            //        document.cookie = 'fileDownloadToken=empty';
            //        btnExcel.SetEnabled(true);
            //        clearInterval(IntervalId);
            //    }
            //    else {
            //        var difInSeconds = Math.floor(((new Date()).getTime() - dateStart.getTime()) / 1000);
            //        var hours = Math.floor(difInSeconds / 3600);
            //        var minutes = Math.floor((difInSeconds - (hours * 3600)) / 60);
            //        var seconds = difInSeconds - (hours * 3600) - (minutes * 60);

            //        if (hours < 10) hours = "0" + hours;
            //        if (minutes < 10) minutes = "0" + minutes;
            //        if (seconds < 10) seconds = "0" + seconds;

            //        lblStatus.SetText("Подождите, идет загрузка... " + hours + ":" + minutes + ":" + seconds);
            //    }
            //}, 1000);
        //}
        
            btnExcel.SetEnabled(false);
            var f = $('table *');
            for (var i = 0; i < f.length; i++) {
                f[i].disabled = true;
            }

            if (isColumn == "column")
                LoadColumnsByWebMethod();
            else LoadByWebMethod();
        //document.getElementById("hdnSave").click();
        
    }
}

function SetParamValues() {
    var arr = $("#serverParamsName").val().split(';');
    var arrtype = $("#serverParamsType").val().split(';');
    var valsAll = $("#serverParamValues").val();
    if (!(valsAll != null && valsAll != "")) return;
    var vals = valsAll.split(';');
    if (vals.length == 0) return;
    var j = 0;
    if (arr.length > 0) {
        for (var i = 0; i < arr.length; i++) {
            var elem = ASPxClientControl.GetControlCollection().GetByName(arr[i]);
            if (elem != null) {
                switch (arrtype[i]) {
                    case "DateTime":
                        if (vals[j] != null && vals[j] != undefined && vals[j].length > 0) {
                            var dd = vals[j].split('.');
                            var d = parseInt(dd[0]);
                            var m = parseInt(dd[1]);
                            var y = parseInt(dd[2]);
                            if (!isNaN(d) && !isNaN(m) && !isNaN(y)) 
                                elem.SetValue(new Date(y, m - 1, d));
                        }
                        break;
                    case "Number":
                        try
                        {
                            if ('SetText' in elem)
                                elem.SetText(vals[j]);
                            else elem.SetValue(vals[j]);
                        } catch(err)
                        {};
                        break;
                    default:
                        if ('SetText' in elem)
                            elem.SetText(vals[j]);
                        else elem.SetValue(vals[j]);
                        break;
                }
                j++;
            }
        }
    }
}