﻿using System;
using System.Collections.Generic;
using SerializeObj;
using System.Xml.Serialization;
using System.IO;
using ExcelReportingAdmin.ASPBackend;


namespace ExcelReportingAdmin
{
    public partial class Connections : System.Web.UI.Page
    {
        //private void loadCon()
        //{
        //    var listDBcon = Common.loadCon(Session, true);
        //    tbConStr.Text = listDBcon[0].value;
        //}

        
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    loadCon();
            //}
        }

        //protected void btnSaveCon_Click(object sender, EventArgs e)
        //{
        //    var dbcon = new DBConnection();
        //    dbcon.type = "Oracle";
        //    dbcon.value = tbConStr.Text;

        //    var listDBcon = new List<DBConnection>();
        //    listDBcon.Add(dbcon);

        //    object locker = new object();
        //    lock (locker)
        //    {
        //        var serialize = new XmlSerializer(typeof(List<DBConnection>));
        //        var connectionFile = System.Configuration.ConfigurationManager.AppSettings["connectionFile"];
        //        var wfs = new StreamWriter(connectionFile);
        //        serialize.Serialize(wfs, listDBcon);
        //        wfs.Close();
        //    }
        //    loadCon();
        //}
    }
}