﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;

namespace ExcelReportingAdmin.ASPBackend
{
    public class ViewReportLongBackEnd
    {
        private static string PrepareDir(string userName, string tempPath)
        {
            string newDir = userName.Replace(@"\", "");
            var newpath = tempPath + (tempPath.EndsWith(@"\")?"":@"\") + newDir + @"\";
            if (!Directory.Exists(newpath))
                Directory.CreateDirectory(newpath);
            return newpath;
        }

        public static string PrepareFileName(string reportName, string userName, string tempPath)
        {
            string fileName = string.Empty;
            var shortName = Common.MakeShortName(reportName);
            var newpath = ViewReportLongBackEnd.PrepareDir(userName, tempPath);
            var files = Directory.GetFiles(newpath);
            string origname = shortName;

            try
            {
                DeleteTmpFiles(files, origname);
            } catch(Exception ex)
            {
                Logger.Log.Inst.ErrorToLog(ex, 
                                           HttpContext.Current.Request.LogonUserIdentity.Name, 
                                           "Функция PrepareFileName (создаем файл для сохранения отчетов)", null, reportName);
            }
            
            int i = FindFiles(files, origname);
            var origOrig = origname;
            if (i > 0)
                origname += i.ToString();

            int j = 1;
            while(j > 0)
            {
                j = FindFiles(files, origname + "_temp");
                if (j > 0)
                    origname = origOrig + (++i).ToString();
            }
            fileName = newpath + origname + ".xlsx";
            return fileName;
        }

        private static void DeleteTmpFiles(string[] files, string origname)
        {
            var fArr = new List<string>();
            foreach (var f in files)
            {
                var fClear = Regex.Replace(f, "[0-9]*_temp\\.xlsx", "", RegexOptions.IgnoreCase);
                if (f.EndsWith("_temp.xlsx") && fClear.EndsWith(origname))
                {
                    try
                    {
                        var t = File.GetCreationTime(f);
                        if (t < DateTime.Today)
                            File.Delete(f);
                    }
                    catch(Exception ex)
                    {
                        Logger.Log.Inst.ErrorToLog(ex,
                                           HttpContext.Current.Request.LogonUserIdentity.Name,
                                           "Функция DeleteTmpFiles (удаляем временный файл с данными!)", null, origname);
                    };
                }
            }
        }

        private static int FindFiles(string[] files, string origname)
        {
            string shortName = origname;
            var fArr = new List<string>();
            foreach (var f in files)
            {
                var cf = Path.GetFileName(f);
                var fClear = Regex.Replace(cf, "[0-9]*\\.xlsx", "", RegexOptions.IgnoreCase);
                if (fClear.EndsWith(shortName))
                {
                    fArr.Add(f);
                }
            }

            int i = 0;
            foreach (var f in fArr)
            {
                var cf = Path.GetFileName(f);
                var r1 = Regex.Replace(cf, ".xlsx", "", RegexOptions.IgnoreCase);
                var matches = Regex.Match(r1, "[0-9]+$", RegexOptions.IgnoreCase);
                var fNumber = string.Empty;
                if(matches.Success)
                    fNumber = matches.Value;
                int res;
                if (int.TryParse(fNumber, out res))
                {
                    if (i < res) i = res;
                }
            }
            if (i > 0 || fArr.Count > 0) i++;
            return i;
        }
    }
}