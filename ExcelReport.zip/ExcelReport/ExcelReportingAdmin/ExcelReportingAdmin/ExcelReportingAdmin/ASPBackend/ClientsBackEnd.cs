﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;
using SerializeObj;
using System.Xml.Serialization;
using System.Web.UI.WebControls;
using System.Web.SessionState;
using System.Reflection;
using CheckAccess;


namespace ExcelReportingAdmin.ASPBackend
{
    public class ClientsBackEnd
    {
        public static void initFile(DBConnection con, string query, string file, HiddenField hdnReportList, HttpSessionState Session, string curruser, out string errMess, string path)
        {
            Dictionary<string, Element> repDict;
            hdnReportList.Value = MakeReportNameList(con, query, file, out repDict, curruser, out errMess, path);
            Session[SessionNames.hdnReportList] = hdnReportList.Value;
            Session[SessionNames.currentElements] = repDict;
        }

        static object locker = new object();
        public static string MakeReportNameList(DBConnection con, string query, string fileName, out Dictionary<string, Element> repDict, string curruser, out string errMess, string path)
        {
            repDict = null;
            var res = string.Empty;
            errMess = string.Empty;
            var rfile = System.Configuration.ConfigurationManager.AppSettings["SourceDir"] + fileName + ".xml";
            var rf = new FileStream(rfile, FileMode.Open, FileAccess.Read, FileShare.Read);
            //var rf = new StreamReader(rfile, System.Text.Encoding.GetEncoding(1251), true);
            try
            {
                var serialize = new XmlSerializer(typeof (List<Element>));

                List<Element> elemList = null;
               lock (locker)
                {
                    elemList = (List<Element>) serialize.Deserialize(rf);
                }

                if (elemList.Count > 0)
                {
                    repDict = new Dictionary<string, Element>();
                    Access acc = new Access();
                    foreach (var el in elemList)
                    {
                        var isaccessed = false;
                        var finuSecurity = System.Configuration.ConfigurationManager.AppSettings["DBSecurity"];
                        if (finuSecurity == "true")
                        {
                            if (acc.CheckAccess(con, query, curruser, el.SecurityGroup, out errMess))
                                isaccessed = true;
                            else if (acc.CheckAccess(con, query, curruser, "Администраторы", out errMess))
                            {
                                //else if (acc.CheckAccess(@"SZB-HQ\KorolevAD", "Администраторы"))
                                isaccessed = true;
                            }
                        }
                        else
                        {
                            isaccessed = Common.checkSecurityLocal(acc, curruser, path);
                        }

                        if (isaccessed)
                        {
                            res += el.name + ";";
                            repDict.Add(el.name, el);
                        }
                    }
                    res = res.Remove(res.Length - 1);
                }
            }
            catch(Exception err)
            {
                Logger.Log.Inst.ErrorToLog(err,
                   HttpContext.Current.Request.LogonUserIdentity.Name,
                   "Функция ClientsBackEnd.MakeReportNameList (загружаем список отчетов!)", null, "Загружаем список отчетов");
            }
            finally
            {
                rf.Close();
            }
            return res;
        }

        public static void loadElement(HiddenField hdnTemplateRowNum, HiddenField hdnTemplSheetName, HiddenField serverSecurity, HiddenParams sP, HttpRequest Request, HttpSessionState Session)
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["report"] != null)
                {
                    if (Session[SessionNames.currentElements] is Dictionary<string, Element>)
                    {
                        var d = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                        var qs = Uri.UnescapeDataString(Request.QueryString["report"].ToString());
                        if (d.ContainsKey(qs))
                        {
                            Session[SessionNames.CurrentReportName] = Request.QueryString["report"].ToString();
                            serverSecurity.Value = d[Request.QueryString["report"].ToString()].SecurityGroup;
                            var paramList = d[Request.QueryString["report"].ToString()].paramList;
                            HiddenParams.FillParams(sP, paramList);
                            hdnTemplateRowNum.Value = d[qs].rowNumInTemplate.ToString();
                            hdnTemplSheetName.Value = d[qs].TemplSheetName != null ? d[qs].TemplSheetName.ToString() : string.Empty;
                        } else  
                            HttpContext.Current.Response.Redirect(@"AccessDenied.htm");
                    }

                    PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
                    isreadonly.SetValue(Request.QueryString, false, null);
                    Request.QueryString.Remove("report");
                }
            }
        }
    }
}