﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Xml.Serialization;
using SerializeObj;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.SessionState;
using System.Reflection;

namespace ExcelReportingAdmin.ASPBackend
{
    public class AdminBackEnd
    {
        public static void initFile(DBConnection con, string query, string file, HiddenField hdnReportList, HttpSessionState Session, string curruser, out string errMess, string path)
        {
            Dictionary<string, Element> repDict;
            hdnReportList.Value = Common.MakeReportNameList(con, query, file, out repDict, curruser, out errMess, path);
            Session[SessionNames.hdnReportList] = hdnReportList.Value;
            Session[SessionNames.currentElements] = repDict;
        }

        public static void loadElement(HiddenField hdnIsStoredProcFlag, HiddenField serverQuery, HiddenField hdnTemplateRowNum, HiddenField hdnTemplSheetName, HiddenField serverSecurity, HiddenParams sP, HttpRequest Request, HttpSessionState Session, HttpServerUtility Server)
        {
            if (Request.QueryString.Count > 0)
            {
                if (Request.QueryString["report"] != null)
                {
                    var qs = Uri.UnescapeDataString(Request.QueryString["report"].ToString());
                    //var qs = Server.UrlDecode(Request.QueryString["report"].ToString());
                    if (Session[SessionNames.currentElements] is Dictionary<string, Element>)
                    {
                        var d = Session[SessionNames.currentElements] as Dictionary<string, Element>;
                        if (d.ContainsKey(qs))
                        {
                            Session[SessionNames.CurrentReportName] = qs;
                            serverQuery.Value = d[qs].query;
                            hdnIsStoredProcFlag.Value = d[qs].IsStoredProcedure?"stored":"";
                            serverSecurity.Value = d[qs].SecurityGroup;
                            var paramList = d[qs].paramList;
                            HiddenParams.FillParams(sP, paramList);
                            hdnTemplateRowNum.Value = d[qs].rowNumInTemplate.ToString();
                            hdnTemplSheetName.Value = d[qs].TemplSheetName != null?d[qs].TemplSheetName.ToString(): string.Empty;
                        }
                    }

                    PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
                    isreadonly.SetValue(Request.QueryString, false, null);
                    Request.QueryString.Remove("report");
                }
            }
        }

        public static string[] LoadFiles(HttpSessionState Session, DropDownList dlFiles)
        {
            /*var files = Directory.GetFiles(System.Configuration.ConfigurationManager.AppSettings["SourceDir"]);
            for (int i = 0; i < files.Length; i++)
            {
                files[i] = files[i].Replace(System.Configuration.ConfigurationManager.AppSettings["SourceDir"], "").Replace(".xml", "");
            }
            Session[SessionNames.files] = files;
            dlFiles.DataSource = files;
            dlFiles.DataBind();
            dlFiles.SelectedIndex = 0;
            Session[SessionNames.FilesSelectedIndex] = 0;*/

            var files = new[] { (System.Configuration.ConfigurationManager.AppSettings["ClientFileName"]) };
            Session[SessionNames.files] = files;
            dlFiles.DataSource = files;
            dlFiles.DataBind();
            dlFiles.SelectedIndex = 0;
            Session[SessionNames.FilesSelectedIndex] = 0;
            return files;
        }

        static object locker = new object();
        public static void SerializeChanges(Dictionary<string, Element> elements, string filename)
        {
            var elemList = new List<Element>();
            foreach (var el in elements.Values)
            {
                elemList.Add(el);
            }
            var serialize = new XmlSerializer(typeof(List<Element>));
            var rfile = System.Configuration.ConfigurationManager.AppSettings["SourceDir"] + filename + ".xml";
            lock (locker)
            {
                var wfs = new StreamWriter(rfile);
                serialize.Serialize(wfs, elemList);
                wfs.Close();
            }
        }
        
    }
}