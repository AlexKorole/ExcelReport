﻿namespace ExcelReportingAdmin.ASPBackend
{
    public class SessionNames
    {
        public const string hdnReportList = "hdnReportList"; //список отчетов в выбранном файле
        public const string files = "files"; //список файлов
        public const string FilesSelectedIndex = "FilesSelectedIndex"; //текущий выбранный файл
        public const string CurrentReportName = "CurrentReportName"; // текущее имя отчета
        public const string currentElements = "currentElements"; // текущие параметры отчета
        public const string divParamsControls = "divParamsControls"; //Сохранение контролов для отображения ViewReports
        public const string fileReports = "fileReports"; //

        public const string ConnectUser = "ConnectUser";
        public const string ConnectSystem = "ConnectSystem";
    }
}