﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Xml.Serialization;
using SerializeObj;
using System.IO;
using CheckAccess;
using System.Web.SessionState;
using System.Text.RegularExpressions;
using FileInfo;


namespace ExcelReportingAdmin.ASPBackend
{
    public class Common
    {
        public static string MakeShortName(string reportName)
        {
            var shortName = reportName.Replace("/", "_").Replace(@"\", "_");
            var isEndNumber = Regex.IsMatch(shortName, "[0-9]$", RegexOptions.IgnoreCase);
            if (isEndNumber) shortName = shortName + "_";
            return shortName;
        }


        static object locker = new object();
        public static string MakeReportNameList(DBConnection con, string query, string fileName, out Dictionary<string, Element> repDict, string curruser, out string errMess, string path)
        {
            repDict = null;
            var res = string.Empty;
            errMess = string.Empty;
            var rfile = System.Configuration.ConfigurationManager.AppSettings["SourceDir"] + fileName + ".xml";
            //var rf = new StreamReader(rfile, System.Text.Encoding.GetEncoding(1251), true);
            var rf = new FileStream(rfile, FileMode.Open, FileAccess.Read, FileShare.Read);
            try
            {
                var serialize = new XmlSerializer(typeof(List<Element>));
                List<Element> elemList = null;
                lock (locker)
                {
                    elemList = (List<Element>) serialize.Deserialize(rf);
                }
                
                if (elemList.Count > 0)
                {
                    repDict = new Dictionary<string, Element>();
                    Access acc = new Access();
                    foreach (var el in elemList)
                    {
                        var isaccessed = false;
                        var finuSecurity = System.Configuration.ConfigurationManager.AppSettings["DBSecurity"];
                        if (finuSecurity == "true")
                        {
                            if (acc.CheckAccess(con, query, curruser, "Администраторы", out errMess))
                            {
                                //else if (acc.CheckAccess(@"SZB-HQ\KorolevAD", "Администраторы"))
                                isaccessed = true;
                            }
                        }
                        else
                        {
                            isaccessed = Common.checkSecurityLocal(acc, curruser, path);
                        }

                        if (isaccessed)
                        {
                            res += el.name + ";";
                            repDict.Add(el.name, el);
                        }
                    }
                    //repDict = new Dictionary<string, Element>();
                    //foreach (var el in elemList)
                    //{
                    //    res += el.name + ";";
                    //    repDict.Add(el.name, el);
                    //}
                    res = res.Remove(res.Length - 1);
                }
            }
            catch(Exception e)
            {
                errMess = e.Message;
                Logger.Log.Inst.ErrorToLog(e,
                   HttpContext.Current.Request.LogonUserIdentity.Name,
                   "Функция Common.MakeReportNameList (загружаем список отчетов!)", null, "Загружаем список отчетов");
            }
            finally
            {
                rf.Close();
            }
            return res;
        }

        public static string setSecurity(DBConnection con, string query, Access acc, string userName, HttpResponse response, string path = "")
        {
            string errMsg = string.Empty;
            var finuSecurity = System.Configuration.ConfigurationManager.AppSettings["DBSecurity"];
            if (finuSecurity == "true")
            {
                if (!acc.CheckAccess(con, query, userName, "Администраторы", out errMsg))
                {
                    response.Redirect("AccessDenied.htm");
                }
            }
            else
            {
                var adminlocal = System.Configuration.ConfigurationManager.AppSettings["AdminLocal"];
                var users = LoadUsersFromFile(path);
                if (!acc.CheckAccessLocalUser(userName, users, adminlocal))
                {
                    response.Redirect("AccessDenied.htm");
                }
            }
            return errMsg;
        }

        public static bool checkSecurityLocal(Access acc,string userName, string path)
        {
            bool ret = false;    
            var adminlocal = System.Configuration.ConfigurationManager.AppSettings["AdminLocal"];
            var users = LoadUsersFromFile(path);
            if (acc.CheckAccessLocalUser(userName, users, adminlocal))
            {
                ret = true;
            }
            return ret;
        }

        public static List<string> LoadUsersFromFile(string path)
        {
            var query = File.ReadAllLines(path + @"Security\Read.txt");
            var listRead = new List<string>();
            foreach (var r in query)
                listRead.Add(r.Trim().ToUpper());
            return listRead;
        }

        static object locker2 = new object();
        public static DBConnection loadSystemCon(HttpSessionState Session, bool reload = false)
        {
            DBConnection DBcon = null;
            if (Session[SessionNames.ConnectSystem] == null || reload)
            {
                var connectionFile = System.Configuration.ConfigurationManager.AppSettings["connectionFile"];
                var rf = new FileStream(connectionFile, FileMode.Open, FileAccess.Read, FileShare.Read);
                var serialize = new XmlSerializer(typeof(List<DBConnection>));

               
                lock (locker2)
                {
                    var listDBcon = (List<DBConnection>)serialize.Deserialize(rf);
                    rf.Close();

                    foreach (var elem in listDBcon)
                    {
                        if (elem.type_Of_Usage == "System")
                        {
                            Session[SessionNames.ConnectSystem] = DBcon = elem;
                            break;
                        }
                    }
                }
            }
            else
                DBcon = Session[SessionNames.ConnectSystem] as DBConnection;
            return DBcon;
        }

        static object locker3 = new object();
        public static DBConnection loadUserCon(HttpSessionState Session, bool reload = false)
        {
            DBConnection DBcon = null;
            if (Session[SessionNames.ConnectUser] == null || reload)
            {
                var connectionFile = System.Configuration.ConfigurationManager.AppSettings["connectionFile"];
                var rf = new FileStream(connectionFile, FileMode.Open, FileAccess.Read, FileShare.Read);
                var serialize = new XmlSerializer(typeof(List<DBConnection>));
                lock (locker3)
                {
                    var listDBcon = (List<DBConnection>)serialize.Deserialize(rf);
                    rf.Close();

                    foreach (var elem in listDBcon)
                    {
                        if (elem.type_Of_Usage == "User")
                        {
                            Session[SessionNames.ConnectUser] = DBcon = elem;
                            break;
                        }
                    }
                }
            }
            else
                DBcon = Session[SessionNames.ConnectUser] as DBConnection;
            return DBcon;
        }


        //public static List<DBConnection> loadCon(HttpSessionState Session, bool reload = false)
        //{
        //    List<DBConnection> listDBcon = null;
        //    if (Session[SessionNames.ConnectList] == null || reload)
        //    {
        //        var connectionFile = System.Configuration.ConfigurationManager.AppSettings["connectionFile"];
        //        var rf = new FileStream(connectionFile, FileMode.Open, FileAccess.Read, FileShare.Read);
        //        var serialize = new XmlSerializer(typeof(List<DBConnection>));

        //        object locker = new object();
        //        lock (locker)
        //        {
        //            listDBcon = (List<DBConnection>)serialize.Deserialize(rf);
        //            rf.Close();
        //            Session[SessionNames.ConnectList] = listDBcon;
        //        }
        //    }
        //    else
        //        listDBcon = Session[SessionNames.ConnectList] as List<DBConnection>;
        //    return listDBcon;
        //}

        public static DBConnection PrepareBeforeCheckAccess(HttpSessionState Session, string path, out string query)
        {
            // Для терадаты берем данные непосредственно из неё
            DBConnection con = loadUserCon(Session);
            if (con.type != "Terradata")
                con = loadSystemCon(Session);
            query = FilePersister.ExecAccessFunc(File.ReadAllText,path + @"SQL\Access.txt");
            var acctable = System.Configuration.ConfigurationManager.AppSettings["AccessTable"];
            query = query.Replace("@AccessTable", acctable);
            return con;
        }
        
    }
}