﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Web;
using System.Text;
using System.Data.OracleClient;
using ExcelExport;
using System.IO;
using System.Threading;
using System.Globalization;
using SerializeObj;
using dll_DataLayer;
using System.Data;
using FileInfo;

namespace ExcelReportingAdmin.ASPBackend
{
    public class ExcelClick
    {
        string SessionID;
        string path;
        string username;
        bool isStoredProc;
        string query;
        string appPath;
        string queryPath;
        public DbConnection db_user_con;
        public DbConnection db_system_con;
        public string system_con_str;
        string templatePath;
        string templateRowNum;
        string _hdnTemplSheetName;
        private DBConnection ConfigCon;

        public volatile UInt32 TotalRows;

        public ExcelClick(string sessionID, DBConnection configCon, string Path, string Username, bool is_storedProc, string Query, string AppPath, string QueryPath, string TemplatePath, string TemplateRowNum, string hdnTemplSheetName)
        {
            SessionID = sessionID;
            ConfigCon = configCon;
            path = Path;
            username = Username;
            isStoredProc = is_storedProc;
            query = Query;
            appPath = AppPath;
            queryPath = QueryPath;

            int rnum;
            if (int.TryParse(TemplateRowNum, out rnum))
            {
                if (rnum > 0 && hdnTemplSheetName.Length > 0)
                    templatePath = TemplatePath;
            }
            templateRowNum = TemplateRowNum;
            _hdnTemplSheetName = hdnTemplSheetName;
            TotalRows = 0;
        }

        public static void SetColNamesFromFile(string reportName, string path)
        {
            if (reportName == "Реестр по корпоративному страхованию")
            {
                var l = File.ReadAllLines(path + @"SQL\reestr_corp.txt");
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }
            }
            
            if (reportName == "ЧОД в разрезе клиентов")
            {
                var l = File.ReadAllLines(path + @"SQL\ChodClients.txt");
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }

            }
            

            if (reportName == "Универсальный отчет")
            {
                var l = File.ReadAllLines(path + @"SQL\main_uni_cols.txt", System.Text.Encoding.GetEncoding(1251));
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }

            }

            if (reportName == "Универсальный отчет Гарантии")
            {
                var l = File.ReadAllLines(path + @"SQL\guar_uni_cols.txt", System.Text.Encoding.GetEncoding(1251));
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }

            }

            if (reportName == "Универсальный отчет блок Обеспечение")
            {
                var l = File.ReadAllLines(path + @"SQL\zal_uni_cols.txt", System.Text.Encoding.GetEncoding(1251));
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    if (arr.Length > 1)
                    {
                        var value = arr[1].Trim();
                        BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                    }
                }
            }

            if (reportName == "Универсальный отчет блок Доходы")
            {
                var l = File.ReadAllLines(path + @"SQL\doh_uni_cols.txt", System.Text.Encoding.GetEncoding(1251));
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (var el in l)
                {
                    var arr = el.Split('-');
                    var key = arr[0].Trim();
                    var value = arr[1].Trim();
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }

            }
        }

        private string SetColNamesFromOracleDB(string reportName, string appPath)
        {
            string err = string.Empty;
            var bt = new BaseTable();
            
            bt.setConAndPath(appPath, db_system_con);
            var paramList = new List<DbParameter>();
            paramList.Add(Queries.addParam(OracleType.VarChar, reportName, "reportname"));
            err = bt.Load("Select_UTL_REPORTS_COLUMN_NAMES_BY_REPORTNAME", paramList,
                                                    typeof(Enums.UTL_REPORTS_COLUMN_NAMES));
            if (bt.Rows.Count > 0)// && BaseExcel.ColumnNameList == null)
            {
                BaseExcel.ColumnNameList = new Dictionary<string, string>();
                foreach (DataRow el in bt.Rows)
                {
                    var key = bt.GetValueStringAnyRow(bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.BASECOLUMNNAME), el).Trim();
                    var value = bt.GetValueStringAnyRow(bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.EXCELCOLUMNNAME), el).Trim();
                    if (string.IsNullOrEmpty(value)) value = key;
                    BaseExcel.ColumnNameList.Add(key.ToUpper(), value);
                }
            }
            return err;
        }

        public string Run(string reportName, string serverParamsName, string serverParamsViewName, string serverParamsType, string serverParamValues)
        {
        //    Thread.Sleep(30000);
            var errBuilder = new StringBuilder();
            string shortName;
            string fileName;
            List<OraParameter> parameters;
            var res = PrepareForRun(reportName, serverParamsName, serverParamsViewName, serverParamsType, serverParamValues, out shortName, out fileName, out parameters, system_con_str);
            if(!res)
                return errBuilder.ToString().Trim();

            bool norows = false;
            string err;
            fileName = fileName.Replace(".xlsx", "_temp.xlsx");
            SetColNamesFromFile(reportName, appPath);
            var scerr = SetColNamesFromOracleDB(reportName, queryPath);
            
            if (!string.IsNullOrEmpty(scerr))
            {
                errBuilder.AppendLine(scerr);
            }

            if (!string.IsNullOrEmpty(templatePath))
            {
                FilePersister.ExecTemplateAction(FilePersister.DeleteOrCopyTemplate, fileName, templatePath);
            }
            var a = new BaseExcel(ConfigCon, query, parameters, fileName, shortName, isStoredProc, out norows, out err,
                                  reportName, templatePath, templateRowNum, _hdnTemplSheetName, username, system_con_str, ref TotalRows);
            if (!string.IsNullOrEmpty(err))
            {
                errBuilder.AppendLine(err);
            }
            else
            {
                var realFile = fileName.Replace("_temp.xlsx", ".xlsx");
                FilePersister.ExecTemplateAction(File.Move, fileName, realFile);
            }
            return errBuilder.ToString().Trim();
        }

        public string GetColumnName(string reportName, string serverParamsName, string serverParamsViewName, string serverParamsType, string serverParamValues, out string error)
        {
            error = string.Empty;
            var errBuilder = new StringBuilder();
            string shortName;
            string fileName;
            List<OraParameter> parameters;
            var res = PrepareForRun(reportName, serverParamsName, serverParamsViewName, serverParamsType, serverParamValues, out shortName, out fileName, out parameters, system_con_str);
            if (!res)
            {
                error = errBuilder.ToString().Trim();
                return "";
            }

            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            var r = new BaseDataReader(ConfigCon, isStoredProc);
            
            bool norows = false;
            string err;
            r.RunReader(query, parameters, true, out norows, out err, HttpContext.Current.Request.LogonUserIdentity.Name, system_con_str, reportName, ref TotalRows);
            errBuilder.AppendLine(err);

            var columns = r.Columns;

            var colBuilder = new StringBuilder();
            if (errBuilder.ToString().Trim().Length == 0)
            {
                foreach (var e in columns)
                {
                    colBuilder.Append(e.Value.Name + ":");
                }
            }
            error = errBuilder.ToString().Trim();
            var resStr = colBuilder.ToString();
            if (resStr.Length > 0)
            {
                if (resStr.EndsWith(":"))
                    resStr = resStr.Substring(0, resStr.Length - 1);
            }
            return resStr;
        }

        public string LoadValuesFromDB(string resStr, string reportName, DbConnection con, out string error)
        {
            var bt = new BaseTable();
            bt.setConAndPath(queryPath,con);
            var paramList = new List<DbParameter>();
            paramList.Add(Queries.addParam(OracleType.VarChar, reportName, "reportname"));
            var err = bt.Load("Select_UTL_REPORTS_COLUMN_NAMES_BY_REPORTNAME", paramList, 
                                                    typeof(Enums.UTL_REPORTS_COLUMN_NAMES));
            var arrResStr = resStr.Split(':');
            var resDict = new Dictionary<string,string>();
            foreach (var el in arrResStr)
            {
                // добавляем колонки из запроса
                if (!resDict.ContainsKey(el))
                    resDict.Add(el, "");
                
                if (bt.Rows.Count > 0)
                {
                    foreach (DataRow r in bt.Rows)
                    {
                        if (r[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.BASECOLUMNNAME)] != DBNull.Value)
                        {
                            // если есть соответсвие в базе то пишем.
                            if (el.ToUpper() == r[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.BASECOLUMNNAME)].ToString().ToUpper())
                            {
                                resDict[el] = r[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.EXCELCOLUMNNAME)].ToString();
                                // if (!resDict.ContainsKey(el))
                               //     resDict.Add(el, r[bt.CN(Enums.UTL_REPORTS_COLUMN_NAMES.EXCELCOLUMNNAME)].ToString());
                            }
                        }
                    }
                }
                //else 
                //{
                //    if (!resDict.ContainsKey(el))
                //        resDict.Add(el, "");
                //}
            }
            error = err;
            
            var resBuilder = new StringBuilder();
            foreach (var d in resDict)
            {
                resBuilder.AppendLine(d.Key + "=" + d.Value);
            }
            
            var res = string.Empty;
            if (resBuilder != null && resBuilder.ToString().Length > 0)
            {
                res = resBuilder.ToString().Replace(Environment.NewLine, ":");
                if (res.EndsWith(":"))
                    res = res.Substring(0, res.Length - 1);
            }
            return res;
        }

        private bool PrepareForRun(string reportName, string serverParamsName, string serverParamsViewName, string serverParamsType, string serverParamValues, out string shortName, out string fileName, out List<OraParameter> parameters, string system_con_str)
        {
            bool isOK = true;
            shortName = reportName.Substring(0, reportName.Length > 20 ? 20 : reportName.Length);
            string tempPath = System.Configuration.ConfigurationManager.AppSettings["PublicPath"];
            if (reportName == string.Empty) reportName = "разовый_селект";
            fileName = ViewReportLongBackEnd.PrepareFileName(reportName, username, tempPath);
            parameters = null;

            if (string.IsNullOrEmpty(serverParamsName))
            {
                //errBuilder.AppendLine("Введите знечения для параметров!");
                //isOK = false;
                parameters = new List<OraParameter>();
                return isOK;
            }
            
            if (serverParamsName != string.Empty)
            {
                var paramhtml = ExcelExport.Parameter.MakeParamList(
                                    serverParamsViewName.Split(';'),
                                    serverParamsName.Split(';'),
                                    serverParamsType.Split(';'),
                                    serverParamValues.Split(';'),
                                    username, reportName, system_con_str);

                if (paramhtml != null && paramhtml.Count > 0)
                {
                    parameters = new List<OraParameter>();
                    foreach (var p in paramhtml)
                    {
                        parameters.Add(OraParameter.AddOraParameter(p.queryName, OraParameter.convertToTypes(p.Type), p.Value, p.Name));
                    }
                }
            }
            return isOK;
        }


        public static ExcelClick PrepareUnload(ref string query, ref string reportName, System.Web.SessionState.HttpSessionState Session, ref bool isStoredProc, string QueryPath, string TemplatePath, string TemplateRowNum = "", string hdnTemplSheetName = "")
        {
            GetReportNameQuery(ref query, ref reportName, Session, ref isStoredProc);

            var shortName = Common.MakeShortName(reportName);
            var filename = TemplatePath + shortName + ".xlsx";
                
            var ec = new ExcelClick(Session.SessionID,
                                    Common.loadUserCon(Session),
                                    System.Configuration.ConfigurationManager.AppSettings["PublicPath"],
                                    HttpContext.Current.Request.LogonUserIdentity.Name,
                                    isStoredProc,
                                    query,
                                    HttpContext.Current.Request.PhysicalApplicationPath,
                                    QueryPath,
                                    filename, TemplateRowNum, hdnTemplSheetName);
            return ec;
        }

       

        public static void GetReportNameQuery(ref string query, ref string reportName, System.Web.SessionState.HttpSessionState Session, ref bool isStoredProc)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo("ru-RU");
            if (Session[SessionNames.currentElements] is Dictionary<string, Element>)
            {
                var d = Session[SessionNames.currentElements] as Dictionary<string, Element>;

                if (Session[SessionNames.CurrentReportName] != null)
                {
                    if (d.ContainsKey(Session[SessionNames.CurrentReportName].ToString()))
                    {
                        isStoredProc = d[Session[SessionNames.CurrentReportName].ToString()].IsStoredProcedure;
                        query = d[Session[SessionNames.CurrentReportName].ToString()].query;
                        reportName = d[Session[SessionNames.CurrentReportName].ToString()].name;
                    }
                }
            }
        }
    }
}