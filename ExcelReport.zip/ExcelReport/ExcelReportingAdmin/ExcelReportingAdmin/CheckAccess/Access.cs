﻿using System;
using System.Collections.Generic;
using System.Data.OracleClient;
using System.Text;
using System.Data;
using System.Data.Common;
using dll_DataLayer;
using SerializeObj;

namespace CheckAccess
{
    public class Access
    {
        public static OracleParameter addParam(OracleType type, object value, string name)
        {
            OracleParameter param = new OracleParameter();
            param.OracleType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = global::System.DBNull.Value;
            }
            else
            {
                param.Value = value;
            }
            return param;
        }
        
        public bool CheckAccess(DBConnection constr, string query, string curruser, string groupName, out string errMess)
        {
            errMess = "";
            bool isaccessed = false;
            var arrGr = groupName.Split(';');
            foreach (var role in arrGr)
            {
                isaccessed = isaccessed || checkAccess(constr, query, curruser, role, out errMess);
            }
            return isaccessed;
        }

        public bool CheckAccessUser(string curruser, string alowedUsers)
        {
            bool isaccessed = false;
            var users = alowedUsers.Split(';');
            foreach (var user in users)
            {
                isaccessed = isaccessed || user.ToUpper().Trim().EndsWith(curruser.ToUpper().Trim());
            }
            return isaccessed;
        }

        private bool checkAccess(DBConnection constr, string query, string curruser, string groupName, out string errMess)
        {
            errMess = "";
            bool isaccessed = false;
            
            DbConnection con;
            DbCommand com = null;
            DbParameterCollection param = null;
            try
            {
                switch (constr.type)
                {
                    case "Oracle":
                        query = checkAccessOracle(query, curruser, groupName, constr, ref param, ref isaccessed);
                        break;
                    case "Terradata":
                        query = checkAccessTeradata(query, curruser, groupName, constr, ref param, ref isaccessed);
                        break;
                }

            }
            catch
                (Exception e)
            {
                errMess = e.Message;
                Logger.Log.Inst.ErrorToLog(e, curruser, query, param, "Проверка доступа.");
            }
            return isaccessed;
        }

        private static string checkAccessTeradata(string query, string curruser, string groupName, DBConnection strCon,
            ref DbParameterCollection param, ref bool isaccessed)
        {
            DbConnection con;
            DbCommand com;
            using (con = DBWrapper.GetConnection(strCon.type, strCon.value))
            {
                com = DBWrapper.GetCommand(strCon.type);
                con.Open();
                com.Connection = con;
                com.CommandTimeout = 0;

                query = String.Format(query.Replace(":username", "'{0}'"), curruser);
                if (groupName.EndsWith("%"))
                    query = String.Format(query.Replace("=  upper(:name_role)", "like upper('{0}')"), groupName);
                else
                    query = String.Format(query.Replace(":name_role", "'{0}'"), groupName);

                com.CommandText = query;
                param = com.Parameters;
                var res = com.ExecuteScalar();
                if (res != DBNull.Value)
                {
                    var count = Convert.ToInt16(res);
                    if (count > 0) isaccessed = true;
                }
            }
            return query;
        }

        private static string checkAccessOracle(string query, string curruser, string groupName, DBConnection strCon,
            ref DbParameterCollection param, ref bool isaccessed)
        {
            DbConnection con;
            DbCommand com;
            using (con = DBWrapper.GetConnection(strCon.type, strCon.value))
            {
                com = DBWrapper.GetCommand(strCon.type);
                con.Open();
                com.Connection = (OracleConnection) con;
                com.CommandTimeout = 0;

                com.Parameters.Add(addParam(OracleType.VarChar, curruser, "username"));
                if (groupName.EndsWith("%"))
                    query = String.Format(query.Replace("=  upper(:name_role)", "like upper('{0}')"), groupName);
                else
                    com.Parameters.Add(addParam(OracleType.VarChar, groupName, "name_role"));
                com.CommandText = query;
                param = com.Parameters;
                var res = com.ExecuteScalar();
                if (res != DBNull.Value)
                {
                    var count = Convert.ToInt16(res);
                    if (count > 0) isaccessed = true;
                }
            }
            return query;
        }

        public bool CheckAccessLocalUser(string curruser, List<string> readUsers, string adminlocal)
        {
            bool isaccessed = false;
            var CurrUser = curruser.ToUpper().Trim();
            var AdminLocal = adminlocal.ToUpper().Trim();
            if (!AdminLocal.Contains(CurrUser))
            {
                foreach (var r in readUsers)
                {
                    if (r == CurrUser)
                    {
                        isaccessed = true;
                        break;
                    }
                }
            }
            else isaccessed = true;
            return isaccessed;
        }
    
    }
}
