﻿using System;
using System.Data.OracleClient;

namespace SerializeObj
{
    [Serializable]
    public class ElParam
    {
        public string Name;
        public string ViewName;
        public OracleType Type;
        public string MinValQuery;
        public string MaxValQuery;

        public ElParam() { }
        public ElParam(string name, string viewName, OracleType type, string minValQuery, string maxValQuery)
        {
            Name = name;
            ViewName = viewName;
            Type = type;
            MinValQuery = minValQuery;
            MaxValQuery = maxValQuery;
        }
    }
}
