﻿using System;
using System.Collections.Generic;

namespace SerializeObj
{
    [Serializable]
    public class Element
    {
        public string name;
        public string query;
        public bool isUserId = false;
        public List<ElParam> paramList;
        public string SecurityGroup;
        public bool IsStoredProcedure;
        public int rowNumInTemplate;
        public string TemplSheetName;

        public Element() { }
        public Element(string inName, string InQuery, List<ElParam> elParams, bool isuserId = false, string securityGroup = "")
        {
            name = inName;
            query = InQuery;
            paramList = elParams;
            isUserId = isuserId;
            SecurityGroup = securityGroup;
        }
    }
}
