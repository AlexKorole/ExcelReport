﻿using System;

namespace SerializeObj
{
    [Serializable]
    public class DBConnection
    {
        public string type;
        public string type_Of_Usage;
        public string value;
    }
}
