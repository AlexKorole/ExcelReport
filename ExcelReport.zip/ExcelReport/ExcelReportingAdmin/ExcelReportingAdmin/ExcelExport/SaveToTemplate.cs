﻿using System;
using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.SqlServer.Server;


namespace ExcelExport
{
    public class SaveToTemplate
    {
        private WorkbookPart globalWorkbookPart;
        private string OriginalSheetName;
        private int SheetNameNumber;
        private string globalSearchId;
        OpenXmlReader mainReader;
        bool isFirst;
        BaseExcel global_be;
        string global_replacementPartId;
        WorksheetPart global_worksheetPart;
        UInt32Value sheetid_Value;
        private string ReportName;

        public void CreateExcelFile(string filename, string sheetName, string query, List<OraParameter> parameters, BaseDataReader r, BaseExcel be, string reportName, out bool norows, out string err, string username, string system_con_str, ref UInt32 TotalRows)
        {
            ReportName = reportName;
            sheetid_Value = 4321U;
            SheetNameNumber = 0;
            
            err = string.Empty;
            norows = false;
            SpreadsheetDocument myDoc;
            WorkbookPart workbookPart;

            myDoc = SpreadsheetDocument.Open(filename, true);
            globalWorkbookPart = workbookPart = myDoc.WorkbookPart;

            string searchId = GetSheetIdByName(sheetName, workbookPart);
            globalSearchId = searchId;
            OriginalSheetName = sheetName;
            global_be = be;
            //--------------------------
            _loadParameters( query, parameters, r, ref norows, ref err, workbookPart, searchId, be, reportName);
            if(string.IsNullOrEmpty(err))
                _loadMainData(query, parameters, r, ref norows, ref err, workbookPart, searchId, be, username, system_con_str, ref TotalRows);
            myDoc.Close();
        }


        #region Функционал для выгрузок более 500 000 строк
        public void OpenNewSheet()
        {
            #region Закрываем предыдущую страницу
            global_be.writer.WriteEndElement();
            while (mainReader.Read())
            {
                if (mainReader.ElementType == typeof(SheetData)) {
                    if (mainReader.IsEndElement)
                    {
                        global_be.writer.WriteEndElement();
                        continue;
                    }
                }
                else
                {
                    if (mainReader.IsStartElement)
                    {
                        global_be.writer.WriteStartElement(mainReader);
                    }
                    else if (mainReader.IsEndElement)
                    {
                        global_be.writer.WriteEndElement();
                    }
                }
            }
            //------Close------------------------------
            mainReader.Close();
            global_be.writer.Close();

            if (isFirst)
            {
                Sheet newsheet = globalWorkbookPart.Workbook.Descendants<Sheet>()
                .Where(s => s.Id.Value.Equals(globalSearchId)).First();
                newsheet.Id.Value = global_replacementPartId;
                globalWorkbookPart.DeletePart(global_worksheetPart);
                isFirst = false;
                globalSearchId = GetSheetIdByName(OriginalSheetName, globalWorkbookPart);
            }
            else
            {
                sheetid_Value++;
                SheetNameNumber++;
                var newSheet = new Sheet()
                {
                    Name = string.Join("_", new [] {OriginalSheetName,SheetNameNumber.ToString()}),
                    SheetId = sheetid_Value,
                    Id = global_replacementPartId
                };
                globalWorkbookPart.Workbook.Sheets.Append(newSheet);

                WorksheetPart wsp = (WorksheetPart)globalWorkbookPart.GetPartById(global_replacementPartId);
                SheetView sw = wsp.Worksheet.SheetViews.FirstOrDefault() as SheetView;
                if (sw != null && sw.TabSelected != null && sw.TabSelected.Value == true)
                    sw.TabSelected.Value = false;
            }

            #endregion  Закрываем предыдущую страницу

            //-------------------------------------------------------------------
            #region Открываем новую
            bool iscopyCell = false;
            WorksheetPart worksheetPart = globalWorkbookPart.GetPartById(globalSearchId) as WorksheetPart;
            WorksheetPart replacementPart = globalWorkbookPart.AddNewPart<WorksheetPart>();
            global_replacementPartId = globalWorkbookPart.GetIdOfPart(replacementPart);

            mainReader = OpenXmlReader.Create(worksheetPart);
            global_be.writer = OpenXmlWriter.Create(replacementPart);

            int count_row_num = 0;
            int intRowNum = 0;
            int.TryParse(global_be._templateRowNum, out intRowNum);
            while (mainReader.Read())
            {
                if (mainReader.ElementType == typeof(SheetData))
                {
                    if (mainReader.IsEndElement)
                    {
                        break;
                    }

                    //if (test_row_num < 6)
                    //{
                    //    global_be.writer.WriteStartElement(mainReader);
                    //    global_be.writer.WriteEndElement();
                    //} else 
                    {
                        iscopyCell = true;
                        global_be.writer.WriteStartElement(new SheetData());
                    }
                }
                else
                {
                    /*if (mainReader.IsStartElement)
                    {
                        if (iscopyCell)
                            global_be.writer.WriteElement(mainReader.LoadCurrentElement());
                        else
                            global_be.writer.WriteStartElement(mainReader);
                    }
                    else if (mainReader.IsEndElement)
                    {
                        global_be.writer.WriteEndElement();
                    }*/

                    if (!iscopyCell || (mainReader.ElementType == typeof(Worksheet) && mainReader.IsEndElement))
                    {
                        if (!iscopyCell && (mainReader.ElementType == typeof(Worksheet) && mainReader.IsEndElement)) iscopyCell = true;

                        if (mainReader.IsStartElement)
                        {
                            global_be.writer.WriteStartElement(mainReader);
                        }
                        else if (mainReader.IsEndElement)
                        {
                            global_be.writer.WriteEndElement();
                        }
                    }
                    else
                    {
                        if (count_row_num < intRowNum)
                        {
                            global_be.writer.WriteElement(mainReader.LoadCurrentElement());
                            count_row_num++;
                        }
                    }
                }
            }
           
            #endregion Открываем новую
        }
        #endregion Функционал для выгрузок более 500 000 строк

        public string GetSheetIdByName(string sheetName, WorkbookPart workbookPart)
        {
            // Поиск искомой страницы
            string searchId = string.Empty;
            foreach (var sheet in workbookPart.Workbook.Sheets)
            {
                if (sheet.GetAttribute("name", "").Value == sheetName)
                {
                    searchId = sheet.GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships").Value;
                    var string_sheetId = sheet.GetAttribute("sheetId", "").Value;
                    int outIntSheetId;
                    
                    if (isFirst && int.TryParse(string_sheetId, out outIntSheetId))
                    {
                        sheetid_Value = Convert.ToUInt32(outIntSheetId);
                    }
                }
            }
            return searchId;
        }

        public static string GetSheetIdByStartWithName(string sheetName, WorkbookPart workbookPart)
        {
            // Поиск искомой страницы
            string searchId = string.Empty;
            foreach (var sheet in workbookPart.Workbook.Sheets)
            {
                if (sheet.GetAttribute("name", "").Value.StartsWith(sheetName))
                {
                    searchId = sheet.GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships").Value;
                }
            }
            return searchId;
        }

        private void _loadParameters(string query, List<OraParameter> parameters, BaseDataReader r, ref bool norows, ref string err, WorkbookPart workbookPart, string searchId, BaseExcel be, string reportName)
        {
            string replacementPartId;
            WorksheetPart worksheetPart = workbookPart.GetPartById(searchId) as WorksheetPart;
            WorksheetPart replacementPart = workbookPart.AddNewPart<WorksheetPart>();
            replacementPartId = workbookPart.GetIdOfPart(replacementPart);

            OpenXmlReader reader = OpenXmlReader.Create(worksheetPart);
            be.writer = OpenXmlWriter.Create(replacementPart);

            //------Reading/Writting---------------------------
            bool isSheetData = false;
            while (reader.Read())
            {
                if (reader.ElementType == typeof(SheetData))
                {
                    if (reader.IsEndElement)
                    {
                        continue;
                    }
                    be.writer.WriteStartElement(new SheetData());
                        isSheetData = true;
                        be.SaveParameters(parameters, reportName);
                        be.writer.WriteEndElement();
                }
                else
                {
                    //if (reader.ElementType == typeof(SheetView))
                    //{
                    //    var atr = reader.Attributes.Single(a => a.LocalName == "tabSelected");
                    //    reader.Attributes[0].Value = "";
                    //    atr.Value = "";
                    //    //var v = new SheetView();
                    //    //v.TabSelected.Value = false;
                    //    be.writer.WriteStartElement(reader);
                    //}

                    if (!isSheetData || (reader.ElementType == typeof(Worksheet) && reader.IsEndElement))
                    {
                        if (!isSheetData && (reader.ElementType == typeof(Worksheet) && reader.IsEndElement)) isSheetData = true;
                        
                        if (reader.IsStartElement)
                        {
                            be.writer.WriteStartElement(reader);
                        }
                        else if (reader.IsEndElement)
                        {
                            be.writer.WriteEndElement();
                        }
                    }
                }
            }
            //------Close------------------------------
            reader.Close();
            be.writer.Close();
            sheetid_Value++;
            var sheetParam = new Sheet()
            {
                Name = "Параметры (1)",
                SheetId = sheetid_Value,
                Id = replacementPartId
            };

            workbookPart.Workbook.Sheets.Append(sheetParam);
            WorksheetPart wsp = (WorksheetPart)workbookPart.GetPartById(replacementPartId);
            SheetView sw = wsp.Worksheet.SheetViews.FirstOrDefault() as SheetView;
            if (sw != null && sw.TabSelected != null && sw.TabSelected.Value == true)
                sw.TabSelected.Value = false;
        }

        private void _loadMainData(string query, List<OraParameter> parameters, BaseDataReader r, ref bool norows, ref string err, WorkbookPart workbookPart, string searchId, BaseExcel be, string username, string system_con_str, ref UInt32 TotalRows)
        {
            string replacementPartId;
            WorksheetPart worksheetPart = workbookPart.GetPartById(searchId) as WorksheetPart;
            global_worksheetPart = worksheetPart;

            WorksheetPart replacementPart = workbookPart.AddNewPart<WorksheetPart>();
            replacementPartId = workbookPart.GetIdOfPart(replacementPart);
            global_replacementPartId = replacementPartId;

            mainReader = OpenXmlReader.Create(worksheetPart);
            be.writer = OpenXmlWriter.Create(replacementPart);

            //------Reading/Writing---------------------------
            bool iscopyCell = false;
            isFirst = true;
            while (mainReader.Read())
            {
                if (mainReader.ElementType == typeof(SheetData))
                {
                    if (mainReader.IsEndElement)
                    {
                        r.RunReader(query, parameters, false, out norows, out err, username, system_con_str, ReportName, ref TotalRows);
                        be.writer.WriteEndElement();
                        iscopyCell = false;
                        continue;
                    }
                    be.writer.WriteStartElement(mainReader);
                    iscopyCell = true;
                }
                else
                {
                    if (mainReader.IsStartElement)
                    {
                        if (iscopyCell)
                            be.writer.WriteElement(mainReader.LoadCurrentElement());
                        else
                            be.writer.WriteStartElement(mainReader);
                    }
                    else if (mainReader.IsEndElement)
                    {
                        be.writer.WriteEndElement();
                    }
                }
            }
            //------Close------------------------------
            mainReader.Close();
            be.writer.Close();

            if (isFirst)
            {
                Sheet newsheet = workbookPart.Workbook.Descendants<Sheet>()
                .Where(s => s.Id.Value.Equals(searchId)).First();
                newsheet.Id.Value = replacementPartId;
                workbookPart.DeletePart(worksheetPart);
            }
            else
            {
                sheetid_Value++;
                SheetNameNumber++;
                var newSheet = new Sheet()
                {
                    Name = string.Join("_", new [] {OriginalSheetName,SheetNameNumber.ToString()}),
                    SheetId = sheetid_Value,
                    Id = global_replacementPartId
                };
                globalWorkbookPart.Workbook.Sheets.Append(newSheet);
                WorksheetPart wsp = (WorksheetPart)globalWorkbookPart.GetPartById(global_replacementPartId);
                SheetView sw = wsp.Worksheet.SheetViews.FirstOrDefault() as SheetView;
                if (sw != null && sw.TabSelected != null && sw.TabSelected.Value == true)
                    sw.TabSelected.Value = false;
            }
        }
    }
}
