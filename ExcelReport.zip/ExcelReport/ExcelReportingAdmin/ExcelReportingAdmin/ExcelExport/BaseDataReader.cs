﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data;
using System.Text;
using dll_DataLayer;
using SerializeObj;
using Teradata.Client.Provider;

namespace ExcelExport
{
    public class BaseDataReader
    {
        public string dbtype;
        public string oracleCon;
        private bool isStoredProc;

        public delegate void OpenRowData(int rowNum);
        public event OpenRowData openRowEvent;

        public delegate void CloseRow();
        public event CloseRow closeRowEvent;

        public delegate void SaveCellsData(BaseColumn c, object value, int colNum);
        public event SaveCellsData saveCellsEvent;

        public delegate void OpenNewSheet();
        public event OpenNewSheet openNewSheet;

        public Dictionary<int, BaseColumn> Columns;

        private int NumRowsPerPage;

        public BaseDataReader(DBConnection conConfig, bool IsStoredProc)
        {
            oracleCon = conConfig.value;
            isStoredProc = IsStoredProc;
            dbtype = conConfig.type;

            NumRowsPerPage = 700000;
            var strNumRows = System.Configuration.ConfigurationManager.AppSettings["NumRowsPerPage"];
            if (strNumRows != null)
                int.TryParse(strNumRows, out NumRowsPerPage);
        }

        public static OracleParameter addParam(OracleType type, object value, string name)
        {
            OracleParameter param = new OracleParameter();
            param.OracleType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = global::System.DBNull.Value;
            }
            else
            {
                param.Value = value;
            }
            return param;
        }

        public static TdParameter addParam(TdType type, object value, string name)
        {
            TdParameter param = new TdParameter();
            param.TdType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = DBNull.Value;
            }
            else
            {
                param.Value = value;
            }
            return param;
        }

        public void RunReader(string query, List<OraParameter> parameters, bool isColumnOnly, out bool norows, out string err, string username, string system_con_str, string reportName, ref UInt32 TotalRows)
        {
            norows = false;
            uint numRows = 0;
            TotalRows = 0;

            var con = DBWrapper.GetConnection( dbtype, oracleCon);
            using (con)
            {
                con.Open();
                DbParameterCollection paramCol;
                DbDataReader reader = execReader(query, con, parameters, out err, username, system_con_str, out paramCol, reportName);
                Logger.Log.Inst.StatusToLog("Начало запроса", username, query, paramCol, reportName, 0);
            
                if (!string.IsNullOrEmpty(err)) return;
                try
                {
                    if (reader.FieldCount > 0)
                    {
                        if (reader.HasRows)
                        {
                            numRows++;
                            var columns = GetColumns(reader);
                            if (isColumnOnly)
                            {
                                Columns = columns;
                            }
                            else
                            {
                                int rowNum = 2;
                                while (reader.Read())
                                {
                                    TotalRows++;
                                    if (numRows > NumRowsPerPage)
                                    {
                                        if (openNewSheet != null) openNewSheet();
                                        GetColumns(reader);
                                        rowNum = 2;
                                        numRows = 1;
                                    }

                                    if (openRowEvent != null) openRowEvent(rowNum);
                                    for (int i = 0; i < reader.FieldCount; i++)
                                    {
                                        if (saveCellsEvent != null) saveCellsEvent(columns[i], reader[i], i);
                                    }
                                    if (closeRowEvent != null) closeRowEvent();
                                    rowNum++;
                                    numRows++;
                                }
                            }
                        }
                        else
                        {
                            norows = true;
                            var columns = GetColumns(reader);
                            Columns = columns;
                        }
                    }

                    Logger.Log.Inst.StatusToLog("Запрос успешно выполнен", username, query, paramCol,
                        reportName, TotalRows);
                }
                catch (Exception e)
                {
                    err = e.Message;
                    Logger.Log.Inst.ErrorToLog(e, username, query, paramCol, reportName);
                }
                finally
                {
                    reader.Close();
                }
            }
        }

        private Dictionary<int,BaseColumn> GetColumns(DbDataReader reader)
        {
            Dictionary<int, BaseColumn> col = new Dictionary<int, BaseColumn>();
            var schema = reader.GetSchemaTable();
            if (openRowEvent != null) openRowEvent(1);
            for (int i = 0; i < reader.FieldCount; i++)
            {
                DataRow field = schema.Rows[i];
                var c = new BaseColumn();
                c.Name = field["ColumnName"].ToString();
                c.Type = (System.Type)field["DataType"];
                c.size = Convert.ToInt32(field["ColumnSize"]);
                c.colNumber = i;
                col.Add(i,c);
                if (saveCellsEvent != null) saveCellsEvent(c, null, c.colNumber + 1);
            }
            if (closeRowEvent != null) closeRowEvent();
            return col;
        }

        private DbDataReader execReader(string query,DbConnection con, List<OraParameter> parameters, out string err, string username, string system_con_str, out DbParameterCollection paramCol, string reportName)
        {
            err = string.Empty;
            var com = DBWrapper.GetCommand(dbtype);
            com.Connection = con;
            com.CommandTimeout = 0;
            com.CommandText = query;
            var resQuery = query;
            if (isStoredProc)
            {
                var arr = com.CommandText.Split('(');
                if (arr.Length > 1)
                    resQuery = com.CommandText.Split('(')[0];
                else resQuery = query;

                com.CommandText = resQuery;
                com.CommandType = CommandType.StoredProcedure;
                if(dbtype == "Oracle")
                    (com as OracleCommand).Parameters.Add("returnValue", OracleType.Cursor).Direction = ParameterDirection.ReturnValue;
                query = resQuery;
            }

            if (parameters != null && parameters.Count > 0)
            {
                if (dbtype == "Oracle")
                {
                    TeradataBuildQuery.enterMultiParameters(ref query, parameters);
                    if (!com.CommandText.Equals(query)) com.CommandText = query;
                    foreach (var p in parameters){ com.Parameters.Add(addParam(p.type, p.Value, p.Name));}
                }
                else
                {
                    TeradataBuildQuery.prepareTeradataQuery(query, parameters, com);
                }
            }

            DbDataReader reader = null;
            paramCol = com.Parameters;

            var tran = con.BeginTransaction();
            try
            {
                com.Transaction = tran;
                
                    //Необходимые настройки для сессии
                var specQuery = System.Configuration.ConfigurationManager.AppSettings["SessionSpecificQuery"];
                if (!string.IsNullOrEmpty(specQuery))
                {
                    var comSpec = DBWrapper.GetCommand(dbtype);
                    comSpec.Connection = con;
                    comSpec.CommandTimeout = 0;
                    comSpec.CommandText = specQuery;
                    comSpec.Transaction = tran;
                    comSpec.ExecuteNonQuery();
                }
                //

                if (isStoredProc)
                {
                    com.ExecuteNonQuery();
                    reader = (OracleDataReader)com.Parameters["returnValue"].Value;
                } else 
                    reader = com.ExecuteReader();
                tran.Commit();
            }
            catch (Exception e)
            {
                tran.Rollback();
                err = e.Message;
                Logger.Log.Inst.ErrorToLog(e, username, query, paramCol, reportName);
            }
            return reader;
        }

        public DateTime LoadDateFromDB(string query)
        {
            OracleConnection con;
            con = new OracleConnection(oracleCon);
            con.Open();
            OracleCommand com = new OracleCommand();
            com.Connection = con;
            com.CommandTimeout = 0;
            com.CommandText = query;
            var res = com.ExecuteScalar();
            con.Close();
            if (res is DateTime)
            {
                return (DateTime)res;
            }
            else return DateTime.MinValue;
        }

        /// <summary>
        /// Инициализирует соединение
        /// </summary>
        private OracleCommand initCon(string query, OracleParameterCollection lparam, out OracleConnection con, OracleTransaction tran = null)
        {
            con = new OracleConnection(oracleCon);
            con.Open();
            OracleCommand com = new OracleCommand();
            if (tran != null) com.Transaction = tran;
            com.Connection = con;
            com.CommandTimeout = 0;
            com.CommandText = query;
            com.Parameters.Clear();
            if (lparam != null && lparam.Count > 0)
            {

                var ArrayOracleParameter = new OracleParameter[lparam.Count];
                for(int i =0; i < lparam.Count; i++)
                    ArrayOracleParameter[i] = lparam[i];
                lparam.Clear();
                com.Parameters.AddRange(ArrayOracleParameter);
            }
            return com;
        }

        /// <summary>
        ///  Функция выполняет запрос в базе
        /// </summary>
        public object ExecNonQuery(string query, OracleTransaction tran, out string err, OracleParameterCollection lparam, bool isStoredProcedure, string username, string system_con_str, string reportName)
        {
            object res = null;
            err = string.Empty;
            OracleParameterCollection paramCol = null;
            try
            {
                OracleConnection con;
                var com = initCon(query, lparam, out con, tran);
                if (isStoredProcedure) com.CommandType = CommandType.StoredProcedure;
                else com.CommandType = CommandType.Text;
                paramCol = com.Parameters;
                res = com.ExecuteNonQuery();
                com.Parameters.Clear();
                con.Close();
            }
            catch (Exception e)
            {
                err = e.Message;
                Logger.Log.Inst.ErrorToLog(e, username, query, paramCol, reportName);
            }
            return res;
        }

    }
}