﻿using System;

namespace ExcelExport
{
    public class BaseColumn
    {
        public string Name;
        public Type Type;
        public int size;
        public int colNumber;
    }
}