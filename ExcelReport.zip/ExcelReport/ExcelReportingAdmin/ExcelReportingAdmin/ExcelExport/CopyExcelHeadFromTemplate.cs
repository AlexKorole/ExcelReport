﻿using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.IO;

namespace ExcelExport
{
    public class CopyExcelHeadFromTemplate
    {
        public static void CopyHead(string filename, string str_rowNum, string sheetName, OpenXmlWriter writer)
        {
            if (!File.Exists(filename)) return;
            if (string.IsNullOrEmpty(str_rowNum)) return;
            int rowNum;
            if (!int.TryParse(str_rowNum, out rowNum))
               return;
            if (rowNum == 0) return;

            var dictRows = new Dictionary<int,List<string>>();
            int currRow = 0;
            using (SpreadsheetDocument myDoc = SpreadsheetDocument.Open(filename, false))
            {
                var workbookPart = myDoc.WorkbookPart;

                // Поиск искомой страницы
                string searchId = string.Empty;
                foreach (var sheet in workbookPart.Workbook.Sheets)
                {
                    if (workbookPart.Workbook.Sheets.ToArray()[0].GetAttribute("name", "").Value == sheetName)
                    {
                        searchId = workbookPart.Workbook.Sheets.ToArray()[0].GetAttribute("id", "http://schemas.openxmlformats.org/officeDocument/2006/relationships").Value;
                    }
                }
                //--------------------------

                var worksheetPart = workbookPart.GetPartById(searchId);
                var reader = OpenXmlReader.Create(worksheetPart);
                var text = new List<string>();
                    while (reader.Read())
                    {
                        if (reader.ElementType.Name == "Row")
                        {
                            currRow++;
                            text = new List<string>();
                            if (rowNum == currRow) break;
                            reader.ReadFirstChild();
                            do
                            {
                                if (reader.ElementType == typeof(Cell))
                                {
                                    Cell c = (Cell)reader.LoadCurrentElement();
                                    string cellValue;
                                    var isexists = false;
                                    if (c.DataType != null && c.DataType == CellValues.SharedString)
                                    {
                                        SharedStringItem ssi = workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(int.Parse(c.CellValue.InnerText));
                                        cellValue = ssi.Text.Text;
                                        isexists = true;
                                    }
                                    else
                                    {
                                        if (c.CellValue != null)
                                            cellValue = c.CellValue.InnerText;
                                        else cellValue = string.Empty;
                                        isexists = true;
                                    }
                                    if (isexists) text.Add(cellValue);
                                }
                            } while(reader.ReadNextSibling());
                            dictRows.Add(currRow, text);
                        }
                    }
                    reader.Close();
                }
            Save( dictRows, writer, rowNum);
        }

        private static void OpenRow(int rowNum, OpenXmlWriter writer)
        {
            var oxa = new List<OpenXmlAttribute>();
            oxa.Add(new OpenXmlAttribute("r", null, rowNum.ToString()));
            writer.WriteStartElement(new Row(), oxa);
        }

        private static void CloseRow(OpenXmlWriter writer)
        {
            writer.WriteEndElement();
        }

        private static void Save(Dictionary<int, List<string>> dictRows, OpenXmlWriter writer, int rowNum)
        {
            var oxa = new List<OpenXmlAttribute>();
            string exelType = "str";
            oxa.Add(new OpenXmlAttribute("t", null, exelType));
            int writeRow = 1;
            foreach(var el in dictRows)
            {
               OpenRow(writeRow, writer);
               foreach(var elem in el.Value)
               {
                    writer.WriteStartElement(new Cell(), oxa);
                    writer.WriteElement(new CellValue(BadChars.Fix(elem)));
                    writer.WriteEndElement();
               }
               CloseRow(writer);
               writeRow++;

               while(writeRow < rowNum)
               {
                   writer.WriteStartElement(new Cell(), oxa);
                   writer.WriteElement(new CellValue(BadChars.Fix(string.Empty)));
                   writer.WriteEndElement();
                   writeRow++;
               }
            }
        }

    }
}
