﻿using System;
using System.Collections.Generic;
using System.Data.OracleClient;

namespace CheckAccess
{
    public class Access
    {
        public static OracleParameter addParam(OracleType type, object value, string name)
        {
            OracleParameter param = new OracleParameter();
            param.OracleType = type;
            param.ParameterName = name;
            param.IsNullable = true;
            if (value == null)
            {
                param.Value = global::System.DBNull.Value;
            }
            else
            {
                param.Value = value;
            }
            return param;
        }
        
       /* public bool CheckAccess(string curruser, string groupName, out string errMess)
        {
            bool retval = false;
            errMess = "";
            using (ClientContext client = new ClientContext("http://finu"))
            {
                Web w = client.Web;
                GroupCollection globalGr = null;
                globalGr = w.SiteGroups;
                client.Load(globalGr, groups => groups.Include(group => group.Title));
                client.ExecuteQuery();

                foreach (Group ogr in globalGr)
                {
                    if (ogr.Title.ToUpper().Trim() == groupName.ToUpper().Trim())
                    {
                        var collUser = ogr.Users;
                        client.Load(collUser, users => users.Include(user => user.LoginName));
                        try
                        {
                            client.ExecuteQuery();
                            foreach (User oUser in collUser)
                            {
                                if (oUser.LoginName.ToUpper().Trim() == curruser.ToUpper().Trim())
                                {
                                    retval = true;
                                    break;
                                }
                            }
                        }
                        catch(Exception e)
                        {
                            errMess = e.Message;
                            retval = false;
                        }
                        break;
                    }
                }
            }
            return retval;
        }*/

        public bool CheckAccess(string constr, string query, string curruser, string groupName, out string errMess)
        {
            errMess = "";
            bool isaccessed = false;
            var arrGr = groupName.Split(';');
            foreach (var role in arrGr)
            {
                isaccessed = isaccessed || checkAccess(constr, query, curruser, role, out errMess);
            }
            return isaccessed;
        }

        public bool CheckAccessUser(string curruser, string alowedUsers)
        {
            bool isaccessed = false;
            var users = alowedUsers.Split(';');
            foreach (var user in users)
            {
                isaccessed = isaccessed || user.ToUpper().Trim().EndsWith(curruser.ToUpper().Trim());
            }
            return isaccessed;
        }

        private bool checkAccess(string constr, string query, string curruser, string groupName, out string errMess)
        {
            errMess = "";
            bool isaccessed = false;
            OracleConnection con;
            con = new OracleConnection(constr);
            try
            {
                con.Open();
                OracleCommand com = new OracleCommand();
                com.Connection = con;
                com.CommandTimeout = 0;

                com.Parameters.Add(addParam(OracleType.VarChar, curruser, "username"));
                if (groupName.EndsWith("%"))
                    query = String.Format(query.Replace("=  upper(:name_role)", "like upper('{0}')"), groupName);
                else
                    com.Parameters.Add(addParam(OracleType.VarChar, groupName, "name_role"));
                com.CommandText = query;

                var res = com.ExecuteScalar();
                if (res != DBNull.Value)
                {
                    var count = Convert.ToInt16(res);
                    if (count > 0) isaccessed = true;
                }
            }
            catch (Exception e)
            {
                errMess = e.Message;

                Logger.Log.Inst.SaveToLog(constr,
                      System.Configuration.ConfigurationManager.AppSettings["utl_reports_error_log"],
                      e.Message,
                      curruser,
                      e.GetType().Name,
                      e.StackTrace,
                      "");
            }
            finally
            {
                con.Close();
            }
            return isaccessed;
        }

        public bool CheckAccessLocalUser(string curruser, List<string> readUsers, string adminlocal)
        {
            bool isaccessed = false;
            var CurrUser = curruser.ToUpper().Trim();
            var AdminLocal = adminlocal.ToUpper().Trim();
            if (!AdminLocal.Contains(CurrUser))
            {
                foreach (var r in readUsers)
                {
                    if (r == CurrUser)
                    {
                        isaccessed = true;
                        break;
                    }
                }
            }
            else isaccessed = true;
            return isaccessed;
        }
    
    }
}
